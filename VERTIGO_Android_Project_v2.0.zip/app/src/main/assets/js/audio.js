/* VERTIGO audio: live-synthesised phonk (808 bass, cowbell, chops) + sfx. No external files, works offline. */
(function(){
'use strict';
const V=window.V;
let ctx=null,master,musicBus,sfxBus,musicLP,noiseBuf,curve;
const A=V.audio={vol:{music:.7,sfx:.8},ok:false,track:null,intensity:.5,slow:false};

function mtof(n){return 440*Math.pow(2,(n-69)/12)}
A.init=function(){if(ctx){if(ctx.state==='suspended')ctx.resume();return}
 try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;ctx=new AC();
  master=ctx.createGain();master.gain.value=.9;const comp=ctx.createDynamicsCompressor();comp.threshold.value=-14;comp.ratio.value=5;master.connect(comp);comp.connect(ctx.destination);
  musicLP=ctx.createBiquadFilter();musicLP.type='lowpass';musicLP.frequency.value=18000;musicBus=ctx.createGain();musicBus.connect(musicLP);musicLP.connect(master);
  sfxBus=ctx.createGain();sfxBus.connect(master);
  noiseBuf=ctx.createBuffer(1,ctx.sampleRate,ctx.sampleRate);const d=noiseBuf.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
  curve=new Float32Array(256);for(let i=0;i<256;i++){const x=i/128-1;curve[i]=Math.tanh(x*2.6)}
  A.ok=true;A.apply();A.schedStart()}catch(e){A.ok=false}};
A.apply=function(){if(!ctx)return;musicBus.gain.value=A.vol.music*.85;sfxBus.gain.value=A.vol.sfx};
A.suspend=function(){if(ctx&&ctx.state==='running')ctx.suspend()};
A.resume=function(){if(ctx&&ctx.state==='suspended')ctx.resume()};
A.setSlow=function(on){A.slow=on;if(ctx)musicLP.frequency.setTargetAtTime(on?500:18000,ctx.currentTime,.08)};

/* ---------- instruments ---------- */
function env(g,t,a,d,v){g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+a);g.gain.exponentialRampToValueAtTime(.0008,t+a+d)}
function kick(t,v){const o=ctx.createOscillator(),g=ctx.createGain();o.type='sine';o.frequency.setValueAtTime(165,t);o.frequency.exponentialRampToValueAtTime(42,t+.13);env(g,t,.003,.28,v);o.connect(g);g.connect(musicBus);o.start(t);o.stop(t+.32)}
function bass(t,n,dur,v,slide){const o=ctx.createOscillator(),o2=ctx.createOscillator(),g=ctx.createGain(),ws=ctx.createWaveShaper();ws.curve=curve;const f=mtof(n);
 o.type='sine';o2.type='triangle';o.frequency.setValueAtTime(slide?f*1.5:f,t);if(slide)o.frequency.exponentialRampToValueAtTime(f,t+.09);o2.frequency.value=f;
 g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+.01);g.gain.exponentialRampToValueAtTime(.001,t+dur);o.connect(ws);o2.connect(ws);ws.connect(g);g.connect(musicBus);o.start(t);o2.start(t);o.stop(t+dur+.05);o2.stop(t+dur+.05)}
function noise(t,dur,type,freq,v,q){const s=ctx.createBufferSource(),f=ctx.createBiquadFilter(),g=ctx.createGain();s.buffer=noiseBuf;f.type=type;f.frequency.value=freq;if(q)f.Q.value=q;env(g,t,.001,dur,v);s.connect(f);f.connect(g);g.connect(musicBus);s.start(t,Math.random()*.5);s.stop(t+dur+.02)}
function clap(t,v){noise(t,.16,'bandpass',1500,v,.8);noise(t+.012,.12,'bandpass',2100,v*.7,.8)}
function hat(t,v,open){noise(t,open?.18:.04,'highpass',7500,v)}
function cow(t,n,v){const g=ctx.createGain(),f=ctx.createBiquadFilter();f.type='bandpass';f.frequency.value=mtof(n+12)*1.6;f.Q.value=2.5;env(g,t,.002,.22,v);f.connect(g);g.connect(musicBus);
 for(const m of[1,1.504]){const o=ctx.createOscillator();o.type='square';o.frequency.value=mtof(n+12)*m;o.connect(f);o.start(t);o.stop(t+.26)}}
function pad(t,n,dur,v){const g=ctx.createGain(),f=ctx.createBiquadFilter();f.type='lowpass';f.frequency.value=900;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+dur*.4);g.gain.linearRampToValueAtTime(0,t+dur);f.connect(g);g.connect(musicBus);
 for(const d of[-9,0,9]){const o=ctx.createOscillator();o.type='sawtooth';o.frequency.value=mtof(n);o.detune.value=d;o.connect(f);o.start(t);o.stop(t+dur+.05)}}
function chop(t,n,dur,v){const g=ctx.createGain(),o=ctx.createOscillator(),f1=ctx.createBiquadFilter(),f2=ctx.createBiquadFilter();o.type='sawtooth';o.frequency.value=mtof(n);f1.type='bandpass';f1.frequency.value=780;f1.Q.value=6;f2.type='bandpass';f2.frequency.value=1250;f2.Q.value=8;
 env(g,t,.012,dur,v);o.connect(f1);o.connect(f2);f1.connect(g);f2.connect(g);g.connect(musicBus);o.start(t);o.stop(t+dur+.05)}
function siren(t,dur,v){const o=ctx.createOscillator(),g=ctx.createGain();o.type='sawtooth';o.frequency.setValueAtTime(300,t);o.frequency.linearRampToValueAtTime(900,t+dur);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+dur*.9);g.gain.linearRampToValueAtTime(0,t+dur);const f=ctx.createBiquadFilter();f.type='lowpass';f.frequency.value=2200;o.connect(f);f.connect(g);g.connect(musicBus);o.start(t);o.stop(t+dur+.05)}

/* ---------- tracks ---------- */
const P=s=>s.split('').map(c=>c==='x'?1:c==='o'?2:0);
const TR={
 menu:{bpm:104,root:45,kick:P('x.......x.......'),clap:P('........x.......'),hat:P('x.x.x.x.x.x.x.x.'),cow:P('x..x....x..x....'),bass:P('x.......x.....x.'),mel:[0,3,5,7,5,3,0,-2],chord:[0,0,-4,-2],chops:false,pad:true},
 run:{bpm:138,root:53,kick:P('x..x..x...x..x..'),clap:P('....x.......x...'),hat:P('xoxxxoxxxoxxxoxo'),cow:P('x.x..x.xx.x..x..'),bass:P('x..x..x...x.x...'),mel:[0,3,7,3,5,3,0,10],chord:[0,0,-4,-2],chops:true,pad:true},
 boss:{bpm:150,root:49,kick:P('x.xx.xx.x.xxx.x.'),clap:P('....x.......x..x'),hat:P('xxxxxxxxxxxxxxxx'),cow:P('xx.xx.x.xx.xx.x.'),bass:P('x.xx.xx.x.xx.xx.'),mel:[0,1,3,1,0,-2,0,3],chord:[0,-2,-4,-5],chops:true,pad:true,siren:true},
 chase:{bpm:160,root:50,kick:P('x.x.x.x.x.xxx.x.'),clap:P('....x.......x...'),hat:P('xxxxxxxxxxxxxxxx'),cow:P('x.xx.x.xx.xx.x.x'),bass:P('xx.xx.xx.xx.xx.x'),mel:[0,3,5,7,10,7,5,3],chord:[0,0,3,-2],chops:true,pad:true,siren:true},
 win:{bpm:120,root:48,kick:P('x...x...x...x...'),clap:P('....x.......x...'),hat:P('x.x.x.x.x.x.x.x.'),cow:P('x.x.x.x.x.x.x.x.'),bass:P('x...x...x...x...'),mel:[0,4,7,12,7,4,7,12],chord:[0,5,7,0],chops:false,pad:true}
};
V.TRACKS=TR;
const ROOTS=[53,50,45,55,48,52];
A.districtRoot=i=>ROOTS[i%6];
let step=0,nextT=0,timer=null,cur=null,curRoot=null,nextTrack=null;
A.play=function(name,root){if(!ctx){A.want=[name,root];return}const tr=TR[name];if(!tr)return;if(A.trackName===name&&curRoot===root)return;A.trackName=name;curRoot=root;cur=Object.assign({},tr);if(root!=null)cur.root=root;step=0;nextT=ctx.currentTime+.06};
A.stop=function(){cur=null;A.trackName=null};
A.schedStart=function(){if(timer)return;timer=setInterval(sched,30);if(A.want){const w=A.want;A.want=null;A.play(w[0],w[1])}};
function sched(){if(!ctx||!cur||ctx.state!=='running')return;const sp=60/cur.bpm/4;if(nextT<ctx.currentTime-.4)nextT=ctx.currentTime+.05;
 while(nextT<ctx.currentTime+.14){play16(nextT,step,cur,sp);nextT+=sp;step=(step+1)%64}}
function play16(t,st,T,sp){const s=st%16,bar=(st>>4)&3,I=A.intensity,ch=T.chord[bar],r=T.root+ch,v=1;
 if(T.kick[s])kick(t,.9);
 if(T.clap[s])clap(t,.5);
 if(T.hat[s]){const acc=(s%4===2)?1:.55;if(I>.2||s%2===0)hat(t,.16*acc*(T.hat[s]===2?1.4:1),T.hat[s]===2&&s%4===3)}
 if(T.bass[s]){const dur=sp*(T.bass[(s+1)%16]?1.2:3.4);bass(t,r-24+(s===6||s===14?7*(bar%2):0),dur,.75,s%8===6)}
 if(T.cow[s]&&(I>.1)){const n=T.mel[(s+bar*3)%8]+r;cow(t,n,.2)}
 if(T.pad&&s===0)pad(t,r,sp*16,.1);
 if(T.chops&&I>.45&&(s===2||s===6||s===11||s===14)){chop(t,r+12+T.mel[(s+bar)%8],sp*1.8,.09)}
 if(T.siren&&s===0&&bar===3)siren(t,sp*16,.04);
 if(A.slow)return}

/* ---------- sfx ---------- */
function tone(type,f0,f1,dur,v,delay){if(!ctx)return;const t=ctx.currentTime+(delay||0),o=ctx.createOscillator(),g=ctx.createGain();o.type=type;o.frequency.setValueAtTime(f0,t);if(f1)o.frequency.exponentialRampToValueAtTime(f1,t+dur);env(g,t,.004,dur,v);o.connect(g);g.connect(sfxBus);o.start(t);o.stop(t+dur+.03)}
function nz(dur,type,f0,f1,v,delay){if(!ctx)return;const t=ctx.currentTime+(delay||0),s=ctx.createBufferSource(),f=ctx.createBiquadFilter(),g=ctx.createGain();s.buffer=noiseBuf;f.type=type;f.frequency.setValueAtTime(f0,t);if(f1)f.frequency.exponentialRampToValueAtTime(f1,t+dur);env(g,t,.004,dur,v);s.connect(f);f.connect(g);g.connect(sfxBus);s.start(t,Math.random()*.4);s.stop(t+dur+.03)}
const FX={
 jump:()=>{tone('triangle',280,620,.14,.28)},dj:()=>{tone('triangle',420,900,.16,.3);nz(.1,'highpass',3000,6000,.12)},
 land:()=>{tone('sine',120,50,.12,.35);nz(.07,'lowpass',900,300,.2)},slide:()=>{nz(.35,'bandpass',1800,500,.22)},
 dash:()=>{nz(.28,'bandpass',500,4000,.3);tone('sawtooth',160,700,.25,.14)},
 coin:()=>{tone('square',988,1319,.09,.14);tone('square',1319,1760,.12,.12,.06)},gem:()=>{tone('triangle',880,1760,.3,.25);tone('triangle',1320,2640,.3,.18,.08)},
 hit:()=>{nz(.35,'lowpass',2400,120,.6);tone('sawtooth',130,40,.3,.4)},shield:()=>{tone('sine',600,1400,.25,.3);tone('triangle',900,300,.3,.2,.05)},
 power:()=>{[0,4,7,12].forEach((n,i)=>tone('square',mtof(69+n),0,.12,.14,i*.06))},trick:()=>{tone('triangle',500,1000,.2,.25);tone('triangle',750,1500,.2,.2,.07)},
 combo:()=>{tone('square',660,990,.12,.16);tone('square',990,1480,.15,.14,.07)},warn:()=>{for(let i=0;i<3;i++)tone('sawtooth',440,0,.18,.25,i*.22)},
 bosshit:()=>{nz(.5,'lowpass',3000,100,.7);tone('sawtooth',220,35,.45,.5);tone('square',880,110,.3,.25)},bossdie:()=>{for(let i=0;i<7;i++){nz(.4,'lowpass',2500,80,.5,i*.14);tone('sawtooth',200-i*15,30,.4,.3,i*.14)}},
 ui:()=>{tone('triangle',700,900,.06,.18)},buy:()=>{tone('square',800,1200,.08,.15);tone('square',1200,1800,.1,.14,.07);tone('square',1600,2400,.14,.12,.14)},
 deny:()=>{tone('square',200,140,.2,.2)},win:()=>{[0,4,7,12,16,19].forEach((n,i)=>tone('square',mtof(60+n),0,.18,.14,i*.09))},
 lose:()=>{[7,5,2,-2].forEach((n,i)=>tone('sawtooth',mtof(60+n),mtof(56+n),.3,.18,i*.16))},cp:()=>{tone('triangle',660,1320,.2,.25);tone('triangle',990,1980,.25,.2,.1)},
 super:()=>{nz(.7,'bandpass',200,6000,.45);tone('sawtooth',90,720,.7,.3)},ach:()=>{[0,4,7,12].forEach((n,i)=>tone('triangle',mtof(72+n),0,.2,.2,i*.07))},
 whoosh:()=>{nz(.3,'bandpass',900,300,.18)},laser:()=>{tone('sawtooth',1400,300,.25,.14)},explode:()=>{nz(.5,'lowpass',2000,90,.6);tone('sine',90,30,.4,.5)},
 step:()=>{nz(.05,'lowpass',700,300,.08)},tele:()=>{tone('square',900,900,.05,.1)}
};
V.sfx=function(n){if(!A.ok||!ctx||ctx.state!=='running')return;const f=FX[n];if(f)try{f()}catch(e){}};
})();
