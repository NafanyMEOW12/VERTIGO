/* VERTIGO game core: player, parkour physics, input, camera, particles, run lifecycle */
(function(){
'use strict';
const V=window.V,S=Math.sin,Cs=Math.cos,PI=Math.PI,clamp=V.clamp,lerp=V.lerp;
const G=V.G={state:'boot',ts:1,tt:1,t:0,real:0,acts:[],par:[],haz:[],toast:[],fpsN:0,fpsT:0,fps:60};
const GRAV=34,JUMP=11.6,JUMP2=10.3,HW=.33;
let R,W=null,p=null,run=null,menuW=null;
const cam={x:0,y:4,z:-8,tx:0,ty:1.5,tz:6,fov:1.05,roll:0};
const poseP=V.newPose();let chunksOut=[];
G.cam=cam;

/* ---------- environment ---------- */
const envCache={};
function mkEnv(i){if(envCache[i])return envCache[i];const e=V.DIST[i].env;return envCache[i]={top:V.c(e.top),bot:V.c(e.bot),glow:V.c(e.glow),fog:V.c(e.fog),fogN:e.fogN,fogF:e.fogF,light:[.45,.8,-.4],bend:.0005,curve:0}}
V.mkEnv=mkEnv;
function envAt(z){if(!W||!W.endless)return mkEnv(W?W.dist:0);const k=z/1100,i=Math.floor(Math.max(0,k))%6,f=k-Math.floor(k),a=mkEnv(i);if(f<.9||z<0)return a;const b=mkEnv((i+1)%6),t=(f-.9)/.1;
 return{top:V.mixc(a.top,b.top,t),bot:V.mixc(a.bot,b.bot,t),glow:V.mixc(a.glow,b.glow,t),fog:V.mixc(a.fog,b.fog,t),fogN:lerp(a.fogN,b.fogN,t),fogF:lerp(a.fogF,b.fogF,t),light:a.light,bend:a.bend,curve:0}}

/* ---------- particles ---------- */
G.spark=function(x,y,z,n,col,spd,life,size,tile){const q=G.par;for(let i=0;i<n&&q.length<420;i++){const a=Math.random()*PI*2,e=Math.random()*PI-PI/2,s=(.3+Math.random())*spd;q.push({x,y,z,vx:Math.cos(a)*Math.cos(e)*s,vy:Math.sin(e)*s+spd*.2,vz:Math.sin(a)*Math.cos(e)*s,l:life*(.6+Math.random()*.6),m:life,s:size,r:col[0],g:col[1],b:col[2],tile:tile||0,g2:6})}};
function parUpd(dt){const q=G.par;for(let i=q.length-1;i>=0;i--){const a=q[i];a.l-=dt;if(a.l<=0){q[i]=q[q.length-1];q.pop();continue}a.vy-=a.g2*dt;a.x+=a.vx*dt;a.y+=a.vy*dt;a.z+=a.vz*dt}}
function parDraw(sp){const q=G.par;for(let i=0;i<q.length;i++){const a=q[i],f=a.l/a.m;sp.add(a.x,a.y,a.z,a.s*(.4+f*.8),a.tile,a.r,a.g,a.b,f)}}
G.toastMsg=function(t,c){G.toast.push({t,c:c||'',life:1.6});if(G.toast.length>3)G.toast.shift();if(V.ui&&V.ui.toast)V.ui.toast(t,c)};

/* ---------- helpers ---------- */
G.shake=function(a){G.shk=Math.max(G.shk||0,a)};
G.slow=function(sc,dur){G.slowS=sc;G.slowT=dur};
G.flash=function(r,g,b,t){G.fl=[r,g,b];G.flT=t||.2};
G.vib=function(ms){if(V.S.set.haptic&&window.Android&&window.Android.vibrate)try{window.Android.vibrate(ms)}catch(e){}};
G.flow=function(a){if(!run)return;run.flow=clamp(run.flow+a,0,1);p.superCh=clamp(p.superCh+a*(.3+.06*V.S.upg.combo),0,1)};
G.mult=()=>run?1+Math.floor(run.flow*7.99):1;
G.addScore=function(n){if(!run)return;run.score+=Math.round(n*G.mult()*(p.sup>0&&p.supT==='storm'?2:1)*(G.x2T>0?2:1))};
const sup=()=>V.SUPERS[V.HEROES[V.S.hero].sup];

/* ---------- player ---------- */
function newPlayer(z){const S_=V.S,u=S_.upg;return{x:0,y:0,z:z||0,vy:0,lane:1,grounded:true,air:0,jumps:0,slide:0,dashT:0,dashCd:0,wall:0,wallT:0,climb:null,inv:0,hp:3+(u.armor>=2?1:0)+(u.armor>=4?1:0),maxhp:3+(u.armor>=2?1:0)+(u.armor>=4?1:0),
 speed:0,base:17,flipT:0,trickN:0,shield:false,guard:S_.comp===3,sup:0,supT:'',superCh:0,boostT:0,hy:1.75,pound:false,leanT:0,stumble:0,dead:false,lastSafe:[],safeT:0,flowT:0,yawT:0,landT:0,hurtT:0,spinT:0}}
G.player=()=>p;G.run=()=>run;G.world=()=>W;
function dashCd(){const u=V.S.upg.dash;return Math.max(1.2,2.4-.22*u)*(V.S.comp===4?.65:1)}

G.startRun=function(cfg){G.endRun(true);const S_=V.S;V.audio.init();const kind=cfg.kind;let d=cfg.dist||0,len=1e9,cp=0,mode=kind,o={};
 if(kind==='campaign'){len=V.DIST[d].len;cp=400}else if(kind==='chase'){const c=V.CHASES[cfg.idx];d=c.dist;len=c.len;cp=0;mode='chase'}else if(kind==='challenge'){const c=V.CHALL[cfg.idx];d=c.dist}else if(kind==='meme'){d=cfg.dist||0;mode='meme'}
 const seed=(Math.random()*1e9)|0;
 W=new V.World({mode:kind==='meme'?'boss':mode,dist:d,len:kind==='meme'?0:len,cp,seed,secret:kind==='campaign'&&!S_.secrets.includes(d),secretZ:250+Math.floor(Math.random()*500),luck:S_.upg.luck,noBoss:kind==='chase'||kind==='challenge'||kind==='endless'});
 p=newPlayer(0);run={kind,dist:d,idx:cfg.idx,len,score:0,coins:0,flow:0,maxMult:1,tricks:0,wall:0,near:0,dash:0,breaks:0,hits:0,time:0,start:0,cpZ:0,cpN:0,secrets:0,coinAcc:0,done:false,res:null,bossState:'none',meters:0,nohitDist:0,gotToken:false};
 p.base=V.DIST[d].v0;G.W=W;G.p=p;G.run_=run;G.haz.length=0;G.par.length=0;G.t=0;G.nb=0;G.lc=0;G.cpSnap=null;G.ts=1;G.tt=1;G.slowT=0;G.magT=0;G.x2T=0;G.B=null;G.chase=null;G.cine=null;G.shk=0;G.cpPrev=null;G.over=false;
 W.gen(0,200);W.bake(R,0,20,180,99);G.state='play';G.paused=false;
 if(kind==='chase'){G.chase={gap:30,kind:V.CHASES[cfg.idx].kind,t:0,atk:3,len:V.CHASES[cfg.idx].len}}
 if(kind==='challenge'){const c=V.CHALL[cfg.idx];run.ch=c;run.chT=0}
 V.audio.play(kind==='chase'?'chase':'run',V.audio.districtRoot(d));V.audio.intensity=.6;
 if(V.ui)V.ui.onRunStart(run,cfg);G.toastMsg(kind==='campaign'?V.DIST[d].name:kind==='endless'?'Бесконечный забег':kind==='chase'?V.CHASES[cfg.idx].name:kind==='challenge'?V.CHALL[cfg.idx].name:'Секретный мем-босс','big');
 if(kind==='meme'||0){}
};
G.endRun=function(silent){if(W){W.destroy(R);W=null}p=null;run=null;G.B=null;G.chase=null;G.haz.length=0;G.par.length=0;G.W=null;G.p=null;G.run_=null;if(!silent){}};

/* ---------- actions ---------- */
G.act=a=>{if(G.acts.length<8)G.acts.push(a)};
function wallAt(side,z0,z1){const l=W.near(z1);for(const s of l){if(s.k==='w'&&s.side===side&&s.z0<=z0+1&&s.z1>=z1)return s}return null}
function wallAhead(side){const l=W.near(p.z);for(const s of l){if(s.k==='w'&&s.side===side&&s.z1>p.z+2.5&&s.z0<=p.z+7)return s}return null}
function startWall(side,pan){p.wallS=pan||null;p.wall=side;p.wallT=0;p.vy=0;p.climb=null;p.slide=0;p.grounded=false;p.jumps=0;V.sfx('whoosh');G.flow(.05)}
function endWall(hop){const s=p.wall;p.wall=0;p.lane=s<0?0:2;if(hop){p.vy=8;p.jumps=1}}
function laneBlocked(nl){const x=laneX(nl),l=W.near(p.z+.6);for(const s of l){if(s.off||s.dead)continue;if(s.k!=='b'&&s.k!=='g')continue;if(x+.3<=s.x0||x-.3>=s.x1)continue;if(p.z+1.6<s.z0||p.z-.5>s.z1)continue;const t=V.solidTop(s,p.z+.4);if(t>p.y+.4&&(s.y0==null||s.y0<p.hy))return true}return false}
const laneX=V.laneX;
function bump(d){p.leanT=-.3*d;G.shake(.25);V.sfx('step');p.stumble=.2;G.spark(p.x+d*.4,.8,p.z+.4,6,[1,.8,.4],3,.3,.3);p.speed*=.9;run.flow=Math.max(0,run.flow-.08)}
function doAct(a){if(G.state!=='play'||!p||p.dead)return;
 switch(a){
 case'L':case'R':{const d=a==='L'?-1:1;if(p.wall){if(d===-p.wall)endWall(true);return}const nl=p.lane+d;if(nl<0||nl>2){const w=wallAhead(d);if(w)startWall(d,w);return}if(laneBlocked(nl)){bump(d);return}p.lane=nl;p.leanT=.28*d;V.sfx('whoosh');break}
 case'U':{if(p.climb)return;if(p.wall){const s=p.wall;endWall(false);p.vy=JUMP*.95;p.jumps=1;p.lane=1;V.sfx('jump');G.flow(.04);return}
  if(p.grounded||(p.air<.11&&p.jumps===0)){p.vy=JUMP;p.jumps=1;p.grounded=false;p.slide=0;V.sfx('jump');G.spark(p.x,p.y+.1,p.z,6,[.8,.85,1],3,.35,.4)}
  else if(p.jumps<2){p.vy=JUMP2*(1+.05*V.S.upg.jump);p.jumps=2;V.sfx('dj');G.spark(p.x,p.y+.2,p.z,10,V.heroColors(V.S.hero,V.S.skin[V.S.hero]).g,4,.4,.5,1)}break}
 case'D':{if(p.wall){endWall(false);return}if(p.grounded){if(p.slide<=0){p.slide=.75;V.sfx('slide')}}else{p.vy=Math.min(p.vy,-22);p.pound=true}break}
 case'dash':dash();break;case'trick':trick();break;case'super':superGo();break}}
function dash(){if(p.dashT>0||p.dashCd>0||p.climb)return;p.dashT=.32+.03*V.S.upg.dash;p.dashCd=dashCd();run.dash++;V.S.stat.dash++;V.sfx('dash');G.shake(.15);G.spark(p.x,p.y+1,p.z,12,[.6,.95,1],8,.4,.5);if(G.B&&G.bossStrike)G.bossStrike()}
function trick(){if(p.grounded||p.y<1.1||p.flipT>0||p.wall||p.climb)return;p.flipT=.6;p.spinT=Math.random()<.5?0:1;run.tricks++;V.S.stat.tricks++;G.addScore(100);G.flow(.2);V.sfx('trick');G.toastMsg('ТРЮК +'+100*G.mult(),'gold');G.spark(p.x,p.y+1,p.z,10,[1,.9,.4],5,.5,.5,2);if(p.y>3.0){G.slow(.5,.45)}}
function superGo(){if(p.superCh<1||p.sup>0||p.dead)return;const s=sup(),t=V.HEROES[V.S.hero].sup;p.sup=s.dur;p.supT=t;p.superCh=0;p.inv=Math.max(p.inv,.4);run.supers=(run.supers||0)+1;V.S.stat.supers++;V.sfx('super');G.shake(.5);G.flash(.5,.8,1,.35);G.spark(p.x,p.y+1,p.z,40,[.5,.9,1],12,.7,.7,2);G.toastMsg(s.name.toUpperCase(),'big');if(t==='warp')G.slow(.6,s.dur)}

/* ---------- damage ---------- */
G.hurt=function(src,soft){if(!p||p.dead||p.inv>0||(p.sup>0&&(p.supT==='phase'||p.supT==='nova')))return false;
 if(p.guard){p.guard=false;p.inv=1;V.sfx('shield');G.toastMsg('Страж-бот принял удар','blue');G.spark(p.x,p.y+1,p.z,16,[.4,.7,1],6,.5,.6);G.shake(.3);return false}
 if(p.shield){p.shield=false;p.inv=1.2;V.sfx('shield');G.toastMsg('Щит спас!','blue');G.spark(p.x,p.y+1,p.z,16,[.4,.7,1],6,.5,.6);G.shake(.3);return false}
 if(soft){p.stumble=.5;p.speed*=.6;G.shake(.3);run.flow*=.5;V.sfx('step');return true}
 p.hp--;run.hits++;run.nohitDist=0;p.inv=1.9;p.speed=Math.min(p.speed,p.base*.55);p.hurtT=.5;run.flow=0;G.shake(.9);G.flash(1,.2,.2,.3);G.vib(60);V.sfx('hit');G.spark(p.x,p.y+1,p.z,20,[1,.4,.3],7,.6,.6);
 if(G.chase)G.chase.gap-=6;
 if(p.hp<=0){die()}return true};
function die(){if(p.dead)return;p.dead=true;G.slow(.25,1.4);V.sfx('lose');G.flash(1,.1,.1,.5);G.spark(p.x,p.y+1,p.z,30,[1,.4,.3],9,.9,.8);setTimeout(()=>{if(G.run_===run&&run&&!run.done)finish(false)},1000)}
G.die=die;

/* ---------- main update ---------- */
G.update=function(dt){
 if(G.state==='play'&&p&&!G.paused){updPlay(dt)}
 if(G.state==='menu'||G.state==='garage'||G.state==='cine'){G.real+=dt}
};
function groundTop(x,z,y){let f=-1e9,sup_=null;const l=W.near(z);for(let i=0;i<l.length;i++){const s=l[i];if((s.k!=='g'&&s.k!=='b')||s.off||s.dead)continue;if(x+HW<=s.x0||x-HW>=s.x1)continue;if(z+.2<s.z0||z-.2>s.z1)continue;const t=V.solidTop(s,z);if(t<=y+.45&&t>f){f=t;sup_=s}}p.sup_=sup_;return f}
function updPlay(dtR){
 /* time scale */
 if(G.slowT>0){G.slowT-=dtR;G.tt=G.slowS}else G.tt=p.dead?.25:1;G.ts+=(G.tt-G.ts)*Math.min(1,dtR*9);const dt=Math.min(dtR,.05)*G.ts;
 V.audio.setSlow(G.ts<.8);
 G.t+=dt;run.time+=dtR;if(run.ch&&!run.chDone)run.chT+=dt;
 for(const a of G.acts.splice(0))doAct(a);
 const D=V.DIST[W.endless?W.dAt(p.z):run.dist],prog=W.endless?clamp(p.z/4200,0,1):clamp(p.z/Math.max(1,run.len),0,1);
 if(!G.B||G.B.state==='enter')p.base=lerp(D.v0,D.v1,prog);else p.base=D.v0+1;
 /* timers */
 p.phase=(p.phase||0)+dt*(10+(p.speed/Math.max(1,p.base))*5);p.inv=Math.max(0,p.inv-dt);p.dashCd=Math.max(0,p.dashCd-dt);p.dashT=Math.max(0,p.dashT-dt);p.slide=Math.max(0,p.slide-dt);p.flipT=Math.max(0,p.flipT-dt);p.boostT=Math.max(0,p.boostT-dt);p.stumble=Math.max(0,p.stumble-dt);p.hurtT=Math.max(0,p.hurtT-dt);
 p.leanT*=Math.max(0,1-dt*8);G.magT=Math.max(0,(G.magT||0)-dt);G.x2T=Math.max(0,(G.x2T||0)-dt);if(p.sup>0){p.sup-=dt;if(p.sup<=0){p.sup=0;p.inv=Math.max(p.inv,.8);if(p.supT==='warp')G.slowT=0}}
 run.flow=Math.max(0,run.flow-dt*(.075-.006*V.S.upg.combo));const m=G.mult();if(m>run.maxMult){run.maxMult=m;if(m>V.S.stat.combo)V.S.stat.combo=m;if(m>=3)V.sfx('combo')}
 /* speed */
 let tgt=p.base;if(p.dashT>0)tgt=p.base*2.0;else if(p.boostT>0)tgt=p.base*1.7;if(p.wall)tgt*=1.05;if(p.sup>0&&p.supT!=='warp')tgt*=1.12;if(p.stumble>0)tgt*=.7;
 if(G.cine)tgt=0;
 if(p.speed<tgt)p.speed=Math.min(tgt,p.speed+(p.dashT>0?200:11)*dt);else p.speed=Math.max(tgt,p.speed-45*dt);
 if(p.climb)p.speed*=.35;
 /* world */
 W.gen(p.z,200);W.upd(G.t,dt,p.z);if(!G.nb||G.t-G.nb>.12){G.nb=G.t;W.bake(R,p.z,20,V.fwdBake(),1)}
 /* lateral */
 if(p.wall){const wx=p.wall*3.0;p.x+=(wx-p.x)*Math.min(1,dt*14)}else{const tx=laneX(p.lane),d=tx-p.x,st=26*V.S.set.sens*dt;p.x+=Math.abs(d)<st?d:Math.sign(d)*st}
 /* forward */
 const oz=p.z;p.z+=p.speed*dt;run.meters=p.z;
 if(p.dashT>0&&G.t%.03<dt)G.spark(p.x,p.y+.9,p.z-.5,2,[.5,.95,1],2,.3,.6,3);
 p.hy=p.y+(p.slide>0?.8:1.75);
 /* wall run */
 if(p.wall){p.wallT+=dt;p.vy=0;p.y+=(1.8-p.y)*Math.min(1,dt*9);p.hy=p.y+1.6;const dz=p.speed*dt;run.wall+=dz;V.S.stat.wall+=dz;run.score+=dz*G.mult()*1.5;G.flow(dt*.11);
  if(!p.wallS||p.z>p.wallS.z1-.4){endWall(true);G.toastMsg('Стена пройдена!','gold')}
  if(G.t%.05<dt)G.spark(p.x+p.wall*.4,p.y+.3,p.z-.6,1,[.6,.9,1],3,.3,.4,3)}
 else if(p.climb){const c=p.climb;c.t+=dt;const u=clamp(c.t/c.dur,0,1);p.y=lerp(c.y0,c.ty,u*u*(3-2*u));p.vy=0;p.z=Math.max(p.z,oz);if(u>=1){p.y=c.ty;p.z=c.zt;p.climb=null;p.grounded=true;p.jumps=0;V.sfx('land');G.flow(.1);G.addScore(60);G.spark(p.x,p.y,p.z,8,[.8,.9,1],3,.4,.4)}}
 else{/* vertical */
  p.vy-=GRAV*dt*(p.pound?1.4:1);const oy=p.y;p.y+=p.vy*dt;const fl=groundTop(p.x,p.z,oy);
  if(p.vy<=0&&p.y<=fl+.001&&fl>-1e8){if(!p.grounded){const fh=Math.abs(p.vy);if(fh>9){V.sfx('land');G.spark(p.x,fl+.05,p.z,8,[.8,.85,1],3,.4,.5);if(fh>20){G.shake(.4);if(p.pound){p.slide=.6}}}p.landT=.2}p.y=fl;p.vy=0;p.grounded=true;p.jumps=0;p.air=0;p.pound=false;const s=p.sup_;if(s&&s.collapse&&s.state===0){s.state=1;s.tt=0}}
  else{if(p.grounded&&fl>-1e8&&p.y-fl<.4&&p.vy<=0){p.y=fl}else{p.grounded=false;p.air+=dt}}
  if(fl<-1e8&&p.grounded){p.grounded=false}
  /* safe positions */
  if(p.grounded&&p.sup_&&p.sup_.k==='g'&&!p.sup_.collapse&&!p.sup_.elev&&!p.sup_.ramp&&p.sup_.z1-p.sup_.z0>4)p.lastG={z:p.z,y:p.y,lane:p.lane,z0:p.sup_.z0};
  if(p.y<-9)fallDeath()}
 /* collisions */
 if(!p.climb)collide(dt);
 /* pickups */
 pickups(dt);
 /* near-miss */
 nearMiss();
 /* stats & checkpoints */
 const adv=p.z-oz;V.S.stat.dist+=adv;run.nohitDist+=adv;if(W.endless&&p.z>V.S.best.endless)V.S.best.endless=Math.floor(p.z);
 run.score+=adv*G.mult()*.5*(G.x2T>0?2:1);
 if(G.chase)chaseUpd(dt);if(G.B&&G.bossUpd)G.bossUpd(dt);if(G.hazUpd)G.hazUpd(dt);
 challengeUpd();
 /* campaign boss trigger */
 if(run.kind==='campaign'&&W.bossGate!=null&&!G.B&&run.bossState==='none'&&p.z>W.bossGate+6&&G.bossStart){run.bossState='fight';G.bossStart(V.DIST[run.dist].boss)}
 if(run.kind==='meme'&&!G.B&&run.bossState==='none'&&p.z>40&&G.bossStart){run.bossState='fight';G.bossStart(6)}
 if(run.kind==='chase'&&p.z>=run.len&&!run.done)finish(true);
 /* fx */
 skinFx(dt);parUpd(dt);G.shk=Math.max(0,(G.shk||0)-dt*2.2);if(G.flT>0)G.flT-=dtR;
 comp_(dt);
 G.updCam(dtR);if(V.ui)V.ui.hud(G,run,p,W)}

function fallDeath(){if(p.hp<=1){p.hp=0;G.hurt;die();return}p.hp--;run.hits++;run.nohitDist=0;run.flow=0;G.flash(1,.2,.2,.3);G.vib(60);V.sfx('hit');G.shake(.7);
 const g=p.lastG||{z:Math.max(0,p.z-25),y:0,lane:1,z0:0};p.z=Math.max(g.z0+1.5,g.z-4);p.y=g.y+.1;p.lane=g.lane;p.x=laneX(p.lane);p.vy=0;p.inv=2.4;p.speed=p.base*.7;p.wall=0;p.climb=null;p.grounded=false;if(G.chase)G.chase.gap-=6;G.toastMsg('Падение! Возвращаю назад','red')}

function collide(dt){const l=W.near(p.z),ph=p.hy,py=p.y;
 for(let i=0;i<l.length;i++){const s=l[i];if(s.off||s.dead)continue;
  if(s.k==='w')continue;
  if(p.x+HW<=s.x0||p.x-HW>=s.x1)continue;
  if(s.k==='hz'){if(p.z+.3>s.z0&&p.z-.3<s.z1&&s.test(p,G.t)&&G.hurt(s)){}continue}
  if(p.z+.3<=s.z0||p.z>=s.z1-.05)continue;
  if(s.k==='bm'){if(ph>s.y0+.02&&py<s.y1){if(p.sup>0&&p.supT==='nova'){s.dead=true;G.spark(p.x,1.3,p.z+1,14,[1,.5,.3],8,.6,.6)}else if(G.hurt(s)){}}continue}
  const tt=V.solidTop(s,p.z);if(py>=tt-.28)continue;if(s.y0!=null&&s.k==='b'&&ph<=s.y0)continue;
  if(p.wall)continue;
  if(s.brk&&(p.dashT>0||p.boostT>0||p.sup>0)){breakObj(s);continue}
  if(p.sup>0&&p.supT==='nova'&&s.k!=='g'){s.dead=true;G.spark(p.x,1.3,p.z+1,14,[1,.5,.3],8,.6,.6);continue}
  const rise=tt-py;
  if(p.inv>0||p.sup>0){if(s.brk){s.dead=true;s.off=true;G.spark((s.x0+s.x1)/2,1.6,s.z0,18,[.6,.95,1],7,.6,.6)}else if(rise>.2&&rise<=3.9){p.climb={t:0,dur:.26,y0:py,ty:tt,zt:Math.max(p.z,s.z0+.5),s};p.slide=0}continue}
  if(s.ledge&&rise<=(p.grounded?1.4:2.2)&&rise>.2){p.climb={t:0,dur:.38,y0:py,ty:tt,zt:Math.max(p.z,s.z0+.5),s};p.slide=0;V.sfx('whoosh');continue}
  if(G.hurt(s)){if(s.brk){s.dead=true;s.off=true;G.spark((s.x0+s.x1)/2,1.6,s.z0,24,[.6,.95,1],8,.7,.6)}}}}
function breakObj(s){s.dead=true;s.off=true;run.breaks++;V.S.stat.breaks++;G.addScore(75);G.flow(.15);V.sfx('explode');G.shake(.45);G.vib(25);const x=(s.x0+s.x1)/2;G.spark(x,1.6,s.z0,30,[.6,.95,1],9,.8,.7,2);G.spark(x,1,s.z0,16,[1,1,1],6,.6,.4);G.toastMsg('РАЗБИТО +'+75*G.mult(),'gold')}

function nearMiss(){const l=W.near(p.z);for(let i=0;i<l.length;i++){const s=l[i];if(s._nm||s.dead||s.off||(s.k!=='b'&&s.k!=='bm'))continue;if(s.k==='b'&&s.y1-s.y0<.8)continue;if(p.z<s.z1||p.z-s.z1>1.5)continue;if(p.inv>0)continue;
  const dx=p.x<(s.x0+s.x1)/2?s.x0-p.x:p.x-s.x1;if(dx>.2&&dx<1.05&&p.y<s.y1-.2){s._nm=1;run.near++;V.S.stat.near++;G.flow(.12);G.addScore(50);if(V.S.comp===2){G.flow(.08);G.addScore(60)}G.toastMsg('ВПРИТИРКУ +'+50*G.mult(),'gold');G.spark(p.x,1,p.z,5,[1,1,.6],4,.3,.3)}}}

function pickups(dt){const mag=(V.S.comp===1?6:1.3)+V.S.upg.magnet*1.1+(G.magT>0?10:0)+(p.sup>0&&p.supT==='storm'?16:0);const a=Math.floor((p.z-3)/V.CH),b=Math.floor((p.z+mag+2)/V.CH);
 for(let i=a;i<=b;i++){const c=W.chunks.get(i);if(!c)continue;
  for(const k of c.coins){if(k.got)continue;const dz=k.z-p.z;if(dz<-1.5||dz>mag+1)continue;const dx=k.x-p.x,dy=k.y-(p.y+.9);if(dx*dx+dy*dy+dz*dz<(mag>2?mag*mag:1.5)){k.got=1;const v=k.v*(1+.08*V.S.upg.luck+(V.S.comp===5?.2:0));run.coinAcc+=v;const w=Math.floor(run.coinAcc);if(w>0){run.coinAcc-=w;run.coins+=w;V.S.coins+=w;V.S.stat.coins+=w;if(run.ch&&run.ch.g==='coins')run.chC=(run.chC||0)+w}G.addScore(10);G.flow(.012);if(G.t-(G.lc||0)>.04){G.lc=G.t;V.sfx('coin')}G.spark(k.x,k.y,k.z,2,[1,.85,.3],2,.25,.3)}}
  for(const it of c.items){if(it.got&&it.t!=='cp')continue;const dz=it.z-p.z;if(Math.abs(dz)>2)continue;
   if(it.t==='cp'){if(!it.hit&&p.z>=it.z){it.hit=1;run.cpZ=it.z;run.cpN++;p.hp=Math.min(p.maxhp,p.hp+1);V.sfx('cp');G.toastMsg('КОНТРОЛЬНАЯ ТОЧКА','blue');G.flash(.4,.9,1,.25);G.cpSnap={z:it.z,hp:p.hp,coins:run.coins}}continue}
   const dx=it.x-p.x,dy=it.y-(p.y+.8);if(dx*dx+dy*dy+dz*dz>(it.t==='padj'||it.t==='padb'?1.9:2.4))continue;
   if(it.t==='padj'){if(p.y<it.y+.8){it.got=0;if(!it.cd||G.t>it.cd){it.cd=G.t+.5;p.vy=19;p.grounded=false;p.jumps=1;p.wall=0;V.sfx('jump');G.spark(it.x,it.y+.3,it.z,14,[1,.6,.2],6,.5,.5,2)}}continue}
   if(it.t==='padb'){if(!it.cd||G.t>it.cd){it.cd=G.t+1;p.boostT=1.6;V.sfx('dash');G.spark(it.x,it.y+.3,it.z,14,[.3,1,.6],6,.5,.5,2);G.toastMsg('УСКОРЕНИЕ!','gold')}continue}
   it.got=1;V.sfx(it.t==='gem'?'gem':'power');
   switch(it.t){case'magnet':G.magT=9;G.toastMsg('МАГНИТ','gold');break;case'shield':p.shield=true;G.toastMsg('ЩИТ','blue');break;case'x2':G.x2T=10;G.toastMsg('ОЧКИ x2','gold');break;case'boost':p.boostT=2.2;p.inv=Math.max(p.inv,1);G.toastMsg('БУСТ','gold');break;
    case'heal':p.hp=Math.min(p.maxhp,p.hp+1);G.toastMsg('+1 целостность','green');break;case'gem':run.coins+=50;V.S.coins+=50;V.S.stat.coins+=50;G.addScore(250);G.flow(.15);G.toastMsg('КРИСТАЛЛ +50','gold');if(run.ch&&run.ch.g==='coins')run.chC=(run.chC||0)+50;break;
    case'token':{run.secrets++;run.gotToken=true;if(!V.S.secrets.includes(it.tid)){V.S.secrets.push(it.tid);G.toastMsg('СЕКРЕТНЫЙ ТОКЕН НАЙДЕН!','big');if(V.S.secrets.length>=6&&!V.S.meme){V.S.meme=true;G.toastMsg('ОТКРЫТ СЕКРЕТНЫЙ БОСС!','big')}V.persist(true);V.checkAch()}break}}
   G.spark(it.x,it.y,it.z,18,[1,1,.8],6,.6,.6,2);G.flow(.04)}}}

function skinFx(dt){const fx=V.heroColors(V.S.hero,V.S.skin[V.S.hero]).fx;if(fx==='none'||p.dead)return;if(Math.random()>dt*60*.4)return;const C=V.heroColors(V.S.hero,V.S.skin[V.S.hero]);const x=p.x,y=p.y+.15,z=p.z-.3;
 switch(fx){case'sparks':G.spark(x,y,z,1,[1,.4,.8],2,.4,.35);break;case'fire':G.spark(x,y+.2,z,1,[1,.55,.1],2.5,.5,.55,0);break;case'ice':G.spark(x,y+.3,z,1,[.6,.9,1],1.5,.6,.5);break;case'glitch':G.spark(x+(Math.random()-.5)*.6,y+Math.random()*1.6,z,1,[.2,1,.8],1,.25,.3,2);break;
  case'rainbow':{const h=(G.t*1.5)%1,c=V.hsl2rgb(h,1,.6);G.spark(x,y+.4,z,1,c,1.5,.5,.5)}break;case'gold':G.spark(x,y+.6,z,1,[1,.85,.3],1.5,.6,.35,2);break;case'shadow':G.spark(x,y+.6,z,1,[.6,.3,1],1.2,.7,.5)}}

/* ---------- companion ---------- */
let comp={x:0,y:2,z:0};
function comp_(dt){if(!V.S.comp||!p)return;const tx=p.x-1.3,ty=p.y+2.3,tz=p.z-.8;comp.x+=(tx-comp.x)*Math.min(1,dt*6);comp.y+=(ty-comp.y)*Math.min(1,dt*6);comp.z+=(tz-comp.z)*Math.min(1,dt*9)}

/* ---------- chase ---------- */
function chaseUpd(dt){const c=G.chase,prog=clamp(p.z/c.len,0,1);const ps=p.base*(.97+.06*prog)+.3;c.gap+=(p.speed-ps)*dt-.2*dt;c.gap=Math.min(c.gap,42);c.t+=dt;
 c.atk-=dt;if(c.atk<=0&&G.haz&&G.hazAdd&&!G.cine){c.atk=4.5-prog*1.5+Math.random()*2;const n=1+Math.floor(prog*2);const ls=[0,1,2].sort(()=>Math.random()-.5).slice(0,n);G.hazAdd('blast',ls,1.3)}
 if(c.gap<=3.5&&!p.dead&&!p.inv){p.hp=0;V.sfx('hit');die()}else if(c.gap<10&&G.t%1<dt)G.toastMsg('ОН РЯДОМ! ГАЗУ!','red')}

/* ---------- challenges ---------- */
function challengeUpd(){const c=run.ch;if(!c||run.done)return;let ok=false,fail=false;
 switch(c.g){case'coins':ok=(run.chC||0)>=c.v;break;case'tricks':ok=run.tricks>=c.v;break;case'nohit':ok=run.nohitDist>=c.v;break;case'wall':ok=run.wall>=c.v;break;case'near':ok=run.near>=c.v;break;case'dist':ok=p.z>=c.v;break;case'combo':ok=run.maxMult>=c.v;break;case'breaks':ok=run.breaks>=c.v;break}
 if(c.lim&&run.chT>c.lim&&!ok)fail=true;if(ok){run.chDone=true;finish(true)}else if(fail)finish(false)}

/* ---------- finish ---------- */
function finish(win){if(!run||run.done)return;run.done=true;run.win=win;const S_=V.S;let bonus=0,newBest=false;const dm=Math.floor(p.z);
 S_.stat.runs++;S_.stat.score=Math.max(S_.stat.score,Math.floor(run.score));S_.stat.time+=run.time;
 if(run.kind==='campaign'&&win){bonus=300+run.dist*120;if(!S_.done.includes(run.dist)){S_.done.push(run.dist);bonus+=400}if(run.hits===0){S_.stat.flawless++;bonus+=300;run.flawless=true}
  S_.best.campaign[run.dist]=Math.max(S_.best.campaign[run.dist]||0,Math.floor(run.score));const medal=run.hits===0?3:run.hits<=2?2:1;S_.medals[run.dist]=Math.max(S_.medals[run.dist]||0,medal);run.medal=medal;
  if(!S_.bossKilled.includes(V.DIST[run.dist].boss)){S_.bossKilled.push(V.DIST[run.dist].boss);S_.stat.bosses++}}
 else if(run.kind==='meme'&&win){bonus=1500;S_.memeKilled=true}
 else if(run.kind==='endless'){const prev=S_.best.endless;newBest=dm>=prev;S_.best.endless=Math.max(prev,dm);bonus=Math.floor(dm/20)}
 else if(run.kind==='chase'){const idx=run.idx;S_.best.chase[idx]=Math.max(S_.best.chase[idx]||0,dm);if(win){S_.stat.chases++;bonus=250+idx*100}}
 else if(run.kind==='challenge'&&win){const ch=V.CHALL[run.idx],key=run.idx;if(!S_.chall[key]){S_.chall[key]=1;bonus=ch.rew}else bonus=Math.floor(ch.rew*.15)}
 run.bonus=bonus;run.coins+=bonus;S_.coins+=bonus;S_.stat.coins+=bonus;
 V.persist(true);const newAch=[],prevAch=V.onAch;V.onAch=a=>newAch.push(a);V.checkAch();V.onAch=prevAch;run.ach=newAch;run.newBest=newBest;run.dm=dm;
 G.state='result';V.audio.play(win?'win':'menu');V.sfx(win?'win':'lose');
 if(V.ui)V.ui.showResult(run,win)}
G.finish=finish;
G.retryCp=function(){if(!run||!p)return false;const S_=V.S,cost=40*(1+run.cpN);const cz=run.cpZ;if(run.kind!=='campaign'||p.dead===false)return false;if(!V.spend(cost))return false;
 run.done=false;p.dead=false;p.hp=Math.max(2,Math.ceil(p.maxhp/2));p.z=cz;p.y=0;p.vy=0;p.lane=1;p.x=0;p.inv=2.5;p.speed=p.base;p.wall=0;p.climb=null;G.haz.length=0;G.B=null;run.bossState=cz>=(W.bossGate||1e9)?'none':run.bossState;if(W.bossGate!=null&&cz<W.bossGate)run.bossState='none';
 G.state='play';G.paused=false;G.slowT=0;V.audio.play('run',V.audio.districtRoot(run.dist));if(V.ui)V.ui.onRunStart(run,{});return true};

/* ---------- camera ---------- */
G.updCam=function(dtR){if(G.cine&&G.cine.cam){G.cine.cam(cam);return}
 const sp=p.speed/Math.max(1,p.base);const k=Math.min(1,dtR*7);
 const slide=p.slide>0?-.7:0;let cx=p.x*.62,cy=3.55+p.y*.55+slide+(p.wall?.6:0),cz=p.z-7.2-(p.dashT>0?1.3:0);
 cam.x+=(cx-cam.x)*k;cam.y+=(cy-cam.y)*k;cam.z=cz;
 cam.tx=p.x*.85;cam.ty=1.35+p.y*.5;cam.tz=p.z+10;
 const fov=1.0+.1*(sp-1)+(p.dashT>0?.2:0)+(p.boostT>0?.12:0)+(p.sup>0?.1:0)+(G.ts<.8?-.12:0);cam.fov+=(fov-cam.fov)*Math.min(1,dtR*6);
 const roll=-(p.x-cam.x)*.012+p.wall*.2+p.leanT*.08;cam.roll+=(roll-cam.roll)*Math.min(1,dtR*6)};
const SHAKE=()=>V.S.set.shake?1:0;

/* ---------- drawing ---------- */
V.fwdBake=()=>V.quality==='low'?132:V.quality==='med'?190:240;
function drawPlayer(m,sp){const S_=V.S,t=G.t;let st='run',o={sp:p.speed/Math.max(1,p.base)-.8,side:p.wall,lean:p.leanT*.35,flip:0};
 if(p.dead)st='hit';else if(p.climb)st='climb';else if(p.wall)st='wall';else if(p.dashT>0)st='dash';else if(p.slide>0)st='slide';else if(!p.grounded)st=p.jumps>1?'jump':(p.vy<-4?'fall':'jump');else if(p.hurtT>0)st='hit';
 if(p.flipT>0){const u=1-p.flipT/.6;if(p.spinT)o.spin=u*PI*2;else o.flip=-u*PI*2}
 if(p.landT>0)p.landT-=.016;
 V.pose(poseP,st,p.speed>1?t:t*0+G.real,o);
 poseP.ph=p.phase||0;
 let yaw=-p.leanT*.8;poseP.yaw+=yaw;
 const flick=p.inv>0&&p.hurtT>0?p.inv:0;
 V.drawHero(m,S_.hero,S_.skin[S_.hero],S_.acc,poseP,p.x,p.y,p.z,{flick});
 if(p.sup>0){const sc=p.supT==='phase'?[.6,.4,1]:p.supT==='nova'?[1,.6,.3]:p.supT==='storm'?[1,.9,.3]:[.4,.9,1];sp.add(p.x,p.y+1,p.z,3.6+S(t*10)*.3,0,sc[0],sc[1],sc[2],.7);sp.add(p.x,p.y+1,p.z,4.5,1,sc[0],sc[1],sc[2],.4+.3*S(t*12))}
 if(p.shield)sp.add(p.x,p.y+1,p.z,3.0,1,.3,.6,1,.7+.2*S(t*8));
 const C=V.heroColors(S_.hero,S_.skin[S_.hero]);if(p.dashT>0||p.boostT>0){for(let i=1;i<5;i++)sp.add(p.x,p.y+1,p.z-i*.9,1.4-i*.18,3,C.g[0],C.g[1],C.g[2],.5-i*.09)}
 if(S_.acc===3&&!p.dead)sp.add(p.x+.14,p.y+.9,p.z-.5,.6+Math.random()*.3,0,1,.6,.2,.8)}
function drawChaser(m,sp){const c=G.chase,z=p.z-c.gap,t=G.t;const th=V.DIST[run.dist].th;
 switch(c.kind){
 case'drones':for(let i=0;i<4;i++){const x=S(t*1.7+i*1.9)*3.2,y=2+S(t*2.3+i)*.8;m.push();m.tr(x,y,z-i*2.2);m.box(0,0,0,1.2,.5,.9,V.c('#232842'),.1);m.box(0,0,.5,.5,.2,.04,[1,.2,.3],1.8);for(const s of[-1,1]){m.push();m.tr(s*.8,.1,0);m.ry(t*28);m.box(0,0,0,.8,.04,.1,V.c('#8a93b0'));m.pop()}m.pop();sp.add(x,y,z-i*2.2+.6,1.6,0,1,.2,.3,.8)}break;
 case'train':m.push();m.tr(0,0,z-14);m.box(0,1.9,7,5.2,3.6,14,V.c('#2c3a46'),.05);m.box(0,3.8,7,5.3,.2,14,V.c(th.acc),.9);m.box(0,2.6,14.1,3.4,1,.1,[1,.9,.6],1.8);m.box(-1.5,1.2,14.1,.6,.6,.1,[1,.9,.6],2);m.box(1.5,1.2,14.1,.6,.6,.1,[1,.9,.6],2);m.pop();sp.add(0,2.4,z,12,0,1,.9,.6,.6);break;
 case'heli':m.push();m.tr(S(t*.8)*2.5,5.5+S(t*1.5),z-6);m.box(0,0,0,2.6,1.6,4,V.c('#232842'),.1);m.box(0,0,2.1,1.6,.9,.1,[1,.2,.3],1.5);m.box(0,.95,0,.2,.5,.2,V.c('#8a93b0'));m.push();m.tr(0,1.25,0);m.ry(t*30);m.box(0,0,0,9,.06,.4,V.c('#8a93b0'));m.pop();m.pop();sp.add(S(t*.8)*2.5,5,z-4,10,0,.9,.95,1,.35);break;
 default:m.push();m.tr(0,0,z-10);m.box(0,1.2,0,4.6,1.8,8,V.c('#333a46'),.05);m.box(0,2.5,0,2.8,1,3,V.c('#2a303c'),.05);m.box(0,2.5,3.2,.4,.4,3.5,V.c('#1a1e28'));m.box(0,1.2,4.1,3,.6,.1,[1,.2,.2],1.8);m.box(-2.5,.6,0,.8,1.2,8.4,V.c('#1a1e28'));m.box(2.5,.6,0,.8,1.2,8.4,V.c('#1a1e28'));m.pop();sp.add(0,1.2,z-5.5,8,0,1,.3,.2,.5)}}

G.render=function(){const t=G.t,m=R.dyn,sp=R.spr;m.reset();sp.reset();R.time=G.real+G.t;let env,list=chunksOut;
 if(G.state==='play'||G.state==='result'){if(!W||!p)return;env=envAt(p.z);const fw=V.fwdBake();W.drawDyn(m,sp,G.t,p.z,fw-20);list=W.meshes(p.z,40,fw,chunksOut);
  if(!p.dead||G.state==='result')drawPlayer(m,sp);if(V.S.comp)V.drawComp(m,V.S.comp,t,comp.x,comp.y,comp.z);
  if(G.chase)drawChaser(m,sp);if(G.B&&G.bossDraw)G.bossDraw(m,sp,t);if(G.hazDraw)G.hazDraw(m,sp,t);parDraw(sp);
  /* speed streaks */
  if(p.speed>p.base*1.2){for(let i=0;i<6;i++){const a=i*2.1+t*3;sp.line(p.x+S(a)*4,p.y+1+Cs(a*1.3)*2,p.z+4+((t*60+i*13)%30),p.x+S(a)*4,p.y+1+Cs(a*1.3)*2,p.z+9+((t*60+i*13)%30),.08,3,.7,.9,1,.5,cam.x,cam.y,cam.z)}}
  R.render(cam,env,list,{shake:SHAKE()*(G.shk||0)*.6,flash:G.flT>0?[G.fl[0]*G.flT*1.2,G.fl[1]*G.flT*1.2,G.fl[2]*G.flT*1.2]:null})}
 else if(G.state==='menu'||G.state==='garage'||G.state==='cine'){G.renderMenu(m,sp)}};

G.renderMenu=function(m,sp){const t=G.real;if(!menuW)return;const mw=menuW;env=mkEnv(G.menuDist||0);var env;
 mw.drawDyn(m,sp,t,25,150);list=mw.meshes(25,40,200,chunksOut);var list;
 const S_=V.S;
 if(G.state==='cine'&&G.cine){G.cine.draw&&G.cine.draw(m,sp,t);G.cine.cam&&G.cine.cam(cam)}
 else if(G.state==='garage'||G.state==='menu'){const gx=G.gv||{};const hero=gx.hero==null?S_.hero:gx.hero,skin=gx.skin==null?S_.skin[hero]:gx.skin,acc=gx.acc==null?S_.acc:gx.acc,cp=gx.comp==null?S_.comp:gx.comp;
  V.pose(poseP,gx.run?'run':'idle',t,{sp:.5});poseP.yaw+=gx.spin!=null?gx.spin:PI+(G.state==='garage'?S(t*.5)*.9:-.35+S(t*.3)*.2);
  m.box(0,-.1,22,3.6,.2,3.6,V.c('#10142a'),.1);m.prism(0,-.05,22,1.15,1.15,.06,16,V.c(V.DIST[G.menuDist||0].th.acc),.8);
  V.drawHero(m,hero,skin,acc,poseP,0,.05,22,{});if(cp)V.drawComp(m,cp,t,1.8,1.9,21.5);
  const C=V.heroColors(hero,skin);sp.add(0,.12,22,3.4,1,C.g[0],C.g[1],C.g[2],.55);sp.add(0,1.1,22,3.6,0,C.g[0]*.5,C.g[1]*.5,C.g[2]*.5,.2);
  if(C.fx!=='none'&&Math.random()<.5){G.spark(S(t*3)*.4,.2+Math.random()*1.6,21.6,1,C.fx==='fire'?[1,.5,.1]:C.fx==='ice'?[.6,.9,1]:C.fx==='gold'?[1,.85,.3]:C.fx==='shadow'?[.6,.3,1]:C.fx==='glitch'?[.2,1,.8]:C.fx==='rainbow'?V.hsl2rgb(t%1,1,.6):[1,.4,.8],1.2,.6,.4)}
  parUpd(.016);parDraw(sp);
  const cz=G.state==='menu'?{x:-1.7,y:1.4,z:17.3,tx:1.15,ty:1.05,tz:22}:{x:.5,y:1.5,z:17.5,tx:-1.05,ty:1.05,tz:22};
  cam.x+=(cz.x-cam.x)*.1;cam.y+=(cz.y-cam.y)*.1;cam.z+=(cz.z-cam.z)*.1;cam.tx=cz.tx;cam.ty=cz.ty;cam.tz=cz.tz;cam.fov=.9;cam.roll=0}
 R.render(cam,env,list,{})};
G.buildMenuWorld=function(d){if(menuW){menuW.destroy(R);menuW=null}G.menuDist=d||0;menuW=new V.World({mode:'campaign',dist:d||0,len:1e9,seed:12345});menuW.first=false;menuW.cz=0;menuW.slab(-20,160,0);menuW.decor(-20,160);menuW.cz=160;menuW.gen(160,160);menuW.bake(R,25,60,200,99)};
G.menuWorld=()=>menuW;

/* ---------- input ---------- */
let touches={};
function setupInput(cv){
 const ov=document.getElementById('touch');const thr=()=>34/V.S.set.sens;
 const tsF=e=>{if(G.state!=='play'||e.target.closest('.btn,#hud button'))return;V.audio.init();for(const t of e.changedTouches){touches[t.identifier]={x:t.clientX,y:t.clientY,t:performance.now(),done:false}}e.preventDefault()};
 const tmF=e=>{if(G.state!=='play')return;for(const t of e.changedTouches){const s=touches[t.identifier];if(!s)continue;const dx=t.clientX-s.x,dy=t.clientY-s.y,th=thr();
  if(Math.abs(dx)>th&&Math.abs(dx)>Math.abs(dy)){G.act(dx<0?'L':'R');s.x=t.clientX;s.y=t.clientY}else if(Math.abs(dy)>th){G.act(dy<0?'U':'D');s.x=t.clientX;s.y=t.clientY}}e.preventDefault()};
 const teF=e=>{for(const t of e.changedTouches){const s=touches[t.identifier];if(s){if(!s.done&&performance.now()-s.t<180&&Math.hypot(t.clientX-s.x,t.clientY-s.y)<12&&G.state==='play'){/* tap = jump */G.act('U')}delete touches[t.identifier]}}};
 ov.addEventListener('touchstart',tsF,{passive:false});ov.addEventListener('touchmove',tmF,{passive:false});ov.addEventListener('touchend',teF);ov.addEventListener('touchcancel',teF);
 let md=null;ov.addEventListener('mousedown',e=>{if(G.state==='play'){V.audio.init();md={x:e.clientX,y:e.clientY}}});window.addEventListener('mousemove',e=>{if(!md||G.state!=='play')return;const dx=e.clientX-md.x,dy=e.clientY-md.y,th=thr();if(Math.abs(dx)>th&&Math.abs(dx)>Math.abs(dy)){G.act(dx<0?'L':'R');md={x:e.clientX,y:e.clientY}}else if(Math.abs(dy)>th){G.act(dy<0?'U':'D');md={x:e.clientX,y:e.clientY}}});window.addEventListener('mouseup',()=>{md=null});
 window.addEventListener('keydown',e=>{if(e.repeat)return;const k=e.key;
  if(k==='ArrowLeft'||k==='a'||k==='A')G.act('L');else if(k==='ArrowRight'||k==='d'||k==='D')G.act('R');else if(k==='ArrowUp'||k==='w'||k==='W'||k===' ')G.act('U');else if(k==='ArrowDown'||k==='s'||k==='S'||k==='Control')G.act('D');
  else if(k==='Shift')G.act('dash');else if(k==='t'||k==='T')G.act('trick');else if(k==='e'||k==='E')G.act('super');else if(k==='Escape'||k==='p'||k==='P'){if(V.ui)V.ui.togglePause()}
  if(k.startsWith('Arrow')||k===' ')e.preventDefault()})}

/* ---------- loop ---------- */
let last=0,paused=false;
function frame(now){requestAnimationFrame(frame);if(!R||R.lost)return;const dtR=Math.min(.1,(now-last)/1000||.016);last=now;
 G.fpsN++;G.fpsT+=dtR;if(G.fpsT>=.5){G.fps=Math.round(G.fpsN/G.fpsT);G.fpsN=0;G.fpsT=0;if(V.S.set.fps&&V.ui)V.ui.fps(G.fps)}
 try{G.update(dtR);G.render()}catch(e){if(!G.err){G.err=e;console.error(e);if(V.ui&&V.ui.fatal)V.ui.fatal(e)}}}
G.start=function(){V.loadSave();V.quality=V.S.set.quality;V.audio.vol.music=V.S.set.music;V.audio.vol.sfx=V.S.set.sfx;
 const cv=document.getElementById('gl');R=G.R=new V.Renderer(cv);window.addEventListener('resize',()=>R.resize());setupInput(cv);
 G.buildMenuWorld(0);G.state='menu';requestAnimationFrame(frame)};
G.setPaused=function(v){if(G.state!=='play')return;G.paused=v;if(v)V.audio.suspend();else V.audio.resume()};
G.menuMode=function(){G.endRun();G.cine=null;G.state='menu';G.gv=null;G.buildMenuWorld(G.menuDist||0);V.audio.play('menu');V.audio.intensity=.3};
G.setQuality=function(q){V.quality=q;V.S.set.quality=q;if(R)R.resize();V.persist()};
G.setCine=function(c){G.cine=c;G.state=c?'cine':'menu'};
G.retryRun=function(){if(!run)return;const c={kind:run.kind,dist:run.dist,idx:run.idx};G.startRun(c)};
})();
