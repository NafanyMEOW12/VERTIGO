/* VERTIGO boot + intro cinematic */
(function(){
'use strict';
const V=window.V,G=V.G,lerp=V.lerp,S=Math.sin,Cs=Math.cos;
const $=id=>document.getElementById(id);
const pose=V.newPose();
V.playIntro=function(){V.audio.init();V.audio.play('menu');V.audio.intensity=.5;G.buildMenuWorld(0);G.gv=null;V.ui.hide();$('hud').classList.add('hidden');
 const c=document.createElement('div');c.id='cine';c.innerHTML='<div class="bars"></div><div class="ct" id="ct"></div><div class="tt" id="tt">VERTIGO</div><button class="btn sm skip" id="skip">ПРОПУСТИТЬ ›</button>';document.body.appendChild(c);
 const L=V.STORY_INTRO,TM=[.5,4.8,9.2,13.6];let shown=-1,done=false;const t0=G.real;
 const end=()=>{if(done)return;done=true;if(c.parentNode)c.parentNode.removeChild(c);V.S.seenIntro=true;V.persist(true);G.setCine(null);G.gv=null;V.ui.go('main')};
 $('skip').addEventListener('click',end);
 const cine={t0,
  cam(cm){const u=G.real-t0;cm.roll=0;
   if(u<4.5){const s=u/4.5;cm.x=lerp(-16,-8,s);cm.y=lerp(20,14,s);cm.z=lerp(-34,-14,s);cm.tx=0;cm.ty=6;cm.tz=40;cm.fov=.92}
   else if(u<9){const s=(u-4.5)/4.5;cm.x=lerp(6,3,s);cm.y=2.3;cm.z=lerp(-6,14,s);cm.tx=0;cm.ty=1.6;cm.tz=70;cm.fov=1.0}
   else if(u<13.5){const s=(u-9)/4.5,a=lerp(.5,2.7,s);cm.x=S(a)*5;cm.z=22-Cs(a)*5;cm.y=1.5+s*.4;cm.tx=0;cm.ty=1.3;cm.tz=22;cm.fov=.85}
   else{const hz=heroZ(u);cm.x=.8+S(u)*.3;cm.y=u>16.2?lerp(3,5,(u-16.2)/2):2.6;cm.z=hz-7.5;cm.tx=0;cm.ty=1.6+(u>16.2?(u-16.2):0);cm.tz=hz+8;cm.fov=lerp(.9,1.25,Math.min(1,(u-13.5)/4))}},
  draw(m,sp,t){const u=G.real-t0;let z=22,y=0,st='idle',o={sp:.6};
   if(u>=13.5){z=heroZ(u);if(u<16.4){st='run'}else{st='jump';y=Math.max(0,S((u-16.4)/1.6*Math.PI)*3.2)}}
   V.pose(pose,st,t,o);pose.ph=t*13;if(st==='idle')pose.yaw=-.2+S(t*.4)*.15;
   if(u>=13.5&&u<16.4)V.drawHero(m,V.S.hero,V.S.skin[V.S.hero],V.S.acc,pose,0,y,z,{});else V.drawHero(m,V.S.hero,V.S.skin[V.S.hero],V.S.acc,pose,0,y,z,{});
   const C=V.heroColors(V.S.hero,V.S.skin[V.S.hero]);sp.add(0,y+1,z,3.4,0,C.g[0],C.g[1],C.g[2],.4);
   if(u>=13.5){for(let i=1;i<6;i++)sp.add(0,y+1,z-i*.9,1.2-i*.15,3,C.g[0],C.g[1],C.g[2],.45-i*.07)}}};
 function heroZ(u){return u<16.4?22+(u-13.5)*(u-13.5)*3.2+ (u-13.5)*10:22+8.41*3.2+29+(u-16.4)*26}
 G.setCine(cine);
 const tick=()=>{if(done)return;const u=G.real-t0;let idx=-1;for(let i=0;i<TM.length;i++)if(u>=TM[i])idx=i;
  if(idx!==shown){shown=idx;const ct=$('ct');if(ct){ct.classList.remove('on');setTimeout(()=>{if(!ct||done)return;ct.textContent=L[idx]||'';ct.classList.add('on')},350)}}
  if(u>=17.2)$('tt')&&$('tt').classList.add('on');if(u>=20.5){end();return}requestAnimationFrame(tick)};
 requestAnimationFrame(tick)};
window.addEventListener('load',()=>{try{G.start();V.onAch=a=>V.ui.toast('Достижение: '+a.name+' +'+a.rew,'gold');V.ui.init();setTimeout(()=>{$('boot').classList.add('gone');if(!V.S.seenIntro)setTimeout(V.playIntro,300)},400);V.audio.play('menu')}
 catch(e){console.error(e);V.ui.fatal(e);$('boot').classList.add('gone')}});
const first=()=>{V.audio.init();if(V.audio.ok&&!V.G.run_)V.audio.play('menu');['touchstart','mousedown','keydown'].forEach(ev=>window.removeEventListener(ev,first,true))};
['touchstart','mousedown','keydown'].forEach(ev=>window.addEventListener(ev,first,true));
})();
