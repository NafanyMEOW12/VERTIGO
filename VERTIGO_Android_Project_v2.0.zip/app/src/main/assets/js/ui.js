/* VERTIGO UI: all screens (HTML overlays), HUD, garage/shop, results */
(function(){
'use strict';
const V=window.V,G=V.G,U=V.ui={};
const $=id=>document.getElementById(id);
const fmt=n=>Math.floor(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g,' ');
let cur='',tab='hero',busyT=0,selSkinHero=null,prevScr=null,typeTm=null,storyD=0,pendingRun=null;
const scr=()=>$('screens');
const coin='<i class="coin"></i>';
const pill=()=>'<div class="pill" id="pill">'+coin+'<b>'+fmt(V.S.coins)+'</b></div>';
const SUPN={phase:'Фазовый сдвиг',nova:'Ударная волна',storm:'Шторм монет',warp:'Искажение времени'};

U.fatal=function(e){const d=document.createElement('div');d.className='fatal';d.innerHTML='<h3>Ошибка игры</h3><pre>'+String(e&&e.stack||e).slice(0,500).replace(/</g,'&lt;')+'</pre><button class="btn" onclick="location.reload()">Перезапустить</button>';document.body.appendChild(d)};
U.fps=function(f){let e=$('fps');if(!e){e=document.createElement('div');e.id='fps';document.body.appendChild(e)}e.textContent=f+' FPS'};
U.toast=function(t,c){const box=$('toasts');if(!box)return;const d=document.createElement('div');d.className='toast '+(c||'');d.textContent=t;box.appendChild(d);while(box.children.length>3)box.removeChild(box.firstChild);setTimeout(()=>{if(d.parentNode)d.parentNode.removeChild(d)},1500)};

/* ---------- screen router ---------- */
U.go=function(name,arg){cur=name;const html=R[name]?R[name](arg):'';const keep=scr().querySelector('.list');const st=keep?keep.scrollTop:0;scr().innerHTML=html;scr().className='scr-'+name;const l=scr().querySelector('.list');if(l&&name===cur&&tab===U.lastTab)l.scrollTop=st;U.lastTab=tab;
 $('hud').classList.add('hidden');if(V.G.state==='menu'||V.G.state==='garage'){}};
U.hide=function(){scr().innerHTML='';scr().className=''};
const hdr=(title,back)=>'<div class="hdr"><button class="btn sm back" data-a="'+(back||'main')+'">‹ НАЗАД</button><div class="ttl">'+title+'</div>'+pill()+'</div>';
const medals=d=>{const m=V.S.medals[d]||0;return'<span class="med m'+m+'">'+(m?'★'.repeat(m):'—')+'</span>'};
const nextDist=()=>{const s=V.S;for(let i=0;i<6;i++)if(!s.done.includes(i))return i;return 5};
const R={
 main(){const s=V.S,nd=nextDist(),can=V.dailyState().can;return`<div class="main"><div class="left"><div class="logo">VERTIGO</div><div class="tagl">NEON PARKOUR</div>
  <button class="btn big" data-a="playCamp">ИГРАТЬ<small>Район ${nd+1}: ${V.DIST[nd].name}</small></button>
  <div class="row2"><button class="btn" data-a="go" data-s="modes">РЕЖИМЫ</button><button class="btn" data-a="garage">ГАРАЖ</button></div>
  <div class="row3"><button class="btn sm" data-a="go" data-s="daily">НАГРАДЫ${can?'<i class="dot"></i>':''}</button><button class="btn sm" data-a="go" data-s="ach">ДОСТИЖЕНИЯ</button><button class="btn sm" data-a="go" data-s="stats">СТАТИСТИКА</button><button class="btn sm" data-a="go" data-s="settings">⚙</button></div></div>
  <div class="tr">${pill()}</div><div class="hn">${V.HEROES[s.hero].name}</div></div>`},
 modes(){const s=V.S,memeBtn=s.meme&&!s.memeKilled?'<button class="card meme" data-a="startMeme"><b>СЕКРЕТНЫЙ БОСС</b><span>Король Банан Рекс ждёт</span></button>':s.memeKilled?'<button class="card meme" data-a="startMeme"><b>МЕМ-БОСС</b><span>Победа! Сразиться снова</span></button>':'';
  return hdr('РЕЖИМЫ')+`<div class="cards"><button class="card" data-a="go" data-s="camp"><b>КАМПАНИЯ</b><span>6 районов, боссы, сюжет</span><em>${s.done.length}/6</em></button>
  <button class="card" data-a="startEndless"><b>БЕСКОНЕЧНЫЙ</b><span>Рекорд: ${fmt(s.best.endless)} м</span></button>
  <button class="card" data-a="go" data-s="chases"><b>ПОГОНИ</b><span>Не дай себя догнать</span></button>
  <button class="card" data-a="go" data-s="chall"><b>ИСПЫТАНИЯ</b><span>${Object.keys(s.chall).length}/${V.CHALL.length} выполнено</span></button>${memeBtn}</div>`},
 camp(){const s=V.S;let h=hdr('КАМПАНИЯ','go" data-s="modes')+'<div class="cards hs">';for(let i=0;i<6;i++){const d=V.DIST[i],open=i===0||s.done.includes(i-1),done=s.done.includes(i);
   h+=`<button class="card dist ${open?'':'lock'} ${done?'done':''}" ${open?`data-a="story" data-d="${i}"`:'data-a="deny"'} style="--c:${d.th.acc}"><i class="num">${i+1}</i><b>${d.name}</b><span>${d.sub}</span><span class="bs">Босс: ${V.BOSSES[d.boss].name}</span>${open?medals(i):'<span class="lk">ЗАКРЫТО</span>'}</button>`}return h+'</div>'},
 chases(){const s=V.S;let h=hdr('ПОГОНИ','go" data-s="modes')+'<div class="cards hs">';V.CHASES.forEach((c,i)=>{const open=s.done.length>=c.dist,best=s.best.chase[i]||0;h+=`<button class="card ${open?'':'lock'}" ${open?`data-a="startChase" data-i="${i}"`:'data-a="deny"'}><b>${c.name}</b><span>${c.desc}</span><span class="bs">Дистанция: ${c.len} м · Лучшее: ${fmt(best)} м</span>${open?'':'<span class="lk">пройди '+c.dist+' р.</span>'}</button>`});return h+'</div>'},
 chall(){const s=V.S;let h=hdr('ИСПЫТАНИЯ','go" data-s="modes')+'<div class="list wide">';V.CHALL.forEach((c,i)=>{const open=s.done.length>=c.dist,dn=s.chall[i];h+=`<button class="row ${open?'':'lock'} ${dn?'done':''}" ${open?`data-a="startChall" data-i="${i}"`:'data-a="deny"'}><b>${c.name}</b><span>${c.desc}${c.lim?' · '+c.lim+' с':''} · ${V.DIST[c.dist].name}</span><em>${dn?'✔':'+'+c.rew}</em></button>`});return h+'</div>'},
 story(d){const D=V.DIST[d];return`<div class="story" style="--c:${D.th.acc}"><div class="sc"><div class="sn">РАЙОН ${d+1}</div><h2>${D.name}</h2><p id="stxt"></p><div class="sb">Босс: ${V.BOSSES[D.boss].name} — ${V.BOSSES[D.boss].title}</div><div class="row2"><button class="btn" data-a="go" data-s="camp">НАЗАД</button><button class="btn big" data-a="startCamp" data-d="${d}">В БОЙ</button></div></div></div>`},
 garage(){const s=V.S;const T=[['hero','ГЕРОИ'],['skin','СКИНЫ'],['acc','АКСЕССУАРЫ'],['comp','НАПАРНИКИ'],['upg','ПРОКАЧКА']];
  return`<div class="garage"><div class="gh"><button class="btn sm back" data-a="main">‹ НАЗАД</button>${pill()}</div><div class="tabs">${T.map(t=>`<button class="tab ${tab===t[0]?'on':''}" data-a="tab" data-t="${t[0]}">${t[1]}</button>`).join('')}</div><div class="gp"><div class="list">${garList()}</div></div></div>`},
 daily(){const st=V.dailyState();let h=hdr('ЕЖЕДНЕВНЫЕ НАГРАДЫ')+'<div class="dgrid">';V.DAILY.forEach((r,i)=>{const past=i<st.idx,now=i===st.idx;h+=`<div class="dcell ${past?'past':''} ${now?'now':''}"><i>ДЕНЬ ${i+1}</i><b>${r.n}</b>${past?'<em>✔</em>':''}</div>`});
  return h+`</div><div class="dfoot"><button class="btn big" data-a="claim" ${st.can?'':'disabled'}>${st.can?'ЗАБРАТЬ НАГРАДУ':'Приходи завтра'}</button></div>`},
 ach(){const s=V.S;let h=hdr('ДОСТИЖЕНИЯ')+`<div class="sub">Открыто: ${s.ach.length}/${V.ACH.length}</div><div class="list wide">`;for(const a of V.ACH){const v=Math.min(a.goal,V.statVal(a.stat)),d=s.ach.includes(a.id);h+=`<div class="row ${d?'done':''}"><b>${a.name}</b><span>${a.desc}</span><div class="pb"><i style="width:${v/a.goal*100}%"></i></div><em>${d?'✔':'+'+a.rew}</em></div>`}return h+'</div>'},
 stats(){const s=V.S,t=s.stat,h=Math.floor(t.time/3600),m=Math.floor(t.time%3600/60);const rows=[['Всего пробежано',fmt(t.dist)+' м'],['Забегов',fmt(t.runs)],['Монет собрано',fmt(t.coins)],['Лучший счёт',fmt(t.score)],['Рекорд бесконечного',fmt(s.best.endless)+' м'],['Трюков',fmt(t.tricks)],['По стенам',fmt(t.wall)+' м'],['Впритирку',fmt(t.near)],['Рывков',fmt(t.dash)],['Разбито препятствий',fmt(t.breaks)],['Боссов побеждено',fmt(t.bosses)],['Погонь выиграно',fmt(t.chases)],['Секретных токенов',s.secrets.length+'/6'],['Героев',s.heroes.length+'/'+V.HEROES.length],['Скинов',s.skins.length+'/'+V.SKINS.length],['Лучший множитель','x'+t.combo],['Время в игре',h+' ч '+m+' мин']];
  return hdr('СТАТИСТИКА')+'<div class="sgrid">'+rows.map(r=>`<div class="srow"><span>${r[0]}</span><b>${r[1]}</b></div>`).join('')+'</div>'},
 settings(){const s=V.S.set;const tg=(k,l)=>`<button class="tg ${s[k]?'on':''}" data-a="tog" data-k="${k}">${l}<i></i></button>`;
  return hdr('НАСТРОЙКИ',prevScr==='pause'?'pause':'main')+`<div class="list wide set"><label>Музыка<input type="range" min="0" max="100" value="${Math.round(s.music*100)}" data-r="music"></label><label>Звуки<input type="range" min="0" max="100" value="${Math.round(s.sfx*100)}" data-r="sfx"></label><label>Чувствительность свайпа<input type="range" min="50" max="180" value="${Math.round(s.sens*100)}" data-r="sens"></label>
  <div class="qrow"><span>Графика</span>${['low','med','high'].map(q=>`<button class="tab ${s.quality===q?'on':''}" data-a="qual" data-q="${q}">${{low:'Слабая',med:'Средняя',high:'Высокая'}[q]}</button>`).join('')}</div>
  <div class="tgs">${tg('shake','Тряска камеры')}${tg('haptic','Вибрация')}${tg('left','Леворукий режим')}${tg('fps','Показать FPS')}</div>
  <button class="btn" data-a="intro">СМОТРЕТЬ ВСТУПЛЕНИЕ</button><button class="btn danger" data-a="reset">СБРОСИТЬ ПРОГРЕСС</button><div class="ver">VERTIGO 2.0 · офлайн</div></div>`},
 pause(){return`<div class="pausebox"><h2>ПАУЗА</h2><button class="btn big" data-a="resume">ПРОДОЛЖИТЬ</button><button class="btn" data-a="restart">ЗАНОВО</button><button class="btn" data-a="pset">НАСТРОЙКИ</button><button class="btn" data-a="quit">В МЕНЮ</button></div>`},
 result(r){const win=r.win,k=r.kind;const title=win?(k==='campaign'?'РАЙОН ПРОЙДЕН':k==='chase'?'ПОБЕГ УДАЛСЯ':k==='challenge'?'ИСПЫТАНИЕ ПРОЙДЕНО':k==='meme'?'КОРОЛЬ ПОВЕРЖЕН':'ЗАБЕГ ЗАВЕРШЁН'):(k==='endless'?'ЗАБЕГ ОКОНЧЕН':'НЕУДАЧА');
  const canCp=!win&&k==='campaign'&&r.cpN>0,nd=k==='campaign'&&win&&r.dist<5;const extra=win&&k==='campaign'?(r.dist===5?'<p class="end">'+V.ENDING+'</p>':'<p class="end">'+V.DIST[r.dist].outro+'</p>'):'';
  return`<div class="result ${win?'win':'lose'}"><div class="rb"><h2>${title}</h2>${r.medal?`<div class="medal">${'★'.repeat(r.medal)}</div>`:''}<div class="rg"><div><span>Счёт</span><b>${fmt(r.score)}</b></div><div><span>Дистанция</span><b>${fmt(r.dm)} м</b></div><div><span>Монеты</span><b>${coin}${fmt(r.coins)}</b></div><div><span>Множитель</span><b>x${r.maxMult}</b></div>${r.bonus?`<div><span>Бонус</span><b>+${fmt(r.bonus)}</b></div>`:''}${r.newBest?'<div class="nb">НОВЫЙ РЕКОРД!</div>':''}</div>${extra}${r.ach&&r.ach.length?'<div class="achs">'+r.ach.map(a=>`<div class="ac">★ ${a.name} <em>+${a.rew}</em></div>`).join('')+'</div>':''}
  <div class="row2">${canCp?`<button class="btn big" data-a="cp">С КОНТРОЛЬНОЙ ТОЧКИ <small>${40*(1+r.cpN)} монет</small></button>`:''}${nd?'<button class="btn big" data-a="nextD">ДАЛЬШЕ</button>':''}<button class="btn" data-a="retry">ЗАНОВО</button><button class="btn" data-a="quit">МЕНЮ</button></div></div></div>`}
};
/* ---------- garage lists ---------- */
function priceTag(owned,price,locked){return owned?'<em class="own">ЕСТЬ</em>':locked?'<em class="lock">🔒</em>':'<em class="pr">'+coin+fmt(price)+'</em>'}
function garList(){const s=V.S;let h='';
 if(tab==='hero'){V.HEROES.forEach((x,i)=>{const own=s.heroes.includes(i),lk=s.done.length<x.need;const eq=s.hero===i;h+=`<button class="it ${eq?'eq':''} ${lk?'lock':''}" data-a="hero" data-i="${i}"><b>${x.name}</b><span>${lk?'Нужно пройти районов: '+x.need:x.tag}</span><span class="sp">Супер: ${SUPN[x.sup]}</span>${eq?'<em class="own">ВЫБРАН</em>':priceTag(own,x.price,lk)}</button>`})}
 else if(tab==='skin'){const hh=s.hero;V.skinsOf(hh).forEach(k=>{const gi=V.SKINS.indexOf(k),own=s.skins.includes(gi),eq=s.skin[hh]===k.idx;h+=`<button class="it r${k.rar} ${eq?'eq':''}" data-a="skin" data-i="${gi}"><b>${k.name}</b><span>${V.RAR[k.rar]} · эффект: ${{none:'—',sparks:'искры',fire:'огонь',ice:'лёд',glitch:'глитч',rainbow:'радуга',gold:'золото',shadow:'тень'}[k.fx]}</span>${eq?'<em class="own">НАДЕТ</em>':priceTag(own,k.price,false)}</button>`})}
 else if(tab==='acc'){V.ACCS.forEach((a,i)=>{const own=s.accs.includes(i),eq=s.acc===i;h+=`<button class="it ${eq?'eq':''}" data-a="acc" data-i="${i}"><b>${a.name}</b><span>Косметика</span>${eq?'<em class="own">НАДЕТ</em>':priceTag(own,a.price,false)}</button>`})}
 else if(tab==='comp'){V.COMPS.forEach((a,i)=>{const own=s.comps.includes(i),eq=s.comp===i;h+=`<button class="it ${eq?'eq':''}" data-a="comp" data-i="${i}"><b>${a.name}</b><span>${a.desc||'Бегаешь один'}</span>${eq?'<em class="own">ВЫБРАН</em>':priceTag(own,a.price,false)}</button>`})}
 else{V.UPG.forEach(u=>{const l=s.upg[u.id],c=V.upgCost(u.id);h+=`<button class="it" data-a="upg" data-i="${u.id}"><b>${u.name} <i class="lv">${'■'.repeat(l)}${'□'.repeat(5-l)}</i></b><span>${u.desc}</span>${c==null?'<em class="own">МАКС</em>':'<em class="pr">'+coin+fmt(c)+'</em>'}</button>`})}
 return h}
function garRefresh(){const l=scr().querySelector('.list');if(!l)return;const st=l.scrollTop;l.innerHTML=garList();l.scrollTop=st;const p=$('pill');if(p)p.innerHTML=coin+'<b>'+fmt(V.S.coins)+'</b>';document.querySelectorAll('.tab[data-t]').forEach(e=>e.classList.toggle('on',e.dataset.t===tab))}
function pv(o){G.gv=Object.assign({},G.gv||{},o);}

/* ---------- actions ---------- */
function typeText(el,txt){clearInterval(typeTm);let i=0;el.textContent='';typeTm=setInterval(()=>{i+=2;el.textContent=txt.slice(0,i);if(i>=txt.length)clearInterval(typeTm)},22)}
const A={
 go:d=>{prevScr=cur;U.go(d.s)},main:()=>{G.gv=null;G.state='menu';U.go('main')},
 playCamp:()=>{A.story({d:nextDist()})},
 story:d=>{const i=+d.d;storyD=i;G.menuDist=i;G.buildMenuWorld(i);U.go('story',i);typeText($('stxt'),V.DIST[i].intro)},
 startCamp:d=>{clearInterval(typeTm);U.hide();G.startRun({kind:'campaign',dist:+d.d})},
 startEndless:()=>{U.hide();G.startRun({kind:'endless',dist:0})},startChase:d=>{U.hide();G.startRun({kind:'chase',idx:+d.i})},startChall:d=>{U.hide();G.startRun({kind:'challenge',idx:+d.i})},startMeme:()=>{U.hide();G.startRun({kind:'meme',dist:0})},
 deny:()=>{V.sfx('deny');U.toast('Сначала пройди предыдущие районы','red')},
 garage:()=>{G.state='garage';G.gv={};tab='hero';U.go('garage');pv({cam:null})},
 tab:d=>{tab=d.t;garRefresh();if(tab==='skin')pv({skin:V.S.skin[V.S.hero]})},
 hero:d=>{const i=+d.i,s=V.S;pv({hero:i,skin:s.skin[i],spin:null});if(s.heroes.includes(i)){s.hero=i;V.persist();garRefresh();V.sfx('ui')}else{const r=V.buy('hero',i);if(r==='ok'){s.hero=i;V.sfx('buy');U.toast('Герой открыт!','gold')}else{V.sfx('deny');U.toast(r==='locked'?'Пройди больше районов':'Не хватает монет','red')}V.persist(true);garRefresh()}},
 skin:d=>{const gi=+d.i,k=V.SKINS[gi],s=V.S;pv({skin:k.idx});if(s.skins.includes(gi)){s.skin[k.hero]=k.idx;V.persist();V.sfx('ui')}else{const r=V.buy('skin',gi);if(r==='ok'){s.skin[k.hero]=k.idx;V.sfx('buy');U.toast('Скин куплен!','gold')}else{V.sfx('deny');U.toast('Не хватает монет','red')}}garRefresh()},
 acc:d=>{const i=+d.i,s=V.S;pv({acc:i});if(s.accs.includes(i)){s.acc=i;V.persist();V.sfx('ui')}else{const r=V.buy('acc',i);if(r==='ok'){s.acc=i;V.sfx('buy')}else{V.sfx('deny');U.toast('Не хватает монет','red')}}garRefresh()},
 comp:d=>{const i=+d.i,s=V.S;pv({comp:i});if(s.comps.includes(i)){s.comp=i;V.persist();V.sfx('ui')}else{const r=V.buy('comp',i);if(r==='ok'){s.comp=i;V.sfx('buy')}else{V.sfx('deny');U.toast('Не хватает монет','red')}}garRefresh()},
 upg:d=>{const r=V.buyUpg(d.i);if(r==='ok'){V.sfx('buy');U.toast('Улучшено!','gold')}else if(r==='poor'){V.sfx('deny');U.toast('Не хватает монет','red')}garRefresh()},
 claim:()=>{const m=V.claimDaily();if(m){V.sfx('buy');U.toast('Получено: '+m,'gold');U.go('daily')}},
 tog:d=>{const s=V.S.set;s[d.k]=!s[d.k];V.persist();if(d.k==='left')document.body.classList.toggle('lefty',s.left);V.sfx('ui');U.go('settings')},
 qual:d=>{G.setQuality(d.q);U.go('settings');V.sfx('ui')},
 reset:()=>{if(confirm('Удалить весь прогресс?')){V.resetSave();V.quality=V.S.set.quality;V.sfx('ui');U.go('main')}},
 intro:()=>{if(V.playIntro)V.playIntro()},
 resume:()=>{U.hide();G.setPaused(false);$('hud').classList.remove('hidden')},restart:()=>{U.hide();G.retryRun()},pset:()=>{prevScr='pause';U.go('settings')},pause:()=>{U.go('pause')},
 quit:()=>{G.menuMode();U.go('main')},retry:()=>{U.hide();G.retryRun()},
 nextD:()=>{G.menuMode();A.story({d:Math.min(5,G.run_?G.run_.dist+1:storyD+1)})},
 cp:()=>{if(G.retryCp()){U.hide()}else{V.sfx('deny');U.toast('Не хватает монет','red')}}
};
U.bind=function(){document.addEventListener('click',e=>{const t=e.target.closest('[data-a]');if(!t||t.disabled)return;V.audio.init();const f=A[t.dataset.a];if(f){if(t.dataset.a!=='deny'&&!/^(hero|skin|acc|comp|upg|claim)$/.test(t.dataset.a))V.sfx('ui');f(t.dataset)}});
 document.addEventListener('input',e=>{const r=e.target.dataset&&e.target.dataset.r;if(!r)return;const v=+e.target.value/100;V.S.set[r]=v;if(r==='music'){V.audio.vol.music=v;V.audio.apply()}if(r==='sfx'){V.audio.vol.sfx=v;V.audio.apply()}V.persist()});
 $('b_dash').addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();V.audio.init();G.act('dash')},{passive:false});$('b_trick').addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();G.act('trick')},{passive:false});$('b_super').addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();G.act('super')},{passive:false});$('b_pause').addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();U.togglePause()},{passive:false});
 for(const[id,a]of[['b_dash','dash'],['b_trick','trick'],['b_super','super']])$(id).addEventListener('mousedown',e=>{e.stopPropagation();G.act(a)});$('b_pause').addEventListener('mousedown',e=>{e.stopPropagation();U.togglePause()});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){V.persist(true);if(G.state==='play'&&!G.paused)U.togglePause();V.audio.suspend()}else if(G.state!=='play'||G.paused)V.audio.resume()});
 window.addEventListener('pagehide',()=>V.persist(true));
 if(V.S.set.left)document.body.classList.add('lefty')};
U.togglePause=function(){if(G.state!=='play'||!G.run_||G.run_.done)return;if(!G.paused){G.setPaused(true);U.go('pause');$('hud').classList.remove('hidden')}else{U.hide();G.setPaused(false)}};
window.__vertigoAutoPause=()=>{if(G.state==='play'&&!G.paused&&G.run_&&!G.run_.done)U.togglePause()};
window.__vertigoBack=()=>{if(cur==='pause'&&G.paused){A.resume();return'resumed'}if(G.state==='play'&&!G.paused){U.togglePause();return'paused'}
 if(G.state==='play'&&G.paused){A.resume();return'resumed'}if(cur&&cur!=='main'&&G.state!=='play'&&G.state!=='result'){if(cur==='settings'&&prevScr==='pause'){U.go('pause');return'back'}if(cur==='story'||cur==='chases'||cur==='chall'||cur==='camp')U.go('modes');else if(cur==='modes'||cur==='garage'||cur==='daily'||cur==='ach'||cur==='stats'||cur==='settings'){G.gv=null;G.state='menu';U.go('main')}return'back'}
 const n=Date.now();if(window.__bk&&n-window.__bk<2000)return'exit';window.__bk=n;U.toast('Нажми «Назад» ещё раз, чтобы выйти');return'wait'};

/* ---------- HUD ---------- */
const H={};
function hset(id,v,k){const key=k||id;if(H[key]===v)return;H[key]=v;const e=$(id);if(e)e.textContent=v}
U.onRunStart=function(run,cfg){U.hide();$('hud').classList.remove('hidden');H.hp=null;H.pw=null;$('bossbar').classList.add('hidden');$('chasebar').classList.toggle('hidden',run.kind!=='chase');$('progbar').classList.toggle('hidden',!(run.kind==='campaign'));$('goal').classList.toggle('hidden',run.kind!=='challenge');$('prompt').classList.add('hidden');
 $('b_super').querySelector('em').textContent='СУПЕР';$('goal').textContent=run.ch?run.ch.desc:''};
U.hud=function(G_,run,p,W){if(!run)return;hset('h_score',fmt(run.score));hset('h_coins',fmt(run.coins));hset('h_dist',run.kind==='campaign'?Math.floor(p.z)+' / '+run.len+' м':Math.floor(p.z)+' м');
 if(H.hp!==p.hp+'/'+p.maxhp){H.hp=p.hp+'/'+p.maxhp;let s='';for(let i=0;i<p.maxhp;i++)s+='<i class="pip '+(i<p.hp?'on':'')+'"></i>';$('h_hp').innerHTML=s}
 const m=G.mult();hset('h_mult','x'+m);$('h_flow').style.width=(run.flow*100).toFixed(0)+'%';$('h_combo').classList.toggle('hot',m>=3);
 const cd=V.S.upg.dash,max=Math.max(1.2,2.4-.22*cd)*(V.S.comp===4?.65:1);const dp=p.dashCd>0?1-p.dashCd/max:1;const bd=$('b_dash');bd.style.setProperty('--p',(dp*100).toFixed(0));bd.classList.toggle('rdy',dp>=1);
 const bs=$('b_super');bs.style.setProperty('--p',(p.superCh*100).toFixed(0));bs.classList.toggle('rdy',p.superCh>=1&&p.sup<=0);
 let pw='';if(p.shield)pw+='<i class="pw s">ЩИТ</i>';if(G.magT>0)pw+='<i class="pw m">МАГНИТ '+Math.ceil(G.magT)+'</i>';if(G.x2T>0)pw+='<i class="pw x">x2 '+Math.ceil(G.x2T)+'</i>';if(p.guard)pw+='<i class="pw s">БОТ</i>';if(p.sup>0)pw+='<i class="pw u">СУПЕР '+Math.ceil(p.sup)+'</i>';if(H.pw!==pw){H.pw=pw;$('h_pw').innerHTML=pw}
 if(run.kind==='campaign'&&W){$('progfill').style.width=Math.min(100,p.z/run.len*100)+'%'}
 if(G.chase){const g=Math.max(0,Math.min(1,G.chase.gap/42));$('chasefill').style.width=(g*100)+'%';$('chasebar').classList.toggle('danger',g<.3)}
 if(run.ch){let v='';const c=run.ch;switch(c.g){case'coins':v=(run.chC||0)+'/'+c.v;break;case'tricks':v=run.tricks+'/'+c.v;break;case'nohit':v=Math.floor(run.nohitDist)+'/'+c.v+' м';break;case'wall':v=Math.floor(run.wall)+'/'+c.v+' м';break;case'near':v=run.near+'/'+c.v;break;case'dist':v=Math.floor(p.z)+'/'+c.v+' м';break;case'combo':v='x'+run.maxMult+'/x'+c.v;break;case'breaks':v=run.breaks+'/'+c.v}if(c.lim)v+=' · '+Math.max(0,Math.ceil(c.lim-run.chT))+' с';hset('goal',c.desc+' — '+v,'goalv')}
 const B=G.B;const bb=$('bossbar');if(B&&B.state!=='enter'){bb.classList.remove('hidden');$('bossname').textContent=B.def.name;$('bossfill').style.width=(Math.max(0,B.hp)/B.max*100)+'%';$('prompt').classList.toggle('hidden',B.state!=='expose')}else{bb.classList.add('hidden');if(!B)$('prompt').classList.add('hidden')}};
U.bossIntro=function(def){const b=$('banner');b.innerHTML='<small>БОСС</small><b>'+def.name+'</b><span>'+def.title+'</span>';b.className='show boss';};
U.bossIntroEnd=function(){$('banner').className=''};
U.bossLine=function(t,def){U.toast(def.name+': '+t,'red')};
U.bossMiss=function(){U.toast('Упустил момент! Босс восстановился','red')};
U.showResult=function(run,win){$('hud').classList.add('hidden');$('prompt').classList.add('hidden');setTimeout(()=>{if(G.state==='result'){U.go('result',run);$('hud').classList.add('hidden')}},win?600:300)};
U.init=function(){U.bind();U.go('main')};
})();
