/* VERTIGO bosses: telegraphed hazards, multi-phase boss fights with dash-strike windows */
(function(){
'use strict';
const V=window.V,G=V.G,S=Math.sin,Cs=Math.cos,clamp=V.clamp,lerp=V.lerp;
const laneX=V.laneX;
const RED=[1,.25,.3],ORG=[1,.6,.2],WHITE=[1,1,1];

/* ---------- hazards ---------- */
G.hazAdd=function(k,lanes,delay,o){const p=G.p;if(!p)return;o=o||{};const z=p.z+Math.max(9,p.base*(delay||1.4));G.haz.push(Object.assign({k,lanes,z,t:0,tel:Math.max(.5,(delay||1.4)-.15),dur:k==='ring'||k==='beamL'||k==='beamH'?.55:k==='hole'||k==='peel'?1.6:.6,hit:false,sp:o.sp||0,x:lanes&&lanes.length?laneX(lanes[0]):0},o));V.sfx('tele')};
G.hazUpd=function(dt){const p=G.p,q=G.haz;if(!p)return;for(let i=q.length-1;i>=0;i--){const h=q[i];h.t+=dt;
 if(h.k==='ball'){h.z-=h.sp*dt;if(!h.hit&&Math.abs(p.z-h.z)<1.0&&Math.abs(p.x-h.x)<1.1&&p.y<1.4&&G.hurt(h))h.hit=true;if(h.z<p.z-8)q.splice(i,1);continue}
 const active=h.t>=h.tel&&h.t<h.tel+h.dur;if(active&&!h.fx){h.fx=true;if(h.k==='blast'){V.sfx('explode');G.shake(.2)}else if(h.k==='ring')V.sfx('explode');else if(h.k==='beamL'||h.k==='beamH')V.sfx('laser')}
 if(active&&!h.hit&&Math.abs(p.z-h.z)<(h.k==='hole'||h.k==='peel'?1.7:1.4)){let hit=false;const inL=()=>h.lanes.some(l=>Math.abs(p.x-laneX(l))<1.1);
  switch(h.k){case'blast':hit=inL()&&p.y<1.3;break;case'ring':case'beamL':hit=p.y<.7;break;case'beamH':hit=p.hy>1.1&&p.y<1.9;break;case'hole':hit=inL()&&p.grounded;break;case'peel':hit=inL()&&p.grounded&&p.y<.4;break}
  if(hit){h.hit=true;if(h.k==='peel')G.hurt(h,true);else G.hurt(h)}}
 if(h.t>h.tel+h.dur+.3||p.z>h.z+8)q.splice(i,1)}};
G.hazDraw=function(m,sp,t){const p=G.p;for(const h of G.haz){const pre=h.t<h.tel,pulse=.5+.5*S(h.t*22),f=pre?h.t/h.tel:1;
 if(h.k==='ball'){m.ball(h.x,.9,h.z,.9,V.c('#4a4a52'),.2,7);m.ball(h.x,.9,h.z-.7,.25,RED,1.8,4);if(G.B&&G.B.id===6){m.ball(h.x,.9,h.z,.92,V.c('#7a4a2a'),.1,7)}continue}
 switch(h.k){
 case'blast':for(const l of h.lanes){const x=laneX(l);if(pre){m.box(x,.04,h.z,2.0,.05,3.0,RED,1.0+pulse*1.2);m.box(x,.05,h.z,1.2*f,.06,1.8*f,[1,.8,.3],1.5)}else if(h.t<h.tel+h.dur){m.box(x,2.5,h.z,1.7,5,1.7,ORG,2.2);m.box(x,2.5,h.z,.8,5.2,.8,WHITE,2.6);sp.add(x,1.5,h.z,5,0,1,.5,.2,.9)}}break;
 case'ring':if(pre)m.box(0,.04,h.z,7.2,.05,1.2,RED,1+pulse*1.2);else if(h.t<h.tel+h.dur){m.box(0,.3,h.z,7.2,.6,.7,[.5,1,1],2.3);sp.add(0,.4,h.z,7,3,.4,.9,1,.8)}break;
 case'beamL':case'beamH':{const y=h.k==='beamL'?.35:1.35;if(pre){m.box(0,y,h.z,7.2,.04,.04,RED,1.2+pulse);for(const sd of[-1,1])m.box(sd*3.8,y,h.z,.3,.3,.3,RED,1.5)}else if(h.t<h.tel+h.dur){m.box(0,y,h.z,7.2,.2,.2,[1,.3,.4],2.4);m.box(0,y,h.z,7.2,.06,.06,WHITE,2.6)}break}
 case'hole':for(const l of h.lanes){const x=laneX(l);m.box(x,.02,h.z,2.1,.05,3.2,pre?[.1,.02,.03]:[0,0,0],pre?.6+pulse:.1);m.box(x,.06,h.z,2.2,.03,.2,RED,1.6);m.box(x,.06,h.z+1.6,2.2,.03,.2,RED,1.6)}break;
 case'peel':for(const l of h.lanes){const x=laneX(l);m.push();m.tr(x,.12,h.z);m.rx(.3);m.box(0,0,0,.9,.1,1.4,V.c('#ffe14d'),pre?.5+pulse:1.2);m.box(.3,.1,-.3,.3,.08,.9,V.c('#ffe14d'),.8);m.box(-.3,.1,-.3,.3,.08,.9,V.c('#ffe14d'),.8);m.pop()}break}}};

/* ---------- boss attacks ---------- */
let sched=[];
const at=(t,fn)=>sched.push({t,fn});
const rl=()=>Math.floor(Math.random()*3);
const hz=(k,l,d,o)=>G.hazAdd(k,l,d,o);
const ATK={
 missiles:ph=>{const n=3+ph;for(let i=0;i<n;i++)at(i*.55,()=>hz('blast',[rl()],1.35));return n*.55+1.3},
 shock:ph=>{at(0,()=>hz('ring',[0,1,2],1.5));if(ph>1)at(1.0,()=>hz('ring',[0,1,2],1.5));return 2.2+(ph>1?1:0)},
 lasers:ph=>{at(0,()=>hz('beamH',[0,1,2],1.5));at(.9,()=>hz('beamL',[0,1,2],1.5));if(ph>0)at(1.8,()=>hz('beamH',[0,1,2],1.5));return 3.2+(ph>0?.9:0)},
 wallgap:ph=>{const g=rl();at(0,()=>hz('blast',[0,1,2].filter(i=>i!==g),1.5));if(ph>0){const g2=rl();at(1.1,()=>hz('blast',[0,1,2].filter(i=>i!==g2),1.5))}return 2.6+(ph>0?1.1:0)},
 rain:ph=>{const n=5+ph*2;for(let i=0;i<n;i++)at(i*.38,()=>hz('blast',[rl()],1.3));return n*.38+1.2},
 roller:ph=>{const l=rl();at(0,()=>hz('ball',[l],0,{sp:16,z:G.p.z+48,x:laneX(l)}));if(ph>0){const l2=(l+1)%3;at(.9,()=>hz('ball',[l2],0,{sp:16,z:G.p.z+48,x:laneX(l2)}))}return 3.4},
 holes:ph=>{const a=rl();at(0,()=>hz('hole',[a,(a+1)%3],1.6));if(ph>1)at(1.2,()=>hz('hole',[(a+2)%3],1.4));return 2.6},
 peels:ph=>{at(0,()=>hz('peel',[0,1,2].filter(()=>Math.random()<.6),1.3));at(.8,()=>hz('peel',[rl()],1.3));return 2.6}
};
const POOL=[['missiles','shock','lasers','wallgap'],['roller','rain','shock','wallgap'],['wallgap','rain','lasers','holes'],['lasers','holes','rain','shock'],['rain','wallgap','lasers','roller'],['lasers','wallgap','rain','shock','holes','roller','missiles'],['peels','roller','shock','rain']];
const LINES=['ИДИ НА МЕНЯ!','Слабое место открыто — ДАШ!','Ты не пройдёшь!','Держи!','Это ещё не всё!','Ай-ай-ай…'];

G.bossStart=function(id){const p=G.p,run=G.run_;const def=V.BOSSES[id];const B=G.B={id,def,hp:def.hp,max:def.hp,state:'enter',t:0,off:56,x:0,exposed:false,flash:0,n:0,cur:null,pause:0,phase:0,struck:false,timer:0,dying:0,dead:false,done:false};
 sched=[];G.haz.length=0;G.cine={t:0,dur:3.4,boss:true,cam:c=>{const u=clamp(B.t/3.4,0,1),bz=p.z+B.off;c.x=lerp(9,-5,u);c.y=lerp(2.2,5,u);c.z=bz-lerp(24,15,u);c.tx=B.x;c.ty=3.2;c.tz=bz;c.fov=.95;c.roll=0}};
 V.audio.play('boss',V.audio.districtRoot(run.dist)-2);V.audio.intensity=.9;V.sfx('warn');G.shake(.6);
 if(V.ui&&V.ui.bossIntro)V.ui.bossIntro(def)};
G.bossStrike=function(){const B=G.B;if(!B||B.state!=='expose'||B.struck)return;const p=G.p;B.struck=true;B.hp--;B.flash=.6;B.state='hurt';B.t=0;B.exposed=false;G.slow(.35,.6);V.sfx('bosshit');G.shake(1);G.flash(1,1,1,.3);G.vib(80);G.addScore(1000);G.flow(.3);
 const bz=p.z+B.off;G.spark(B.x,2.5,bz,50,B.def.col?V.c(B.def.col):[1,.5,.3],12,1,.9,2);G.spark(B.x,2.5,bz,30,[1,1,1],8,.7,.6);G.toastMsg(B.hp>0?'ПОПАЛ! Осталось '+B.hp:'ФИНАЛЬНЫЙ УДАР!','big')};
function pickAtk(B){const pool=POOL[B.id],name=pool[Math.floor(Math.random()*pool.length)];const dur=ATK[name](B.phase);B.cur={name,t:0,dur};B.n++;
 if(V.ui&&V.ui.bossLine&&Math.random()<.5)V.ui.bossLine(LINES[Math.floor(Math.random()*LINES.length)],B.def)}
G.bossUpd=function(dt){const B=G.B,p=G.p,run=G.run_;if(!B||!p)return;B.t+=dt;B.flash=Math.max(0,B.flash-dt);B.phase=Math.min(2,Math.floor((B.max-B.hp)/Math.ceil(B.max/3)));
 for(let i=sched.length-1;i>=0;i--){const s=sched[i];s.t-=dt;if(s.t<=0){sched.splice(i,1);if(!p.dead)s.fn()}}
 /* boss lateral drift */
 const tx=B.cur&&B.cur.name==='roller'?0:S(G.t*.9)*2.2;B.x+=(tx-B.x)*Math.min(1,dt*3);
 switch(B.state){
 case'enter':B.off=lerp(56,23,clamp(B.t/3.4,0,1));if(B.t>=3.4){G.cine=null;B.state='attack';B.t=0;B.n=0;B.pause=.8;if(V.ui&&V.ui.bossIntroEnd)V.ui.bossIntroEnd()}break;
 case'attack':B.off+=(23-B.off)*Math.min(1,dt*2);if(B.cur){B.cur.t+=dt;if(B.cur.t>=B.cur.dur){B.cur=null;B.pause=.7-B.phase*.12;if(B.n>=(B.phase>=1?2:1)){B.state='expose';B.t=0;B.struck=false;B.exposed=true;B.timer=4;p.dashCd=0;V.sfx('warn');if(V.ui&&V.ui.bossLine)V.ui.bossLine(LINES[1],B.def)}}}else{B.pause-=dt;if(B.pause<=0&&!p.dead)pickAtk(B)}break;
 case'expose':B.off+=(10-B.off)*Math.min(1,dt*2.5);B.timer-=dt;if(B.timer<=0){B.exposed=false;B.state='attack';B.n=0;B.cur=null;B.pause=.8;if(V.ui&&V.ui.bossMiss)V.ui.bossMiss()}break;
 case'hurt':B.off+=(27-B.off)*Math.min(1,dt*3);if(B.t>1.1){if(B.hp<=0){B.state='dying';B.t=0;G.slow(.3,2.8);V.audio.stop();V.sfx('bossdie')}else{B.state='attack';B.n=0;B.cur=null;B.pause=1}}break;
 case'dying':{B.off+=(30-B.off)*Math.min(1,dt*1);B.dying+=dt;if(Math.random()<dt*14){const bz=p.z+B.off;G.spark(B.x+(Math.random()-.5)*3,1+Math.random()*3,bz,10,[1,.6,.2],8,.8,.8);G.shake(.5)}
  if(B.t>2.6&&!B.done){B.done=true;B.dead=true;G.haz.length=0;G.spark(B.x,3,p.z+B.off,80,[1,.8,.4],16,1.2,1);V.sfx('explode');G.flash(1,1,1,.5);setTimeout(()=>{if(G.run_===run&&run&&!run.done){run.bossState='dead';G.finish(true)}},900)}break}}};
G.bossDraw=function(m,sp,t){const B=G.B,p=G.p;if(!B||B.dead)return;const bz=p.z+B.off;
 V.drawBoss(m,B.id,t,{x:B.x,y:0,z:bz,flash:B.flash,exposed:B.exposed,atk:!!B.cur,scale:1.2});
 const c=V.c(B.def.col);sp.add(B.x,3,bz,B.exposed?10:6,0,c[0],c[1],c[2],B.exposed?.8:.4);
 if(B.exposed){sp.add(B.x,2.6,bz,5+S(t*14),1,1,1,1,.9);sp.add(B.x,2.6,bz-1,3,2,1,.9,.4,.8)}
 if(B.cur&&(B.cur.name==='lasers'||B.cur.name==='shock')){sp.add(B.x,2.6,bz,5,2,1,.3,.3,.7)}};
})();
