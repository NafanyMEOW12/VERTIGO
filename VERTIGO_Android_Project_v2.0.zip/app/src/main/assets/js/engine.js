/* VERTIGO engine: math, colours, mesh builder, sprites, WebGL renderer */
(function(){
'use strict';
const V=window.V=window.V||{};
const TAU=Math.PI*2;
V.TAU=TAU;
V.clamp=(x,a,b)=>x<a?a:x>b?b:x;
V.lerp=(a,b,t)=>a+(b-a)*t;
V.sgn=x=>x<0?-1:x>0?1:0;
V.rng=function(seed){let s=seed>>>0;return function(){s=(s+0x6D2B79F5)>>>0;let t=s;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296}};

/* ---------- colours ---------- */
const cc={};
V.c=function(h){if(typeof h!=='string')return h;let r=cc[h];if(r)return r;const n=parseInt(h.slice(1),16);return cc[h]=[(n>>16&255)/255,(n>>8&255)/255,(n&255)/255]};
V.mixc=(a,b,t)=>[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];
V.shade=(c,f)=>[Math.min(1,c[0]*f),Math.min(1,c[1]*f),Math.min(1,c[2]*f)];
V.rgb2hsl=function(c){const r=c[0],g=c[1],b=c[2],mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;let h=0,s=0;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);h=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;h/=6}return[h,s,l]};
V.hsl2rgb=function(h,s,l){h=((h%1)+1)%1;if(s===0)return[l,l,l];const q=l<.5?l*(1+s):l+s-l*s,p=2*l-q;const f=t=>{t=((t%1)+1)%1;return t<1/6?p+(q-p)*6*t:t<.5?q:t<2/3?p+(q-p)*(2/3-t)*6:p};return[f(h+1/3),f(h),f(h-1/3)]};
V.recolor=function(c,m){if(!m)return c;const x=V.rgb2hsl(c);return V.hsl2rgb(x[0]+(m.h||0)/360,V.clamp(x[1]*(m.s==null?1:m.s),0,1),V.clamp(x[2]*(m.l==null?1:m.l),0,1))};

/* ---------- matrices (column-major) ---------- */
const M={
 ident(){const m=new Float32Array(16);m[0]=m[5]=m[10]=m[15]=1;return m},
 mul(o,a,b){const t=new Float32Array(16);for(let j=0;j<4;j++)for(let i=0;i<4;i++){t[j*4+i]=a[i]*b[j*4]+a[4+i]*b[j*4+1]+a[8+i]*b[j*4+2]+a[12+i]*b[j*4+3]}o.set(t);return o},
 persp(o,fy,asp,n,f){const t=1/Math.tan(fy/2);o.fill(0);o[0]=t/asp;o[5]=t;o[10]=(f+n)/(n-f);o[11]=-1;o[14]=2*f*n/(n-f);return o},
 look(o,ex,ey,ez,cx,cy,cz,ux,uy,uz){let zx=ex-cx,zy=ey-cy,zz=ez-cz,l=1/Math.hypot(zx,zy,zz);zx*=l;zy*=l;zz*=l;
  let xx=uy*zz-uz*zy,xy=uz*zx-ux*zz,xz=ux*zy-uy*zx;l=1/Math.hypot(xx,xy,xz);xx*=l;xy*=l;xz*=l;
  const yx=zy*xz-zz*xy,yy=zz*xx-zx*xz,yz=zx*xy-zy*xx;
  o[0]=xx;o[1]=yx;o[2]=zx;o[3]=0;o[4]=xy;o[5]=yy;o[6]=zy;o[7]=0;o[8]=xz;o[9]=yz;o[10]=zz;o[11]=0;
  o[12]=-(xx*ex+xy*ey+xz*ez);o[13]=-(yx*ex+yy*ey+yz*ez);o[14]=-(zx*ex+zy*ey+zz*ez);o[15]=1;return o}
};
V.M4=M;

/* ---------- mesh builder with transform stack ---------- */
const FACES=[];
(function(){for(let a=0;a<3;a++)for(const s of[1,-1]){const u=(a+1)%3,v=(a+2)%3;const idx=(su,sv)=>{const p=[0,0,0];p[a]=s;p[u]=su;p[v]=sv;return(p[0]>0?1:0)+(p[1]>0?2:0)+(p[2]>0?4:0)};
 const n=[0,0,0];n[a]=s;const c=s>0?[idx(-1,-1),idx(1,-1),idx(1,1),idx(-1,1)]:[idx(-1,-1),idx(-1,1),idx(1,1),idx(1,-1)];FACES.push({n,c,bottom:a===1&&s<0})}})();
const corner=new Float32Array(24),TRI=[0,1,2,0,2,3];

class Mesh{
 constructor(capVerts){this.cap=capVerts||60000;this.a=new Float32Array(this.cap*10);this.n=0;this.st=[];for(let i=0;i<32;i++)this.st.push(M.ident());this.sp=0;this.m=this.st[0];this.over=false}
 reset(){this.n=0;this.sp=0;this.m=this.st[0];this.m.fill(0);this.m[0]=this.m[5]=this.m[10]=this.m[15]=1}
 push(){const n=this.st[this.sp+1];n.set(this.m);this.sp++;this.m=n;return this}
 pop(){this.sp--;this.m=this.st[this.sp];return this}
 tr(x,y,z){const m=this.m;m[12]+=m[0]*x+m[4]*y+m[8]*z;m[13]+=m[1]*x+m[5]*y+m[9]*z;m[14]+=m[2]*x+m[6]*y+m[10]*z;return this}
 rx(a){const m=this.m,c=Math.cos(a),s=Math.sin(a);for(let i=0;i<4;i++){const y=m[4+i],z=m[8+i];m[4+i]=y*c+z*s;m[8+i]=-y*s+z*c}return this}
 ry(a){const m=this.m,c=Math.cos(a),s=Math.sin(a);for(let i=0;i<4;i++){const x=m[i],z=m[8+i];m[i]=x*c-z*s;m[8+i]=x*s+z*c}return this}
 rz(a){const m=this.m,c=Math.cos(a),s=Math.sin(a);for(let i=0;i<4;i++){const x=m[i],y=m[4+i];m[i]=x*c+y*s;m[4+i]=-x*s+y*c}return this}
 sc(x,y,z){const m=this.m;y=y==null?x:y;z=z==null?x:z;for(let i=0;i<4;i++){m[i]*=x;m[4+i]*=y;m[8+i]*=z}return this}
 v(x,y,z,nx,ny,nz,col,e){if(this.n>=this.cap){this.over=true;return}const m=this.m,a=this.a;let o=this.n*10;
  a[o]=m[0]*x+m[4]*y+m[8]*z+m[12];a[o+1]=m[1]*x+m[5]*y+m[9]*z+m[13];a[o+2]=m[2]*x+m[6]*y+m[10]*z+m[14];
  a[o+3]=m[0]*nx+m[4]*ny+m[8]*nz;a[o+4]=m[1]*nx+m[5]*ny+m[9]*nz;a[o+5]=m[2]*nx+m[6]*ny+m[10]*nz;
  a[o+6]=col[0];a[o+7]=col[1];a[o+8]=col[2];a[o+9]=e||0;this.n++}
 /* world-space vertex without transform */
 vw(x,y,z,nx,ny,nz,col,e){if(this.n>=this.cap){this.over=true;return}const a=this.a;let o=this.n*10;a[o]=x;a[o+1]=y;a[o+2]=z;a[o+3]=nx;a[o+4]=ny;a[o+5]=nz;a[o+6]=col[0];a[o+7]=col[1];a[o+8]=col[2];a[o+9]=e||0;this.n++}
 box(cx,cy,cz,w,h,d,col,e,bottom){if(this.n+36>this.cap){this.over=true;return}col=V.c(col);const hw=w/2,hh=h/2,hd=d/2,m=this.m;
  for(let i=0;i<8;i++){const x=cx+((i&1)?hw:-hw),y=cy+((i&2)?hh:-hh),z=cz+((i&4)?hd:-hd);corner[i*3]=m[0]*x+m[4]*y+m[8]*z+m[12];corner[i*3+1]=m[1]*x+m[5]*y+m[9]*z+m[13];corner[i*3+2]=m[2]*x+m[6]*y+m[10]*z+m[14]}
  const a=this.a;
  for(let f=0;f<6;f++){const F=FACES[f];if(F.bottom&&!bottom)continue;const n=F.n;
   const nx=m[0]*n[0]+m[4]*n[1]+m[8]*n[2],ny=m[1]*n[0]+m[5]*n[1]+m[9]*n[2],nz=m[2]*n[0]+m[6]*n[1]+m[10]*n[2];
   const c=F.c;for(let k=0;k<6;k++){const ci=c[TRI[k]]*3;const o=this.n*10;a[o]=corner[ci];a[o+1]=corner[ci+1];a[o+2]=corner[ci+2];a[o+3]=nx;a[o+4]=ny;a[o+5]=nz;a[o+6]=col[0];a[o+7]=col[1];a[o+8]=col[2];a[o+9]=e||0;this.n++}}
  return this}
 /* vertical frustum / prism: rb bottom radius, rt top radius */
 prism(cx,by,cz,rb,rt,h,seg,col,e,cap){col=V.c(col);seg=seg||6;const sl=(rb-rt)/h;
  for(let i=0;i<seg;i++){const a0=i/seg*TAU,a1=(i+1)/seg*TAU,am=(a0+a1)/2;const nx=Math.cos(am),nz=Math.sin(am),ny=sl;
   const x0=Math.cos(a0),z0=Math.sin(a0),x1=Math.cos(a1),z1=Math.sin(a1);
   this.v(cx+x0*rb,by,cz+z0*rb,nx,ny,nz,col,e);this.v(cx+x0*rt,by+h,cz+z0*rt,nx,ny,nz,col,e);this.v(cx+x1*rt,by+h,cz+z1*rt,nx,ny,nz,col,e);
   this.v(cx+x0*rb,by,cz+z0*rb,nx,ny,nz,col,e);this.v(cx+x1*rt,by+h,cz+z1*rt,nx,ny,nz,col,e);this.v(cx+x1*rb,by,cz+z1*rb,nx,ny,nz,col,e);
   if(cap!==false&&rt>0){this.v(cx,by+h,cz,0,1,0,col,e);this.v(cx+x1*rt,by+h,cz+z1*rt,0,1,0,col,e);this.v(cx+x0*rt,by+h,cz+z0*rt,0,1,0,col,e)}}
  return this}
 ball(cx,cy,cz,r,col,e,seg){col=V.c(col);seg=seg||6;const lat=Math.max(3,seg>>1);
  for(let j=0;j<lat;j++){const p0=j/lat*Math.PI,p1=(j+1)/lat*Math.PI;for(let i=0;i<seg;i++){const t0=i/seg*TAU,t1=(i+1)/seg*TAU;
   const P=(p,t)=>[Math.sin(p)*Math.cos(t),Math.cos(p),Math.sin(p)*Math.sin(t)];const a=P(p0,t0),b=P(p0,t1),c=P(p1,t1),d=P(p1,t0);
   const put=(q)=>this.v(cx+q[0]*r,cy+q[1]*r,cz+q[2]*r,q[0],q[1],q[2],col,e);
   if(j>0){put(a);put(b);put(d)}if(j<lat-1){put(b);put(c);put(d)}}}
  return this}
 quad(p0,p1,p2,p3,col,e){col=V.c(col);const ux=p1[0]-p0[0],uy=p1[1]-p0[1],uz=p1[2]-p0[2],vx=p3[0]-p0[0],vy=p3[1]-p0[1],vz=p3[2]-p0[2];
  let nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;const l=Math.hypot(nx,ny,nz)||1;nx/=l;ny/=l;nz/=l;
  this.v(p0[0],p0[1],p0[2],nx,ny,nz,col,e);this.v(p1[0],p1[1],p1[2],nx,ny,nz,col,e);this.v(p2[0],p2[1],p2[2],nx,ny,nz,col,e);
  this.v(p0[0],p0[1],p0[2],nx,ny,nz,col,e);this.v(p2[0],p2[1],p2[2],nx,ny,nz,col,e);this.v(p3[0],p3[1],p3[2],nx,ny,nz,col,e);
  this.v(p0[0],p0[1],p0[2],-nx,-ny,-nz,col,e);this.v(p2[0],p2[1],p2[2],-nx,-ny,-nz,col,e);this.v(p1[0],p1[1],p1[2],-nx,-ny,-nz,col,e);
  this.v(p0[0],p0[1],p0[2],-nx,-ny,-nz,col,e);this.v(p3[0],p3[1],p3[2],-nx,-ny,-nz,col,e);this.v(p2[0],p2[1],p2[2],-nx,-ny,-nz,col,e);return this}
 tri(a,b,c,col,e){col=V.c(col);const ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];let nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;const l=Math.hypot(nx,ny,nz)||1;nx/=l;ny/=l;nz/=l;
  this.v(a[0],a[1],a[2],nx,ny,nz,col,e);this.v(b[0],b[1],b[2],nx,ny,nz,col,e);this.v(c[0],c[1],c[2],nx,ny,nz,col,e);
  this.v(a[0],a[1],a[2],-nx,-ny,-nz,col,e);this.v(c[0],c[1],c[2],-nx,-ny,-nz,col,e);this.v(b[0],b[1],b[2],-nx,-ny,-nz,col,e);return this}
}
V.Mesh=Mesh;

/* ---------- sprite batch (additive billboards) ---------- */
class Sprites{
 constructor(cap){this.cap=cap||4000;this.a=new Float32Array(this.cap*6*9);this.n=0;this.rx=[1,0,0];this.ry=[0,1,0]}
 reset(){this.n=0}
 /* tile: 0 soft dot, 1 ring, 2 flare, 3 streak */
 add(x,y,z,s,tile,r,g,b,al,rot){if(this.n>=this.cap)return;const c=Math.cos(rot||0)*s*.5,sn=Math.sin(rot||0)*s*.5;const rx=this.rx,ry=this.ry;
  const ax=rx[0]*c+ry[0]*sn,ay=rx[1]*c+ry[1]*sn,az=rx[2]*c+ry[2]*sn,bx=-rx[0]*sn+ry[0]*c,by=-rx[1]*sn+ry[1]*c,bz=-rx[2]*sn+ry[2]*c;
  const u0=(tile&1)*.5,v0=(tile>>1)*.5,u1=u0+.5,v1=v0+.5;const A=this.a;let o=this.n*54;
  const P=(px,py,pz,u,v)=>{A[o++]=px;A[o++]=py;A[o++]=pz;A[o++]=u;A[o++]=v;A[o++]=r;A[o++]=g;A[o++]=b;A[o++]=al};
  P(x-ax-bx,y-ay-by,z-az-bz,u0,v1);P(x+ax-bx,y+ay-by,z+az-bz,u1,v1);P(x+ax+bx,y+ay+by,z+az+bz,u1,v0);
  P(x-ax-bx,y-ay-by,z-az-bz,u0,v1);P(x+ax+bx,y+ay+by,z+az+bz,u1,v0);P(x-ax+bx,y-ay+by,z-az+bz,u0,v0);this.n++}
 /* ribbon between two world points, facing camera */
 line(x1,y1,z1,x2,y2,z2,w,tile,r,g,b,al,camx,camy,camz){if(this.n>=this.cap)return;const dx=x2-x1,dy=y2-y1,dz=z2-z1;const mx=(x1+x2)/2-camx,my=(y1+y2)/2-camy,mz=(z1+z2)/2-camz;
  let sx=dy*mz-dz*my,sy=dz*mx-dx*mz,sz=dx*my-dy*mx;const l=Math.hypot(sx,sy,sz)||1;sx*=w/2/l;sy*=w/2/l;sz*=w/2/l;
  const u0=(tile&1)*.5,v0=(tile>>1)*.5,u1=u0+.5,v1=v0+.5;const A=this.a;let o=this.n*54;
  const P=(px,py,pz,u,v)=>{A[o++]=px;A[o++]=py;A[o++]=pz;A[o++]=u;A[o++]=v;A[o++]=r;A[o++]=g;A[o++]=b;A[o++]=al};
  P(x1-sx,y1-sy,z1-sz,u0,v1);P(x2-sx,y2-sy,z2-sz,u1,v1);P(x2+sx,y2+sy,z2+sz,u1,v0);P(x1-sx,y1-sy,z1-sz,u0,v1);P(x2+sx,y2+sy,z2+sz,u1,v0);P(x1+sx,y1+sy,z1+sz,u0,v0);this.n++}
}
V.Sprites=Sprites;

/* ---------- renderer ---------- */
const VS=`attribute vec3 aPos;attribute vec3 aNor;attribute vec4 aCol;
uniform mat4 uVP;uniform vec3 uOff;uniform vec3 uCam;uniform vec3 uBend;uniform vec3 uLight;uniform vec2 uFog;
varying vec3 vC;varying float vF;
void main(){vec3 p=aPos+uOff;float dz=max(p.z-uCam.z,0.0);p.y-=uBend.x*dz*dz;p.x+=uBend.y*dz*dz;
 vec3 n=normalize(aNor);float l=max(dot(n,uLight),0.0);float lit=0.40+0.60*l+0.10*n.y;
 vec3 base=aCol.rgb*lit+aCol.rgb*aCol.a*1.25;vC=base;
 float d=length(p-uCam);vF=clamp((d-uFog.x)/(uFog.y-uFog.x),0.0,1.0);
 gl_Position=uVP*vec4(p,1.0);}`;
const FS=`precision mediump float;varying vec3 vC;varying float vF;uniform vec3 uFogC;uniform vec3 uFlash;
void main(){gl_FragColor=vec4(mix(vC,uFogC,vF)+uFlash,1.0);}`;
const SVS=`attribute vec3 aPos;attribute vec2 aUV;attribute vec4 aCol;uniform mat4 uVP;uniform vec3 uCam;uniform vec3 uBend;varying vec2 vUV;varying vec4 vC;
void main(){vec3 p=aPos;float dz=max(p.z-uCam.z,0.0);p.y-=uBend.x*dz*dz;p.x+=uBend.y*dz*dz;vUV=aUV;vC=aCol;gl_Position=uVP*vec4(p,1.0);}`;
const SFS=`precision mediump float;varying vec2 vUV;varying vec4 vC;uniform sampler2D uTex;
void main(){vec4 t=texture2D(uTex,vUV);gl_FragColor=vec4(vC.rgb*t.r*vC.a,1.0);}`;
const KVS=`attribute vec2 aP;varying vec2 vP;void main(){vP=aP;gl_Position=vec4(aP,0.9999,1.0);}`;
const KFS=`precision mediump float;varying vec2 vP;uniform vec3 uTop;uniform vec3 uBot;uniform vec3 uGlow;uniform float uT;uniform float uAsp;
float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
void main(){float y=vP.y*0.5+0.5;vec3 c=mix(uBot,uTop,pow(clamp(y,0.0,1.0),0.7));
 float hz=exp(-abs(y-0.42)*7.0);c+=uGlow*hz*0.65;
 vec2 g=vec2(vP.x*uAsp,vP.y)*38.0;vec2 id=floor(g);float s=h(id);if(s>0.985&&y>0.5){vec2 f=fract(g)-0.5;float d=length(f);c+=vec3(1.0)*smoothstep(0.25,0.0,d)*(0.5+0.5*sin(uT*2.0+s*50.0))*(y-0.4);}
 vec2 q=vec2((vP.x-0.35)*uAsp,vP.y-0.30);float sun=smoothstep(0.30,0.28,length(q));c=mix(c,uGlow*1.25+vec3(0.15),sun*0.55);
 gl_FragColor=vec4(c,1.0);}`;

function prog(gl,vs,fs,attrs){const mk=(t,s)=>{const sh=gl.createShader(t);gl.shaderSource(sh,s);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw new Error('shader: '+gl.getShaderInfoLog(sh));return sh};
 const p=gl.createProgram();gl.attachShader(p,mk(gl.VERTEX_SHADER,vs));gl.attachShader(p,mk(gl.FRAGMENT_SHADER,fs));attrs.forEach((a,i)=>gl.bindAttribLocation(p,i,a));gl.linkProgram(p);
 if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw new Error('link: '+gl.getProgramInfoLog(p));
 p.u={};const n=gl.getProgramParameter(p,gl.ACTIVE_UNIFORMS);for(let i=0;i<n;i++){const u=gl.getActiveUniform(p,i);p.u[u.name]=gl.getUniformLocation(p,u.name)}return p}

class Renderer{
 constructor(canvas){this.cv=canvas;const gl=this.gl=canvas.getContext('webgl',{antialias:false,alpha:false,powerPreference:'high-performance'})||canvas.getContext('experimental-webgl');if(!gl)throw new Error('WebGL недоступен');
  this.pm=prog(gl,VS,FS,['aPos','aNor','aCol']);this.ps=prog(gl,SVS,SFS,['aPos','aUV','aCol']);this.pk=prog(gl,KVS,KFS,['aP']);
  this.dyn=new Mesh(90000);this.spr=new Sprites(5000);
  this.dynBuf=gl.createBuffer();this.sprBuf=gl.createBuffer();this.skyBuf=gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER,this.skyBuf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
  this.makeTex();this.vp=M.ident();this.vw=M.ident();this.pj=M.ident();this.scale=1;this.time=0;this.cam={x:0,y:3,z:-7,fov:1.05,roll:0};
  this.lost=false;canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();this.lost=true},false);canvas.addEventListener('webglcontextrestored',()=>{location.reload()},false);
  this.resize()}
 makeTex(){const gl=this.gl,c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');x.fillStyle='#000';x.fillRect(0,0,128,128);
  const rad=(cx,cy,r)=>{const g=x.createRadialGradient(cx,cy,0,cx,cy,r);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.35,'rgba(255,255,255,.55)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.beginPath();x.arc(cx,cy,r,0,TAU);x.fill()};
  rad(32,32,31);
  const rg=x.createRadialGradient(96,32,10,96,32,31);rg.addColorStop(0,'rgba(255,255,255,0)');rg.addColorStop(.62,'rgba(255,255,255,1)');rg.addColorStop(.8,'rgba(255,255,255,.35)');rg.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=rg;x.fillRect(64,0,64,64);
  x.save();x.translate(32,96);rad(0,0,12);x.fillStyle='rgba(255,255,255,.9)';x.fillRect(-1.5,-30,3,60);x.fillRect(-30,-1.5,60,3);x.restore();
  const sg=x.createLinearGradient(64,96,128,96);sg.addColorStop(0,'rgba(255,255,255,0)');sg.addColorStop(.5,'rgba(255,255,255,1)');sg.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=sg;x.fillRect(66,84,60,24);
  const t=this.tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,c);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE)}
 resize(){const cv=this.cv,dpr=Math.min(window.devicePixelRatio||1,2);const q=V.quality||'high';const s=q==='low'?.62:q==='med'?.85:1;this.scale=s;
  const w=Math.max(2,Math.floor(cv.clientWidth*dpr*s)),h=Math.max(2,Math.floor(cv.clientHeight*dpr*s));if(cv.width!==w||cv.height!==h){cv.width=w;cv.height=h}this.asp=w/h}
 upload(mesh){const gl=this.gl;const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,mesh.a.subarray(0,mesh.n*10),gl.STATIC_DRAW);return{buf:b,count:mesh.n}}
 free(c){if(c&&c.buf){this.gl.deleteBuffer(c.buf);c.buf=null}}
 /* env: {top,bot,glow,fog,fogN,fogF,light,bend,curve}; chunks:[{buf,count,off}] */
 render(cam,env,chunks,opt){const gl=this.gl;if(this.lost)return;opt=opt||{};this.resize();gl.viewport(0,0,this.cv.width,this.cv.height);
  const sh=opt.shake||0;const ex=cam.x+(sh?(Math.random()-.5)*sh:0),ey=cam.y+(sh?(Math.random()-.5)*sh:0),ez=cam.z;
  M.persp(this.pj,cam.fov,this.asp,.3,420);const rl=cam.roll||0;M.look(this.vw,ex,ey,ez,cam.tx,cam.ty,cam.tz,Math.sin(rl),Math.cos(rl),0);M.mul(this.vp,this.pj,this.vw);
  const vw=this.vw;this.spr.rx=[vw[0],vw[4],vw[8]];this.spr.ry=[vw[1],vw[5],vw[9]];this.camPos=[ex,ey,ez];
  gl.clearColor(env.fog[0],env.fog[1],env.fog[2],1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
  /* sky */
  gl.disable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);gl.useProgram(this.pk);gl.bindBuffer(gl.ARRAY_BUFFER,this.skyBuf);gl.enableVertexAttribArray(0);gl.disableVertexAttribArray(1);gl.disableVertexAttribArray(2);gl.vertexAttribPointer(0,2,gl.FLOAT,false,8,0);
  const k=this.pk.u;gl.uniform3fv(k.uTop,env.top);gl.uniform3fv(k.uBot,env.bot);gl.uniform3fv(k.uGlow,env.glow);gl.uniform1f(k.uT,this.time);gl.uniform1f(k.uAsp,this.asp);gl.drawArrays(gl.TRIANGLES,0,3);
  /* solid pass */
  gl.enable(gl.DEPTH_TEST);gl.enable(gl.CULL_FACE);gl.cullFace(gl.BACK);gl.useProgram(this.pm);const u=this.pm.u;
  gl.uniformMatrix4fv(u.uVP,false,this.vp);gl.uniform3f(u.uCam,ex,ey,ez);gl.uniform3f(u.uBend,env.bend==null?.0005:env.bend,env.curve||0,0);gl.uniform3fv(u.uLight,env.light||[.45,.8,-.4]);gl.uniform2f(u.uFog,env.fogN,env.fogF);gl.uniform3fv(u.uFogC,env.fog);gl.uniform3fv(u.uFlash,opt.flash||[0,0,0]);
  gl.enableVertexAttribArray(0);gl.enableVertexAttribArray(1);gl.enableVertexAttribArray(2);
  const bind=()=>{gl.vertexAttribPointer(0,3,gl.FLOAT,false,40,0);gl.vertexAttribPointer(1,3,gl.FLOAT,false,40,12);gl.vertexAttribPointer(2,4,gl.FLOAT,false,40,24)};
  if(chunks)for(let i=0;i<chunks.length;i++){const c=chunks[i];if(!c.buf||!c.count)continue;gl.bindBuffer(gl.ARRAY_BUFFER,c.buf);bind();gl.uniform3f(u.uOff,0,0,0);gl.drawArrays(gl.TRIANGLES,0,c.count)}
  const d=this.dyn;if(d.n){gl.bindBuffer(gl.ARRAY_BUFFER,this.dynBuf);gl.bufferData(gl.ARRAY_BUFFER,d.a.subarray(0,d.n*10),gl.STREAM_DRAW);bind();gl.uniform3f(u.uOff,0,0,0);gl.drawArrays(gl.TRIANGLES,0,d.n)}
  /* additive sprites */
  const sp=this.spr;if(sp.n){gl.useProgram(this.ps);const s=this.ps.u;gl.uniformMatrix4fv(s.uVP,false,this.vp);gl.uniform3f(s.uCam,ex,ey,ez);gl.uniform3f(s.uBend,env.bend==null?.0005:env.bend,env.curve||0,0);
   gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,this.tex);gl.uniform1i(s.uTex,0);gl.bindBuffer(gl.ARRAY_BUFFER,this.sprBuf);gl.bufferData(gl.ARRAY_BUFFER,sp.a.subarray(0,sp.n*54),gl.STREAM_DRAW);
   gl.vertexAttribPointer(0,3,gl.FLOAT,false,36,0);gl.vertexAttribPointer(1,2,gl.FLOAT,false,36,12);gl.vertexAttribPointer(2,4,gl.FLOAT,false,36,20);
   gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE);gl.depthMask(false);gl.disable(gl.CULL_FACE);gl.drawArrays(gl.TRIANGLES,0,sp.n*6);gl.depthMask(true);gl.disable(gl.BLEND)}
 }
 /* project world point to screen fractions (0..1), returns null if behind */
 project(x,y,z){const m=this.vp;const w=m[3]*x+m[7]*y+m[11]*z+m[15];if(w<=0.01)return null;return[(m[0]*x+m[4]*y+m[8]*z+m[12])/w*.5+.5,1-((m[1]*x+m[5]*y+m[9]*z+m[13])/w*.5+.5),w]}
}
V.Renderer=Renderer;
})();
