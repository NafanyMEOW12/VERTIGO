/* VERTIGO world: chunked level generation, six district styles, colliders, dynamic hazards */
(function(){
'use strict';
const V=window.V;const S=Math.sin,Cs=Math.cos,PI=Math.PI;
const LW=2.2,CH=48,clamp=V.clamp;V.LW=LW;V.CH=CH;
const laneX=i=>(i-1)*LW;V.laneX=laneX;
const GOLD=V.c('#ffcf3a'),RED=V.c('#ff3a4a'),WHITE=[.95,.95,.97],DARK=V.c('#0c0e18');
const pick=(r,a)=>a[Math.floor(r()*a.length)];
const top=(o,z)=>o.ramp?o.ramp[0]+(o.ramp[1]-o.ramp[0])*V.clamp((z-o.z0)/(o.z1-o.z0),0,1):o.y1;
V.solidTop=top;

class World{
 constructor(o){this.o=o;this.mode=o.mode||'campaign';this.rng=V.rng(o.seed||7);this.chunks=new Map();this.movers=[];this.q=[];this.cz=0;this.len=o.len==null?1e9:o.len;this.dist=o.dist||0;
  this.arenaZ=Infinity;this.nextCp=o.cp?o.cp:1e9;this.cpEvery=o.cp||0;this.cps=[];this.secretLeft=o.secret?1:0;this.secretDone=false;this.noBoss=!!o.noBoss;this.first=true;this.segN=0;this.endless=this.mode==='endless';
  this.baked=new Set();this.scratch=null;this.segs=[]}
 dAt(z){return this.endless?Math.floor(Math.max(0,z)/1100)%6:this.dist}
 th(z){return V.DIST[this.dAt(z)].th}
 diff(z){if(this.endless)return V.clamp(z/3500,0,1);const p=V.clamp(z/this.len,0,1);return V.clamp(this.dist*.1+p*.45,0,1)}
 chunk(i){let c=this.chunks.get(i);if(!c){c={i,solids:[],st:[],dyn:[],coins:[],items:[],mesh:null,hz:0};this.chunks.set(i,c)}return c}
 add(o){const a=Math.floor(o.z0/CH),b=Math.floor(o.z1/CH);if(o.solid!==false&&!o.mover)for(let i=a;i<=b;i++)this.chunk(i).solids.push(o);
  const home=this.chunk(Math.floor((o.z0+o.z1)/2/CH));if(o.d)home.st.push(o);if(o.dd&&!o.mover)home.dyn.push(o);if(o.mover)this.movers.push(o);return o}
 coin(x,y,z,v){this.chunk(Math.floor(z/CH)).coins.push({x,y,z,got:0,v:v||2})}
 item(t,x,y,z,e){const it=Object.assign({t,x,y,z,got:0},e||{});this.chunk(Math.floor(z/CH)).items.push(it);return it}
 coinLine(x,y,z0,z1,step){step=step||2.4;for(let z=z0;z<=z1;z+=step)this.coin(x,y,z)}
 coinArc(x,y,z0,z1,h,n){n=n||7;for(let i=0;i<n;i++){const t=i/(n-1);this.coin(x,y+S(t*PI)*h,z0+(z1-z0)*t)}}
 /* ---------- primitives ---------- */
 slab(z0,z1,y,x0,x1,o){x0=x0==null?-3.5:x0;x1=x1==null?3.5:x1;const w=this,dk=this.dAt(z0);const s=Object.assign({k:'g',x0,x1,y0:-40,y1:y,z0,z1,ledge:y>.4,dk},o||{});s.d=m=>w.gDraw(m,s);return this.add(s)}
 ramp(z0,z1,ya,yb,x0,x1){const s=this.slab(z0,z1,Math.max(ya,yb),x0,x1,{ramp:[ya,yb],ledge:false});return s}
 block(lane,z0,len,h,y,o){o=o||{};const w=this,th=this.th(z0),x=laneX(lane),s=Object.assign({k:'b',x0:x-1.0,x1:x+1.0,y0:y,y1:y+h,z0,z1:z0+len,ledge:h>1.2&&h<3.7},o);
  const col=o.col||V.mixc(V.c(pick(this.rng,th.bld)),V.c(th.acc),.18);
  s.d=m=>{m.box(x,y+h/2,z0+len/2,2.0,h,len,col,.05);m.box(x,y+h+.05,z0+len/2,2.06,.1,len+.06,th.acc,s.ledge?1.3:.5);m.box(x,y+h*.5,z0-.01,1.7,.1,.03,th.acc2,.9);
   if(h>1.8){m.box(x-.99,y+h*.5,z0+len/2,.03,h*.8,len*.7,th.win,.5);m.box(x+.99,y+h*.5,z0+len/2,.03,h*.8,len*.7,th.win,.5)}};return this.add(s)}
 hurdle(lane,z,y,o){const w=this,th=this.th(z),x=laneX(lane),s=Object.assign({k:'b',x0:x-1.0,x1:x+1.0,y0:y,y1:y+.9,z0:z,z1:z+.5,ledge:false},o||{});
  s.d=m=>{m.box(x,y+.45,z+.25,2.0,.9,.5,V.c('#2a1418'),.1);for(let i=0;i<5;i++)m.box(x-.8+i*.4,y+.5,z-.01,.2,.7,.03,i%2?WHITE:RED,.5);m.box(x,y+.92,z+.25,2.04,.07,.54,RED,1.4)};return this.add(s)}
 beam(lanes,z,y,o){const th=this.th(z),a=laneX(Math.min(...lanes))-1.05,b=laneX(Math.max(...lanes))+1.05,cx=(a+b)/2,wd=b-a;
  const s=Object.assign({k:'bm',x0:a,x1:b,y0:y+1.05,y1:y+2.5,z0:z,z1:z+.6},o||{});
  s.d=m=>{m.box(cx,y+1.8,z+.3,wd,.9,.5,V.c('#1b1e30'),.1);m.box(cx,y+1.36,z+.3,wd,.08,.54,th.acc2,1.5);m.box(a+.1,y+1.1,z+.3,.14,2.3,.14,V.c('#2a2f48'));m.box(b-.1,y+1.1,z+.3,.14,2.3,.14,V.c('#2a2f48'));
   for(let i=0;i<Math.floor(wd/1.1);i++)m.box(a+.7+i*1.1,y+1.85,z-.01,.5,.34,.03,th.acc,.9)};return this.add(s)}
 glass(z,y,o){const th=this.th(z),s=Object.assign({k:'b',x0:-3.5,x1:3.5,y0:y,y1:y+3.4,z0:z,z1:z+.5,brk:true,ledge:false},o||{});
  s.d=m=>{m.box(0,y+1.7,z+.25,7,3.4,.18,V.mixc(V.c(th.acc),[.1,.15,.25],.65),.55);m.box(0,y+3.4,z+.25,7.1,.12,.3,th.acc,1.6);m.box(0,y+.06,z+.25,7.1,.12,.3,th.acc,1.6);for(let i=-3;i<=3;i++)m.box(i,y+1.7,z+.26,.06,3.3,.2,th.acc,1.2)};return this.add(s)}
 wallPanel(side,z0,z1,y){const th=this.th(z0),x=side*3.4,s={k:'w',x0:x-.3,x1:x+.3,y0:y-20,y1:y+9,z0,z1,side};
  s.d=m=>{const L=z1-z0;m.box(x,y+3.5,(z0+z1)/2,.6,10,L,V.c('#171a30'),.05);m.box(x-side*.31,y+1.9,(z0+z1)/2,.03,.14,L,th.acc,1.7);m.box(x-side*.31,y+3.6,(z0+z1)/2,.03,.08,L,th.acc2,1.2);
   for(let z=z0+2;z<z1-1;z+=4)m.box(x-side*.31,y+2.7,z,.03,1.1,1.6,th.win,.5)};return this.add(s)}
 laser(z,y,low,per,duty,ph){const th=this.th(z),w=this,y0=low?y:y+1.0,y1=low?y+.55:y+1.65,yc=(y0+y1)/2;const s={k:'hz',x0:-3.5,x1:3.5,y0,y1,z0:z-.4,z1:z+.4,per,duty,ph};
  s.on=t=>((t/per+ph)%1)<duty;s.warn=t=>{const u=((t/per+ph)%1);return u>duty-.18&&u<duty?0:(u<duty?-1:(1-u<.15?1:0))};
  s.test=(p,t)=>s.on(t)&&p.hy>y0&&p.y<y1;
  s.d=m=>{for(const sd of[-1,1]){m.box(sd*3.75,y+.9,z,.4,1.9,.4,V.c('#1b1e30'),.1);m.box(sd*3.55,yc,z,.14,.3,.3,th.acc2,1.4)}};
  s.dd=(m,sp,t)=>{if(s.on(t)){m.box(0,yc,z,7.1,.14,.14,[1,.3,.4],2.2);m.box(0,yc,z,7.1,.04,.04,WHITE,2.5)}else{const u=((t/per+ph)%1);if(u>.78&&u<1||u<.05)m.box(0,yc,z,7.1,.03,.03,[.9,.2,.3],1.2*(.5+.5*S(t*30)))}};return this.add(s)}
 elec(lane,z0,len,y,per,ph){const th=this.th(z0),x=laneX(lane);const s={k:'hz',x0:x-1.0,x1:x+1.0,y0:y,y1:y+.5,z0,z1:z0+len,per,ph};s.on=t=>((t/per+ph)%1)<.5;s.test=(p,t)=>s.on(t)&&p.y<y+.4;
  s.d=m=>{m.box(x,y+.01,z0+len/2,2,.04,len,V.c('#2a1a10'),.2)};s.dd=(m,sp,t)=>{const on=s.on(t),u=((t/per+ph)%1);if(on){m.box(x,y+.08,z0+len/2,1.9,.12,len,[1,.9,.2],1.9);for(let i=0;i<4;i++)m.box(x+S(t*40+i*3)*.8,y+.3+i*.12,z0+((t*9+i*1.7)%len),.05,.5,.05,[.8,.9,1],2.5)}else if(u>.38)m.box(x,y+.05,z0+len/2,1.9,.05,len,[1,.5,.1],1.1)};return this.add(s)}
 crane(z,per,ph,y){const th=this.th(z),y0=y||0;const s={k:'hz',x0:-3.6,x1:3.6,y0:y0,y1:y0+2.4,z0:z-1,z1:z+1,per,ph};s.bx=t=>S(t*6.28/per+ph)*3.0;s.test=(p,t)=>Math.abs(p.x-s.bx(t))<1.25&&p.y<y0+2.3&&p.hy>y0+.2;
  s.d=m=>{for(const sd of[-1,1])m.box(sd*4.4,y0+4,z,.5,8,.5,V.c('#3a3322'));m.box(0,y0+8,z,9.4,.5,.9,th.acc,.35)};
  s.dd=(m,sp,t)=>{const x=s.bx(t);m.box(x*.5,y0+5,z,.06,6,.06,[.6,.6,.6]);m.ball(x,y0+1.1,z,.95,V.c('#4a4a52'),.1,7);m.ball(x,y0+1.1,z+.7,.2,[1,.4,.2],1.6,4)};return this.add(s)}
 spin(lane,z,y){const th=this.th(z),x=laneX(lane),s={k:'hz',x0:x-3.5,x1:x+3.5,y0:y,y1:y+1.6,z0:z-1.8,z1:z+1.8};const sp=1.9+this.rng()*.5,ph=this.rng()*6;s.ang=t=>t*sp+ph;
  s.test=(p,t)=>{const a=s.ang(t);const dx=p.x-x,dz=p.z-z;if(p.y>y+1.2||p.hy<y+.2)return false;for(const q of[0,PI]){const ux=Cs(a+q),uz=S(a+q);const tt=dx*ux+dz*uz;if(tt>0&&tt<3.4){const px=dx-ux*tt,pz=dz-uz*tt;if(Math.hypot(px,pz)<.55)return true}}return false};
  s.d=m=>{m.prism(x,y,z,.35,.3,.9,6,V.c('#2a2f48'),.1)};s.dd=(m,sp2,t)=>{const a=s.ang(t);m.push();m.tr(x,y+.55,z);m.ry(-a);m.box(0,0,0,6.9,.22,.22,th.acc2,1.4);m.box(1.6,0,0,.5,.32,.32,V.c('#ff3a4a'),1.5);m.box(-1.6,0,0,.5,.32,.32,V.c('#ff3a4a'),1.5);m.pop()};return this.add(s)}
 drone(lane,z,y){const x=laneX(lane),th=this.th(z),s={k:'bm',x0:x-.7,x1:x+.7,y0:y+.9,y1:y+1.8,z0:z,z1:z+.8,solid:true};
  s.dd=(m,sp,t)=>{m.push();m.tr(x,y+1.35+S(t*4+z)*.08,z+.4);m.box(0,0,0,1.1,.5,.8,V.c('#232842'),.1);m.box(0,0,.42,.5,.2,.04,[1,.2,.3],1.8);for(const sd of[-1,1]){m.push();m.tr(sd*.7,.1,0);m.ry(t*25);m.box(0,0,0,.7,.04,.1,V.c('#8a93b0'));m.pop()}m.pop()};return this.add(s)}
 train(lane,z,len,sp,y){const th=this.th(z),x=laneX(lane),s={k:'b',x0:x-1.05,x1:x+1.05,y0:y,y1:y+2.7,z0:z,z1:z+len,ledge:true,mover:true,vz:0,sp,base:z,len,trig:105,act:false,x};
  s.dd=(m,sp2,t)=>{m.push();m.tr(x,y,s.z0);m.box(0,1.4,len/2,2.1,2.6,len,V.c('#2c3a46'),.05);m.box(0,2.75,len/2,2.14,.12,len,th.acc,.8);m.box(0,1.9,len/2,2.14,.5,len*.9,V.c('#101a22'),.1);for(let i=0;i<Math.floor(len/2.2);i++)m.box(0,1.95,1+i*2.2,2.16,.34,1.4,th.win,.9);m.box(0,.8,-.02,1.6,.3,.06,[1,.95,.7],1.8);m.ball(-.6,1.3,-.05,.2,[1,.95,.7],2,4);m.ball(.6,1.3,-.05,.2,[1,.95,.7],2,4);m.pop()};
  s.d=null;return this.add(s)}
 collapse(lane,z0,len,y){const th=this.th(z0),x=laneX(lane),w=this;const s={k:'g',x0:x-1.1,x1:x+1.1,y0:-40,y1:y,z0,z1:z0+len,cz0:z0,state:0,t0:0,fy:0,ledge:false,mover:true,collapse:true,tt:0};
  s.dd=(m,sp,t)=>{if(s.dead)return;const sh=s.state===1?S(t*60)*.03:0;const fy=s.state===2?s.fy:0;m.box(x+sh,y-.3+fy,z0+len/2,2.1,.6,len-.06,s.state?V.c('#4a2230'):V.c('#2a2748'),s.state?.8:.1);m.box(x+sh,y+.01+fy,z0+len/2,1.9,.05,len-.3,s.state?[1,.4,.3]:V.c(th.acc),s.state?1.6:.9)};return this.add(s)}
 elevator(lane,z0,len,yLo,yHi,per,ph){const th=this.th(z0),x=laneX(lane);const s={k:'g',x0:x-1.1,x1:x+1.1,y0:-40,y1:yLo,z0,z1:z0+len,ledge:true,mover:true,elev:true,yLo,yHi,per,ph};
  s.dd=(m,sp,t)=>{const y=yLo+(yHi-yLo)*(.5+.5*S(t*6.28/per+ph));s.y1=y;m.box(x,y-.25,z0+len/2,2.2,.5,len,V.c('#2a3d52'),.1);m.box(x,y+.01,z0+len/2,2.0,.05,len-.2,th.acc,1.2);m.box(x,y-5,z0+len/2,.2,10,.2,th.acc,.5)};return this.add(s)}
 pad(lane,z,y,kind){const x=laneX(lane);const it=this.item(kind==='jump'?'padj':'padb',x,y+.05,z,{lane});return it}
 /* ---------- ground / decor drawing ---------- */
 gDraw(m,s){const th=V.DIST[s.dk].th,k=s.dk,x0=s.x0,x1=s.x1,z0=s.z0,z1=s.z1,y=s.y1,L=z1-z0,cx=(x0+x1)/2,wd=x1-x0;
  if(s.ramp){const a=s.ramp[0],b=s.ramp[1];m.quad([x0,a,z0],[x1,a,z0],[x1,b,z1],[x0,b,z1],th.gA,.05);m.quad([x0,a-.3,z0],[x0,b-.3,z1],[x0,b,z1],[x0,a,z0],th.gB,0);m.quad([x1,a,z0],[x1,b,z1],[x1,b-.3,z1],[x1,a-.3,z0],th.gB,0);
   m.quad([x0,a+.02,z0],[x0+.15,a+.02,z0],[x0+.15,b+.02,z1],[x0,b+.02,z1],th.acc,1.1);m.quad([x1-.15,a+.02,z0],[x1,a+.02,z0],[x1,b+.02,z1],[x1-.15,b+.02,z1],th.acc,1.1);return}
  const depth=k===0?14:k===1||k===3?.9:1.6;const body=k===0?th.gB:k===4?V.mixc(V.c(th.gA),V.c(th.acc),.25):th.gA;
  m.box(cx,y-depth/2,(z0+z1)/2,wd,depth,L,body,k===4?.15:.03);m.box(cx,y+.001,(z0+z1)/2,wd-.4,.02,L,V.shade(V.c(th.gA),1.25),.02);
  m.box(x0+.1,y+.04,(z0+z1)/2,.18,.08,L,th.acc,1.2);m.box(x1-.1,y+.04,(z0+z1)/2,.18,.08,L,th.acc,1.2);
  if(wd>6){for(let z=z0+1.5;z<z1-1;z+=3.2){m.box(-LW/2,y+.015,z,.08,.02,1.3,th.acc2,.7);m.box(LW/2,y+.015,z,.08,.02,1.3,th.acc2,.7)}}
  if(k===0&&L>6){for(const sd of[-1,1]){m.box(sd*3.62,y+.28,(z0+z1)/2,.22,.56,L,th.gB,.05);m.box(sd*3.62,y+.58,(z0+z1)/2,.26,.05,L,th.acc,.9)}}
  else if(k===1){for(let z=z0+3;z<z1-2;z+=9){for(const sd of[-1,1])m.box(sd*3.3,y-6,z,.4,12,.4,V.c('#4a3a2a'));m.box(0,y-4.5,z,7.2,.3,.3,V.c('#4a3a2a'))}for(let z=z0;z<z1;z+=2.4){m.box(x0+.35,y+.03,z+.6,.5,.02,1.2,z%4<2.4?V.c('#ffb21e'):V.c('#1a1a1a'),.5);m.box(x1-.35,y+.03,z+.6,.5,.02,1.2,V.c('#ffb21e'),.5)}}
  else if(k===2){for(const sd of[-1,1])for(const q of[-.8,.8]){m.box(sd*LW*.5+q*.05,y+.06,(z0+z1)/2,.08,.1,L,V.c('#8a949a'),.1)}for(let z=z0+1;z<z1;z+=1.6)m.box(0,y+.03,z,7,.06,.3,V.c('#3a3430'))}
  else if(k===3){for(let z=z0+2;z<z1;z+=12){for(const sd of[-1,1]){m.box(sd*3.9,y+1.3,z,.12,2.6,.12,th.acc,.9);m.box(sd*3.9,y+2.6,z,.4,.12,.4,th.acc2,1.3)}for(const sd of[-1,1])m.box(sd*3.65,y+.32,z+6,.1,.5,12,V.c('#242240'),.1)}}
  else if(k===4){for(let z=z0+2;z<z1;z+=4)m.box(0,y+.012,z,wd-.5,.02,.06,V.c('#ffffff'),.8);for(let x=-3;x<=3;x+=1.5)m.box(x,y+.012,(z0+z1)/2,.05,.02,L,V.c('#ffffff'),.6)}
  else if(k===5){for(let z=z0+2;z<z1;z+=4)m.box(0,y+.012,z,wd-.4,.02,.08,th.acc,1.3);for(let x=-3;x<=3;x+=1.1)m.box(x,y+.012,(z0+z1)/2,.05,.02,L,th.acc,1)}}
 /* side buildings, skyline and district props for [z0,z1) */
 decor(z0,z1){const r=this.rng,k=this.dAt(z0),th=V.DIST[k].th,ch=this.chunk(Math.floor((z0+z1)/2/CH));
  const D=(fn)=>ch.st.push({d:fn});
  if(k===2){/* tunnel shell */const L=z1-z0;D(m=>{for(const sd of[-1,1]){m.box(sd*6.6,3.4,(z0+z1)/2,.6,8,L,V.c('#171f1c'),.05);m.box(sd*6.28,1.6,(z0+z1)/2,.04,.1,L,th.acc,1.3)}m.box(0,7.2,(z0+z1)/2,13.6,.6,L,V.c('#0f1614'),.03);for(let z=z0+3;z<z1;z+=12){m.box(0,6.85,z,6,.1,.5,th.acc,1.6);for(const sd of[-1,1])m.box(sd*6.2,3.4,z,.5,7,.7,V.c('#212b27'),.05)}for(let z=z0;z<z1;z+=24)for(const sd of[-1,1])m.box(sd*6.28,2.5,z+8,.04,.7,3,th.acc2,1)});return}
  for(let z=z0;z<z1;z+=8+r()*6){for(const sd of[-1,1]){const x=sd*(7+r()*5),w=3+r()*4,d=5+r()*5;let h;
   if(k===0)h=-1.5+r()*3.5;else if(k===1)h=-3+r()*14;else if(k===3)h=-9+r()*6;else if(k===4)h=-2+r()*22;else h=-4+r()*10;
   const c=V.c(pick(r,th.bld)),zz=z;D(m=>{const top=Math.max(h,1);m.box(x,(top-30)/2,zz,w,top+30,d,c,.04);if(h>3){m.box(x-sd*w/2*.0,h*.55,zz-d/2-.01,w*.78,h*.7,.03,th.win,.55)}m.box(x,top+.05,zz,w+.1,.1,d+.1,th.acc,.7)})}}
  for(let z=z0;z<z1;z+=20+r()*12){const sd=r()<.5?-1:1,x=sd*(26+r()*40),h=30+r()*50,w=8+r()*8,c=V.shade(V.c(pick(r,th.bld)),1.3),zz=z;D(m=>{m.box(x,h/2-20,zz,w,h+40,w,c,.1);m.box(x-sd*w/2,h*.6,zz,.1,h*.5,w*.7,th.win,.8);m.box(x,h-19.8,zz,w+.2,.3,w+.2,th.acc2,1)})}
  if(k===0){for(let z=z0+6;z<z1;z+=40+r()*30){const sd=r()<.5?-1:1,zz=z,c=r()<.5?th.acc:th.acc2;D(m=>{m.box(sd*6.5,3.2,zz,.2,6.4,.2,V.c('#1a1e30'));m.box(sd*6.5,6.2,zz,.3,2.4,4,c,1.6);m.box(sd*6.5,6.2,zz,.32,2.0,3.6,[0,0,0],0)})}}
  if(k===1){for(let z=z0+10;z<z1;z+=60+r()*30){const sd=r()<.5?-1:1,zz=z;D(m=>{m.box(sd*10,12,zz,.7,26,.7,V.c('#6a5a2a'),.1);m.box(sd*5,23,zz,11,.5,.5,V.c('#6a5a2a'),.1);m.box(sd*3,21,zz,.05,4,.05,V.c('#aaa'));m.box(sd*10.4,25,zz,.4,.4,.4,[1,.2,.2],2)})}}
  if(k===3){for(let z=z0+4;z<z1;z+=80){const zz=z;D(m=>{for(const sd of[-1,1]){m.box(sd*7,12,zz,.9,26,.9,V.c('#2a2748'),.1);m.box(sd*7,25.5,zz,1.6,1,1.6,th.acc2,1.3)}m.box(0,25.5,zz,14.5,.6,.6,V.c('#2a2748'),.1)})}}
  if(k===4){for(let z=z0+3;z<z1;z+=30+r()*20){const sd=r()<.5?-1:1,zz=z;D(m=>{m.box(sd*5.6,10,zz,.1,22,3.5,V.c('#bfeaff'),.7);m.box(sd*5.6,21,zz,.2,.2,3.7,th.acc,1.6)})}}
  if(k===5){for(let z=z0+3;z<z1;z+=26+r()*16){const sd=r()<.5?-1:1,zz=z;D(m=>{m.prism(sd*6.5,-4,zz,.9,.9,14,6,V.c('#2a1014'),.1);m.prism(sd*6.5,8,zz,.95,.95,.25,6,th.acc,1.7);m.box(sd*6.5,10,zz,1.4,.5,1.4,th.acc,1.5)})}}}
 /* ---------- segment library ---------- */
 sFlat(z,len,o){o=o||{};this.slab(z,z+len,0);if(!o.bare){const l=Math.floor(this.rng()*3);this.coinLine(laneX(l),.8,z+4,z+len-4)}return len}
 sHurdles(z,len,dif){const r=this.rng;this.slab(z,z+len,0);let zz=z+8;while(zz<z+len-6){const n=1+(r()<.35+dif*.4?1:0),free=Math.floor(r()*3),lanes=[0,1,2].filter(i=>i!==free||n===1&&false);const blocked=n===1?[Math.floor(r()*3)]:lanes.filter(i=>i!==free);
  const slide=r()<.45;if(slide)this.beam(blocked,zz,0);else for(const l of blocked)this.hurdle(l,zz,0);const fl=[0,1,2].find(i=>!blocked.includes(i));this.coinLine(laneX(fl),.8,zz-6,zz+4,2);zz+=12+r()*4}return len}
 sBeams(z,len,dif){const r=this.rng;this.slab(z,z+len,0);let zz=z+8;while(zz<z+len-6){const a=Math.floor(r()*3),b=r()<.5?a:Math.min(2,a+1);const lanes=a===b?[a]:[a,b];this.beam(lanes,zz,0);if(r()<.4)this.hurdle((a+2)%3,zz+6,0);this.coinLine(laneX(a),.6,zz-4,zz+3,1.4);zz+=13+r()*3}return len}
 sBlocks(z,len,dif){const r=this.rng;this.slab(z,z+len,0);let zz=z+9;while(zz<z+len-8){const free=Math.floor(r()*3),h=2.3+r()*1.1;for(let l=0;l<3;l++){if(l===free)continue;if(r()<.75)this.block(l,zz,6+r()*5,h,0);}this.coinLine(laneX(free),.8,zz-7,zz+8,2.2);const bl=(free+1)%3;this.coinLine(laneX(bl),h+.9,zz+1,zz+6,1.6);zz+=19+r()*5}return len}
 sGap(z,len,dif){const g=Math.round(5.5+dif*5+this.rng()*2),run=15,land=14;this.slab(z,z+run,0);this.slab(z+run+g,z+run+g+land,0);const l=Math.floor(this.rng()*3);this.coinArc(laneX(l),1.4,z+run-2,z+run+g+2,2.2,Math.max(5,Math.floor(g/1.6)));this.coinLine(laneX((l+1)%3),.8,z+run+g+3,z+run+g+land-2);if(dif>.45&&this.rng()<.6)this.hurdle((l+2)%3,z+run+g+8,0);return run+g+land}
 sGapMulti(z,len,dif){const r=this.rng;let zz=z;this.slab(zz,zz+10,0);zz+=10;const n=3+Math.floor(r()*2);let yPrev=0;for(let i=0;i<n;i++){const g=4+r()*(2.5+dif*3),pl=10+r()*6,y=Math.round((r()*1.4)*10)/10;zz+=g;this.slab(zz,zz+pl,y);const l=Math.floor(r()*3);this.coinArc(laneX(l),y+1.2,zz-g,zz+3,1.4,5);if(r()<.5)this.hurdle(Math.floor(r()*3),zz+pl-4,y);yPrev=y;zz+=pl}this.slab(zz,zz+8,0);return zz+8-z}
 sWall(z,len,dif){const g=Math.round(9+dif*10),run=10;this.slab(z,z+run,0);const a=z+run,b=a+g;for(const sd of[-1,1])this.wallPanel(sd,a-2,b+2,0);this.slab(b+3,b+13,0);
  for(const sd of[-1,1]){for(let zz=a+2;zz<b;zz+=2.5)this.coin(sd*3.0,1.9,zz)}this.coinLine(0,.9,a+1,b-1,3);return run+g+13}
 sStairs(z,len,dif){const r=this.rng;let zz=z;this.slab(zz,zz+10,0);zz+=10;let y=0;const n=2+Math.floor(r()*2);for(let i=0;i<n;i++){y+=1.15;const L=11+r()*4;this.slab(zz,zz+L,y);this.coinLine(laneX(Math.floor(r()*3)),y+.8,zz+1,zz+L-1,2.4);if(r()<.5)this.hurdle(Math.floor(r()*3),zz+L*.6,y);zz+=L}
  this.ramp(zz,zz+18,y,0);this.coinLine(0,y*.6+.8,zz+2,zz+16,2.4);zz+=18;this.slab(zz,zz+6,0);return zz+6-z}
 sLasers(z,len,dif){const r=this.rng;this.slab(z,z+len,0);let zz=z+10;while(zz<z+len-6){this.laser(zz,0,r()<.5,1.8+r()*.8,.55,r());if(r()<.4+dif*.3)this.laser(zz+7,0,!1,1.8+r()*.8,.55,r());this.coinLine(laneX(Math.floor(r()*3)),.8,zz-5,zz+5,2.5);zz+=18+r()*4}return len}
 sElec(z,len,dif){const r=this.rng;this.slab(z,z+len,0,-3.5,3.5,{});let zz=z+9;while(zz<z+len-8){const a=Math.floor(r()*3),b=(a+1+Math.floor(r()*2))%3;this.elec(a,zz,7,0,1.5,r());if(dif>.3||r()<.4)this.elec(b,zz,7,0,1.5,r());this.coinLine(laneX(3-a-b>=0&&3-a-b<=2?3-a-b:1),.8,zz,zz+8,2.4);zz+=15+r()*4}return len}
 sTrains(z,len,dif){const r=this.rng;this.slab(z,z+len,0);let zz=z+30;while(zz<z+len-10){const a=Math.floor(r()*3);this.train(a,zz+20,14,15+r()*5,0);if(r()<.6+dif*.3){const b=(a+1+Math.floor(r()*2))%3;this.train(b,zz+34,14,14+r()*5,0)}const fr=[0,1,2].find(i=>true);this.coinLine(laneX(Math.floor(r()*3)),.8,zz,zz+10,2.4);if(r()<.5)this.hurdle(Math.floor(r()*3),zz+6,0);zz+=44+r()*8}return len}
 sCrane(z,len,dif){const r=this.rng;this.slab(z,z+len,0);let zz=z+12;while(zz<z+len-8){this.crane(zz,2.6+r()*.8,r()*6);if(r()<.5)this.beam([Math.floor(r()*3)],zz+8,0);this.coinLine(laneX(Math.floor(r()*3)),.9,zz+2,zz+10,2.4);zz+=24+r()*5}return len}
 sGirders(z,len,dif){const r=this.rng;let zz=z;const pats=[[0,1],[1,2],[0],[2],[1]];this.slab(zz,zz+14,0);zz+=14;const n=3+Math.floor(r()*2);let prev=[0,1,2];for(let i=0;i<n;i++){const ok=pats.filter(q=>q.some(l=>prev.includes(l))&&q!==prev&&(i>0||q.length>1||q[0]===1));const q=ok[Math.floor(r()*ok.length)];const L=13+r()*5;const x0=laneX(q[0])-1.3,x1=laneX(q[q.length-1])+1.3;this.slab(zz,zz+L,0,x0,x1);const cl=q[Math.floor(r()*q.length)];this.coinLine(laneX(cl),.8,zz+1,zz+L-1,2.3);if(r()<.4&&q.length>1)this.hurdle(q[q.length-1],zz+L*.55,0);zz+=L;prev=q;if(i<n-1)zz+=3+r()*1.5}this.slab(zz,zz+8,0);return zz+8-z}
 sCollapse(z,len,dif){const r=this.rng;this.slab(z,z+9,0);let zz=z+9;const rows=Math.floor((len-18)/7);let safe=Math.floor(r()*3);for(let i=0;i<rows;i++){safe=clamp(safe+Math.floor(r()*3)-1,0,2);for(let l=0;l<3;l++){if(l===safe||r()<.45){this.slab(zz,zz+6.8,0,laneX(l)-1.1,laneX(l)+1.1)}else{this.collapse(l,zz,6.8,0)}}this.coinLine(laneX(safe),.8,zz,zz+6,2.2);zz+=7}this.slab(zz,zz+9,0);return zz+9-z}
 sElevator(z,len,dif){const r=this.rng;this.slab(z,z+10,0);const g=20;const l=Math.floor(r()*3);this.elevator(l,z+10+g/2-3,6,.2,2.0,3.4,r()*6);this.slab(z+10+g,z+10+g+12,0);this.coinArc(laneX(l),1.6,z+10+2,z+10+g-2,1.6,8);return 10+g+12}
 sSpin(z,len,dif){const r=this.rng;this.slab(z,z+len,0);let zz=z+12;while(zz<z+len-10){this.spin(Math.floor(r()*3),zz,0);this.coinLine(laneX(Math.floor(r()*3)),.9,zz-8,zz+8,2.6);zz+=22+r()*5}return len}
 sPads(z,len,dif){const r=this.rng;this.slab(z,z+len,0);const l=Math.floor(r()*3),zz=z+14;this.pad(l,zz,0,'jump');this.slab(zz+9,zz+27,4.2,laneX(l)-1.3,laneX(l)+1.3,{ledge:true});this.coinLine(laneX(l),5.1,zz+10,zz+26,2);if(r()<.5)this.item('gem',laneX(l),5.2,zz+18);this.coinLine(laneX((l+1)%3),.8,zz,zz+len-20,2.5);this.pad((l+2)%3,z+len-14,0,'boost');return len}
 sGlass(z,len,dif){this.slab(z,z+len,0);this.glass(z+14,0);this.coinLine(0,1,z+16,z+22,1.4);this.coinLine(laneX(1),.9,z+4,z+12,2.4);if(len>=62){this.glass(z+len-12,0);this.coinLine(0,1,z+len-10,z+len-4,1.4)}return len}
 sDrones(z,len,dif){const r=this.rng;this.slab(z,z+len,0);let zz=z+10;while(zz<z+len-6){const a=Math.floor(r()*3);this.drone(a,zz,0);if(r()<.5)this.drone((a+1+Math.floor(r()*2))%3,zz+(r()<.5?0:5),0);this.coinLine(laneX(Math.floor(r()*3)),.7,zz-3,zz+3,1.5);zz+=14+r()*4}return len}
 sSecret(z,len,dif){this.slab(z,z+len,0);const zz=z+14;this.block(0,zz,9,3.1,0,{ledge:true,secretHint:true});this.slab(zz+13,zz+24,4.7,laneX(0)-1.3,laneX(0)+1.3,{ledge:true});this.coinArc(laneX(0),4.2,zz+8,zz+14,1.5,5);this.coinLine(laneX(0),5.5,zz+14,zz+23,2);
  this.item('token',laneX(0),5.7,zz+22,{tid:this.dAt(z)});this.coinLine(laneX(2),.8,zz,zz+20,2.4);this.secretLeft=0;return len}
 /* ---------- weights per district ---------- */
 pickSeg(z,dif){const k=this.dAt(z),r=this.rng;const T={
  0:[['sFlat',1],['sHurdles',3],['sBeams',2],['sBlocks',2.5],['sGap',4],['sGapMulti',3],['sWall',2.2],['sStairs',1.5],['sPads',1.2],['sDrones',2],['sGlass',.6]],
  1:[['sHurdles',2],['sBeams',3],['sBlocks',3],['sGap',2],['sCrane',4],['sGirders',4],['sGlass',2],['sStairs',1.2],['sPads',1],['sDrones',1.2]],
  2:[['sFlat',.6],['sHurdles',2],['sBeams',2],['sTrains',5],['sWall',3],['sElec',3],['sGlass',1.2],['sBlocks',1.5],['sDrones',1]],
  3:[['sGap',3],['sCollapse',4],['sLasers',4],['sHurdles',2],['sBeams',1],['sPads',2],['sWall',1.2],['sSpin',1.2],['sGapMulti',1.5]],
  4:[['sStairs',3],['sElevator',3],['sGlass',3],['sWall',3],['sSpin',2],['sBlocks',2],['sGap',2],['sLasers',1],['sDrones',1]],
  5:[['sElec',4],['sLasers',4],['sPads',2],['sSpin',3],['sGlass',2],['sGap',2],['sBlocks',2],['sBeams',2],['sCrane',1.2],['sCollapse',2]]}[k];
  let tot=0;for(const t of T)tot+=t[1];let x=r()*tot;for(const t of T){x-=t[1];if(x<=0)return t[0]}return T[0][0]}
 nextSeg(){const z=this.cz,r=this.rng;let len=0;
  if(z>=this.arenaZ){this.slab(z,z+CH,0,-3.6,3.6);this.decor(z,z+CH);if(r()<.5)this.coinLine(laneX(Math.floor(r()*3)),.9,z+4,z+CH-4,3);len=CH}
  else if(this.first){this.first=false;this.sFlat(z,44,{bare:true});this.coinLine(0,.9,z+10,z+40,2.5);len=44}
  else if(z>=this.len&&!this.noBoss&&this.mode!=='endless'&&this.mode!=='chase'&&this.mode!=='challenge'){this.arenaZ=z;this.slab(z,z+CH,0,-3.6,3.6);this.decor(z,z+CH);len=CH;this.bossGate=z}
  else if(z>=this.nextCp&&this.cpEvery){this.nextCp+=this.cpEvery;this.slab(z,z+20,0);this.decor(z,z+20);const th=this.th(z);this.item('cp',0,0,z+10,{});this.cps.push(z+10);len=20}
  else{const dif=this.diff(z);const name=this.secretLeft>0&&z>(this.o.secretZ||300)?'sSecret':this.pickSeg(z,dif);const L=name==='sGap'||name==='sWall'||name==='sElevator'?0:34+Math.floor(r()*30);len=this[name](z,L||40,dif);this.segs.push([name,z,z+len])}
  if(z<this.arenaZ)this.decor(z,z+len);
  if(this.segN++>2&&z<this.arenaZ&&r()<.3+.08*(this.o.luck||0)){const t=pick(r,['magnet','shield','x2','boost','heal','gem']);this.item(t,laneX(Math.floor(r()*3)),1.2,z+len*.5)}
  this.cz=z+len}
 gen(pz,ahead){while(this.cz<pz+ahead)this.nextSeg()}
 /* ---------- queries ---------- */
 near(z){const q=this.q;q.length=0;const a=Math.floor((z-6)/CH),b=Math.floor((z+9)/CH);for(let i=a;i<=b;i++){const c=this.chunks.get(i);if(c)for(let j=0;j<c.solids.length;j++)q.push(c.solids[j])}for(let j=0;j<this.movers.length;j++)q.push(this.movers[j]);return q}
 upd(t,dt,pz){for(let i=this.movers.length-1;i>=0;i--){const o=this.movers[i];
   if(o.train===undefined&&o.sp&&!o.collapse&&!o.elev){/* train */if(!o.act&&o.z0-pz<o.trig)o.act=true;if(o.act){o.z0-=o.sp*dt;o.z1=o.z0+o.len}}
   if(o.collapse&&!o.dead){const d=o.cz0-pz;if(o.state===0&&d<13){o.state=1;o.tt=0}if(o.state===1){o.tt+=dt;if(o.tt>.5||d<5){o.state=2;o.vy=0;o.fy=0}}if(o.state===2){o.off=true;o.vy=(o.vy||0)-30*dt;o.fy+=o.vy*dt;if(o.fy<-25)o.dead=true}}
   if(o.elev)o.y1=o.yLo+(o.yHi-o.yLo)*(.5+.5*S(t*6.28/o.per+o.ph));
   if(o.z1<pz-30)this.movers.splice(i,1)}}
 /* solids to ignore for collapse tiles: state 2 means no support */
 chunkRange(pz,back,fwd){const a=Math.floor((pz-back)/CH),b=Math.floor((pz+fwd)/CH);return[a,b]}
 /* bake static meshes of nearby chunks (limit per call) and free far ones */
 bake(R,pz,back,fwd,limit){const[a,b]=this.chunkRange(pz,back,fwd);let n=0;if(!this.scratch)this.scratch=new V.Mesh(240000);
  for(let i=a;i<=b;i++){const c=this.chunks.get(i);if(!c||c.mesh||n>=limit)continue;const m=this.scratch;m.reset();for(const o of c.st)o.d(m);if(m.over)m.over=false;c.mesh=R.upload(m);n++}
  for(const[i,c]of this.chunks){if(i<a-1||i>b+1){if(c.mesh){R.free(c.mesh);c.mesh=null}if(this.endless&&i<a-3)this.chunks.delete(i)}}return n}
 meshes(pz,back,fwd,out){out.length=0;const[a,b]=this.chunkRange(pz,back,fwd);for(let i=a;i<=b;i++){const c=this.chunks.get(i);if(c&&c.mesh)out.push(c.mesh)}return out}
 /* dynamic draw: coins, items, animated hazards */
 drawDyn(m,sp,t,pz,fwd){const a=Math.floor((pz-8)/CH),b=Math.floor((pz+fwd)/CH);const th=this.th(pz);
  for(let i=a;i<=b;i++){const c=this.chunks.get(i);if(!c)continue;
   for(const k of c.coins){if(k.got||k.z<pz-6||k.z>pz+fwd)continue;m.push();m.tr(k.x,k.y+S(t*3+k.z)*.06,k.z);m.ry(t*3.2+k.z);m.box(0,0,0,.46,.46,.09,GOLD,1.1);m.box(0,0,0,.28,.28,.12,[1,.85,.4],1.4);m.pop()}
   for(const o of c.dyn){if(o.z1<pz-8||o.z0>pz+fwd)continue;o.dd(m,sp,t,o)}
   for(const it of c.items){if(it.got||it.z<pz-6||it.z>pz+fwd+30)continue;this.drawItem(m,sp,t,it)}}
  for(const o of this.movers){if(o.z1<pz-8||o.z0>pz+fwd+40)continue;if(o.dd)o.dd(m,sp,t,o)}}
 drawItem(m,sp,t,it){const th=this.th(it.z);const bob=S(t*2.5+it.z)*.12;
  switch(it.t){
  case'cp':{const ac=it.hit?[.4,1,.6]:V.c(th.acc);m.box(-3.9,2.5,it.z,.3,5,.3,ac,1.4);m.box(3.9,2.5,it.z,.3,5,.3,ac,1.4);m.box(0,5,it.z,8.1,.3,.3,ac,1.4);m.box(0,4.4,it.z,4,.5,.1,ac,.6);break}
  case'padj':m.prism(it.x,it.y,it.z,.9,.9,.12,8,V.c('#ff9a3c'),1.5);m.prism(it.x,it.y+.1,it.z,.6,.6,.05,8,WHITE,1.8);sp.add(it.x,it.y+.6,it.z,2.2,0,1,.6,.2,.8);break;
  case'padb':for(let i=0;i<3;i++)m.box(it.x,it.y+.04,it.z-1+i,1.6,.08,.4,i===(Math.floor(t*6)%3)?WHITE:V.c('#3aff9a'),1.8);sp.add(it.x,it.y+.4,it.z,2,0,.3,1,.6,.7);break;
  case'token':{m.push();m.tr(it.x,it.y+bob,it.z);m.ry(t*2);m.box(0,0,0,.7,.7,.7,V.c('#ff3fb8'),1.8);m.box(0,0,0,.4,.4,.9,WHITE,2);m.pop();sp.add(it.x,it.y+bob,it.z,2.4,0,1,.3,.8,.9,t);break}
  case'gem':{m.push();m.tr(it.x,it.y+bob,it.z);m.ry(t*2.5);m.prism(0,-.3,0,.35,.0,.3,4,V.c('#6ee7ff'),1.7);m.prism(0,0,0,.0,.35,.3,4,V.c('#6ee7ff'),1.7);m.pop();sp.add(it.x,it.y+bob,it.z,1.4,0,.3,.9,1,.8);break}
  default:{const col={magnet:'#ff4d6d',shield:'#4da6ff',x2:'#ffd54a',boost:'#3aff9a',heal:'#ff6ac8'}[it.t]||'#fff';m.push();m.tr(it.x,it.y+bob,it.z);m.ry(t*2);m.box(0,0,0,.6,.6,.6,V.c(col),1.6);m.box(0,0,0,.34,.34,.7,WHITE,1.8);m.pop();sp.add(it.x,it.y+bob,it.z,1.8,0,V.c(col)[0],V.c(col)[1],V.c(col)[2],.85)}}}
 destroy(R){for(const[i,c]of this.chunks){if(c.mesh)R.free(c.mesh)}this.chunks.clear();this.movers.length=0}
}
V.World=World;
})();
