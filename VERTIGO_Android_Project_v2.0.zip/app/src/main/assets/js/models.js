/* VERTIGO models: procedural low-poly heroes, accessories, companions, bosses */
(function(){
'use strict';
const V=window.V;const S=Math.sin,Cs=Math.cos,PI=Math.PI;
const W=[1,1,1];

/* ---------- colours per hero+skin ---------- */
const hc={};
V.heroColors=function(h,s){const k=h*10+s;if(hc[k])return hc[k];const H=V.HEROES[h].pal,sk=V.SKINS.find(x=>x.hero===h&&x.idx===s)||{h:0,s:1,l:1};
 const mod={h:sk.h,s:sk.s,l:sk.l};const r={a:V.recolor(V.c(H.a),mod),b:V.recolor(V.c(H.b),mod),g:V.recolor(V.c(H.g),{h:sk.h,s:1,l:1}),d:V.c(H.d),s:V.c(H.s),fx:sk.fx};
 if(sk.fx==='gold'){r.a=V.mixc(r.a,V.c('#ffcf4a'),.45);r.g=V.c('#ffe27a')}if(sk.fx==='shadow'){r.a=V.shade(r.a,.55);r.b=V.shade(r.b,.6);r.g=V.c('#b46bff')}
 return hc[k]=r};

/* ---------- pose ---------- */
V.newPose=()=>({ph:0,lA:0,lB:0,rA:0,rB:0,aLa:0,aLb:0,aRa:0,aRb:0,pitch:0,roll:0,yaw:0,bob:0,t:0,st:'run'});
V.pose=function(P,st,t,o){o=o||{};const ph=t*(10+(o.sp||0)*5);P.ph=ph;P.t=t;P.st=st;P.pitch=0;P.roll=0;P.yaw=0;P.bob=0;
 switch(st){
 case 'run':{const c=Cs(ph);P.lA=-S(ph)*.95;P.lB=.15+Math.max(0,c)*1.2;P.rA=S(ph)*.95;P.rB=.15+Math.max(0,-c)*1.2;P.aLa=S(ph)*.9;P.aLb=-1;P.aRa=-S(ph)*.9;P.aRb=-1;P.pitch=.16;P.bob=Math.abs(c)*.07;break}
 case 'jump':P.lA=-.9;P.lB=1;P.rA=.3;P.rB=.9;P.aLa=-2.3;P.aLb=-.3;P.aRa=-2.3;P.aRb=-.3;P.pitch=.05;break;
 case 'fall':P.lA=-.5+S(t*14)*.2;P.lB=.6;P.rA=.4-S(t*14)*.2;P.rB=.7;P.aLa=-2.5+S(t*16)*.4;P.aLb=-.3;P.aRa=-2.5-S(t*16)*.4;P.aRb=-.3;break;
 case 'slide':P.pitch=-1.25;P.bob=-.5;P.lA=0;P.lB=.1;P.rA=.1;P.rB=.1;P.aLa=-1.5;P.aLb=-.2;P.aRa=-1.5;P.aRb=-.2;break;
 case 'dash':P.pitch=.6;P.lA=-1.25;P.lB=.3;P.rA=.9;P.rB=1.3;P.aLa=1.5;P.aLb=-.2;P.aRa=1.5;P.aRb=-.2;break;
 case 'wall':{const c=Cs(ph);P.roll=-(o.side||1)*1.3;P.lA=-S(ph)*.9;P.lB=.15+Math.max(0,c);P.rA=S(ph)*.9;P.rB=.15+Math.max(0,-c);P.aLa=S(ph)*.8;P.aLb=-.6;P.aRa=-S(ph)*.8;P.aRb=-.6;P.bob=.1;break}
 case 'climb':P.lA=-S(t*16)*.9;P.lB=.9;P.rA=S(t*16)*.9;P.rB=.9;P.aLa=-2.9;P.aLb=-.2;P.aRa=-2.9;P.aRb=-.2;break;
 case 'hit':P.pitch=-.3;P.lA=-.3;P.lB=.4;P.rA=.3;P.rB=.4;P.aLa=-.5;P.aLb=-.4;P.aRa=.5;P.aRb=-.4;break;
 default:{const b=S(t*2.2);P.bob=b*.012;P.lA=0;P.lB=.05;P.rA=0;P.rB=.05;P.aLa=.06+b*.03;P.aLb=-.2;P.aRa=.06+b*.03;P.aRb=-.2;if(st==='pose'){P.aLa=-1.2;P.aLb=-.5}}}
 if(o.flip)P.pitch+=o.flip;if(o.spin)P.yaw+=o.spin;if(o.lean)P.roll+=o.lean;return P};

/* ---------- building blocks ---------- */
function leg(m,C,P,side,sp){const A=side<0?P.lA:P.rA,B=side<0?P.lB:P.rB;const len=sp.legLen||1;m.push();m.tr(side*(sp.legX||.13),.92,0);m.rx(A);
 m.box(0,-.23*len,0,sp.legW||.17,.46*len,sp.legD||.18,sp.pants||C.d);m.tr(0,-.46*len,0);m.rx(B);m.box(0,-.22*len,0,(sp.legW||.17)*.9,.46*len,(sp.legD||.18)*.9,sp.pants2||sp.pants||C.d);
 sp.shoe?sp.shoe(m,C,P,side):(m.box(0,-.47*len,.07,.18,.1,.3,C.b),m.box(0,-.53*len,.07,.18,.03,.3,C.g,1));m.pop()}
function arm(m,C,P,side,sp){const A=side<0?P.aLa:P.aRa,B=side<0?P.aLb:P.aRb;m.push();m.tr(side*(sp.armX||.32),sp.armY||1.46,0);m.rx(A);
 m.box(0,-.14,0,.14,.3,.14,sp.sleeve||C.a);m.tr(0,-.28,0);m.rx(B);m.box(0,-.14,0,.12,.28,.12,sp.sleeve2||sp.sleeve||C.a);
 sp.hand?sp.hand(m,C,P,side):m.box(0,-.3,0,.12,.12,.12,sp.glove||C.s);m.pop()}
const defTorso=(m,C)=>{m.box(0,1.22,0,.5,.64,.28,C.a);m.box(0,1.22,.145,.1,.62,.01,C.g,1);m.box(0,.93,0,.52,.08,.3,C.d)};
function humanoid(m,C,P,sp){m.push();
 m.tr(0,.95,0);m.rx(P.pitch);m.tr(0,-.95,0);
 if(!sp.noLegs){leg(m,C,P,-1,sp);leg(m,C,P,1,sp)}
 (sp.torso||defTorso)(m,C,P);
 (sp.head||(()=>{}))(m,C,P);
 if(!sp.noArms){arm(m,C,P,-1,sp);arm(m,C,P,1,sp)}
 if(sp.extra)sp.extra(m,C,P);
 m.pop()}
const eyes=(m,y,z,sep,r,pc)=>{for(const s of[-1,1]){m.ball(s*sep,y,z,r,W,.3,5);m.ball(s*sep,y,z+r*.7,r*.5,pc||[.05,.05,.1],0,4)}};

/* ---------- hero specs ---------- */
const SP=[];
SP[0]={hy:2.05,by:-.2,
 torso:(m,C,P)=>{m.box(0,1.22,0,.5,.64,.3,C.a);m.box(0,1.22,.155,.08,.6,.01,C.g,1.2);m.box(0,1.28,.155,.36,.03,.01,C.g,1);m.box(0,.93,0,.52,.08,.32,C.d);m.box(0,1.6,-.12,.34,.18,.14,C.a)},
 head:(m,C)=>{m.box(0,1.76,0,.36,.38,.36,C.a);m.box(0,1.98,-.04,.36,.06,.42,C.a);m.box(0,1.72,.19,.3,.24,.02,C.d);m.box(0,1.74,.205,.28,.06,.01,C.g,1.5);m.box(0,1.86,-.2,.3,.3,.08,C.a)},
 pants:null,glove:null};
SP[0].pants=V.c('#161c32');SP[0].glove=V.c('#101523');
SP[1]={hy:2.0,by:-.25,legLen:.7,legW:.15,
 torso:(m,C)=>{m.box(0,1.15,0,.64,.62,.38,C.a);m.box(0,1.15,.2,.5,.5,.02,C.g,.4);m.box(0,1.15,.21,.1,.5,.01,W,.2);m.box(0,.9,0,.66,.1,.4,C.d);m.box(-.04,1.12,-.26,.18,.16,.14,C.a);m.box(.1,1.2,-.3,.12,.2,.1,C.a)},
 head:(m,C)=>{m.box(0,1.64,0,.42,.4,.4,C.a);m.box(0,1.62,.3,.3,.07,.22,C.b);m.box(0,1.56,.3,.28,.05,.2,C.b);m.box(0,1.74,.21,.38,.06,.02,C.g,.6);m.box(0,1.72,.23,.36,.09,.02,[.06,.06,.1],0);m.box(0,1.86,0,.1,.1,.1,C.a)},
 pants:null,shoe:(m,C)=>{m.box(0,-.34,.12,.26,.05,.36,C.b);m.box(0,-.31,.3,.22,.04,.14,C.b)}};
SP[1].pants=null;
SP[2]={hy:2.0,by:-.2,
 torso:(m,C)=>{m.box(0,1.22,0,.52,.64,.3,C.b);m.box(0,1.26,.155,.1,.56,.01,W);m.box(0,1.12,.165,.07,.38,.01,C.g,.7);m.box(0,.93,0,.54,.08,.32,C.d)},
 head:(m,C,P)=>{m.box(0,1.78,.02,.42,.44,.5,C.a);m.box(0,2.06,-.02,.06,.22,.34,C.g,.5);m.box(0,2.14,-.1,.06,.12,.2,C.g,.5);
  for(const s of[-1,1]){m.ball(s*.22,1.84,.12,.1,W,.2,5);m.ball(s*.26,1.84,.17,.05,[0,0,0],0,4);m.box(s*.23,1.7,-.08,.03,.2,.08,C.g,.3)}m.box(0,1.62,.28,.34,.04,.02,[.1,.05,.1],0);
  m.box(0,1.58,.12,.3,.05,.2,C.a)},
 pants:V.c('#1c2a3d'),
 hand:(m,C,P,side)=>{m.box(0,-.3,0,.12,.12,.12,C.s);if(side>0){m.box(0,-.52,.1,.1,.34,.44,V.c('#5a3a22'));m.box(0,-.52,.33,.04,.06,.02,V.c('#ffd54a'),.8)}}};
SP[3]={hy:2.1,by:-.4,legLen:.75,
 torso:(m,C,P)=>{m.push();m.tr(0,.95,0);m.rx(-.28);m.box(0,.22,0,.5,.5,.38,C.a);m.tr(0,.45,0);m.rx(.34);m.box(0,.25,0,.52,.5,.4,C.a);m.tr(0,.48,0);m.rx(.3);m.box(0,.12,.02,.44,.3,.36,C.a);m.box(0,.3,.02,.16,.14,.14,C.b);
  for(let i=0;i<3;i++)m.box(0,.05+i*.0,-.22-.0,.12,.14,.16,C.b);m.pop();
  m.box(0,1.2,.22,.4,.04,.01,C.g,.6)},
 head:(m,C)=>{m.push();m.tr(0,1.78,.14);m.box(0,0,0,.34,.3,.36,C.a);m.box(0,-.04,.26,.2,.14,.2,C.a);m.box(0,-.11,.3,.18,.04,.18,W,.2);eyes(m,.1,.16,.12,.06);m.pop();m.box(0,2.0,.06,.08,.12,.08,C.b)},
 extra:(m,C,P)=>{const sw=S(P.ph*.5)*.15;m.push();m.tr(0,.95,-.2);m.rx(.6);m.box(0,0,-.2,.2,.18,.4,C.a);m.tr(0,0,-.4);m.rx(.3+sw);m.box(0,0,-.2,.14,.14,.4,C.a);m.tr(0,0,-.4);m.rx(.2+sw);m.box(0,0,-.2,.08,.1,.36,C.b);m.pop();
  for(let i=0;i<5;i++)m.box(0,1.62-i*.1,-.26-i*.02,.06,.1,.12,C.b)},
 hand:(m,C)=>m.box(0,-.2,0,.09,.12,.09,C.a),armX:.28,sleeve:V.c('#ffe14d')};
SP[4]={hy:2.1,by:-.2,
 torso:(m,C)=>{m.box(0,1.2,0,.5,.62,.3,C.b);for(let i=0;i<3;i++)m.box(0,1.04+i*.18,0,.52,.06,.32,C.g,.2);m.box(0,.93,0,.52,.08,.32,C.d)},
 head:(m,C,P)=>{const j=S(P.t*45)*.02;m.push();m.tr(j,1.74,0);m.prism(0,-.05,0,.17,.24,.46,8,C.a,.1);m.prism(0,.38,0,.22,.2,.04,8,C.b,.1);m.box(.3,.2,0,.06,.2,.1,C.a);m.box(.26,.12,0,.08,.05,.1,C.a);m.box(.26,.28,0,.08,.05,.1,C.a);
  eyes(m,.2,.2,.09,.07);m.box(0,.08,.22,.14,.04,.02,[.1,0,0],0);m.pop()},
 pants:V.c('#2a1a10')};
SP[5]={hy:2.2,by:-.3,legLen:.85,noArms:false,armY:1.3,armX:.3,sleeve:V.c('#ff6a13'),
 torso:(m,C)=>{m.prism(0,.55,0,.4,.07,1.12,8,C.a,.15);m.prism(0,.82,0,.33,.31,.12,8,C.b,.3);m.prism(0,1.2,0,.24,.22,.12,8,C.b,.3);m.box(0,.51,0,.84,.06,.84,C.d);
  for(const s of[-1,1]){m.box(s*.09,1.34,.2,.12,.05,.02,C.g,1.6);m.box(s*.1,1.4,.2,.14,.03,.02,C.d)}m.box(0,1.16,.24,.2,.04,.02,C.d)},
 pants:V.c('#2a1a0e'),shoe:(m,C)=>{m.box(0,-.4,.06,.18,.1,.28,C.d)}};
SP[6]={hy:2.1,by:-.3,legLen:1.1,legW:.1,legD:.1,armY:1.35,armX:.3,sleeve:V.c('#8a5a2c'),
 torso:(m,C)=>{m.prism(0,.65,0,.27,.27,1.05,8,C.a,.05,false);m.prism(0,1.7,0,.27,.23,.06,8,C.b,.05);for(let i=0;i<3;i++)m.prism(0,.78+i*.34,0,.285,.285,.05,8,C.b,.1,false);
  for(const s of[-1,1]){m.ball(s*.11,1.42,.24,.09,W,.35,5);m.ball(s*.11,1.42,.31,.04,[0,0,0],0,4)}m.box(0,1.2,.27,.14,.05,.02,[.1,0,0],0)},
 shoe:(m,C)=>{m.box(0,-.5,.06,.12,.06,.2,C.d)},pants:V.c('#2f1c0d'),
 hand:(m,C,P,side)=>{m.box(0,-.3,0,.1,.1,.1,C.s);if(side>0){m.push();m.tr(0,-.3,.05);m.rx(-1.2+S(P.ph)*.4);m.box(0,.35,0,.1,.9,.1,C.b);m.box(0,.85,0,.14,.3,.14,C.b);m.box(0,.55,.0,.15,.03,.15,C.g,.6);m.pop()}}};
SP[7]={hy:2.15,by:-.2,legLen:1,legW:.11,legD:.11,armY:1.4,armX:.24,
 torso:(m,C)=>{m.box(0,1.2,0,.38,.58,.22,C.a);m.box(0,1.2,.12,.34,.08,.02,C.g,.8);m.prism(0,.88,0,.48,.34,.1,10,C.g,.35);m.prism(0,.96,0,.34,.26,.08,10,V.mixc(C.g,W,.5),.35)},
 head:(m,C,P)=>{m.push();m.tr(0,1.74,0);m.prism(0,-.1,0,.15,.22,.42,8,C.a,.15);m.prism(0,.31,0,.21,.2,.04,8,C.b,.1);m.ball(0,.36,0,.12,V.c('#e8d6b8'),.15,5);m.box(0,.38,.0,.2,.02,.03,C.b);eyes(m,.14,.19,.08,.055);m.box(0,.02,.2,.08,.03,.02,C.g,.5);m.ball(0,.42,-.2,.1,C.b,0,4);m.pop()},
 pants:V.c('#f3e6d6'),sleeve:V.c('#f3e6d6'),shoe:(m,C)=>{m.box(0,-.5,.1,.1,.06,.26,C.g,.5)},
 extra:(m,C,P)=>{}};
SP[8]={hy:2.05,by:-.2,
 torso:(m,C,P)=>{for(let i=0;i<4;i++)m.box(0,1.04+i*.15,0,.52,.15,.3,i%2?C.b:C.a);m.box(0,1.25,-.16,.14,.18,.01,C.g,.8);m.box(0,.93,0,.52,.1,.32,C.d)},
 head:(m,C)=>{m.box(0,1.74,0,.34,.36,.34,C.s);m.box(0,1.94,-.02,.36,.12,.36,V.c('#1a1410'));m.box(0,1.8,.17,.34,.05,.02,C.g,.8);eyes(m,1.74,.17,.08,.04,[0,0,0])},
 pants:V.c('#14142a'),pants2:V.c('#f5f5f5'),shoe:(m,C)=>{m.box(0,-.47,.07,.18,.1,.3,C.g,.5)},
 extra:(m,C,P)=>{const t=P.t*7;m.ball(0,.26+Math.abs(S(t))*.2,.62+S(t*.5)*.12,.17,W,.1,6);m.ball(0,.3+Math.abs(S(t))*.2,.76+S(t*.5)*.12,.06,[.1,.1,.1],0,4)}};
SP[9]={hy:2.15,by:-.25,
 torso:(m,C)=>{m.box(0,1.22,0,.56,.64,.34,C.a);m.box(.14,1.2,.18,.2,.3,.02,C.b);m.box(0,1.5,.18,.16,.08,.04,V.c('#b01c2b'));m.box(0,.93,0,.58,.1,.36,C.d);for(let i=0;i<3;i++)m.box(-.16,1.0+i*.14,.18,.18,.03,.02,C.b)},
 head:(m,C,P)=>{const j=Math.round(S(P.t*12)*2)/2*.04;m.push();m.tr(j,1.8,0);m.box(0,0,0,.46,.4,.42,C.a);m.box(0,-.06,.26,.24,.16,.14,C.s);m.box(0,-.0,.34,.1,.06,.04,C.d);for(const s of[-1,1]){m.ball(s*.2,.24,-.02,.1,C.a,0,5);m.ball(s*.12,.08,.22,.075,[.02,.02,.02],0,5);m.ball(s*.12,.08,.27,.04,C.g,1.6,4)}
  m.box(.17,.0,.2,.1,.12,.03,C.b);for(let i=-1;i<=1;i++)m.box(i*.06,-.15,.3,.04,.05,.02,W);m.box(0,.28,0,.34,.03,.34,C.d);m.box(0,.38,0,.24,.18,.24,C.d);m.pop()},
 shoe:(m,C)=>{m.box(0,-.47,.07,.2,.1,.32,C.b)},pants:V.c('#4d3018'),pants2:V.c('#6a7380'),
 hand:(m,C)=>{m.box(0,-.3,0,.12,.14,.12,C.b)},sleeve2:V.c('#6a7380')};
SP[10]={hy:2.1,by:-.25,legLen:.9,legW:.13,legD:.13,armY:1.38,armX:.34,sleeve:V.c('#ff7eb6'),
 torso:(m,C,P)=>{const sw=S(P.ph)*.04;m.push();m.rz(sw);m.ball(0,1.22,0,.42,C.a,.1,8);m.box(0,.96,0,.62,.14,.4,C.g,.35);m.box(0,1.5,.34,.46,.04,.02,C.b,.9);m.pop()},
 head:(m,C)=>{m.box(0,1.74,.12,.6,.14,.1,[.05,.05,.08]);m.box(0,1.745,.17,.52,.07,.02,C.g,1.4);for(const s of[-1,1])m.box(s*.14,1.5,.35,.1,.1,.02,C.b,.9);m.box(0,1.62,.4,.06,.04,.02,[.6,.1,.2],0);m.box(0,2.1,0,.18,.3,.16,C.a)},
 pants:V.c('#ff7eb6'),shoe:(m,C)=>{m.box(0,-.4,.1,.16,.08,.3,V.c('#e0183a'),.2);m.box(0,-.34,-.05,.05,.16,.05,V.c('#ffd54a'),.5)},hand:(m,C)=>m.box(0,-.3,0,.18,.14,.12,C.a)};
SP[1].pants=V.c('#ff8a1f');

V.drawHero=function(m,h,s,acc,P,x,y,z,o){o=o||{};const C=V.heroColors(h,s),sp=SP[h];
 m.push();m.tr(x,y+P.bob,z);m.ry(P.yaw);m.rz(P.roll);if(o.flick&&Math.floor(o.flick*14)%2){m.pop();return}
 humanoid(m,C,P,sp);
 if(acc)drawAcc(m,acc,C,P,sp);
 m.pop()};

/* ---------- accessories ---------- */
function drawAcc(m,a,C,P,sp){const hy=sp.hy||2.05,by=sp.by||-.2;m.push();m.tr(0,.95,0);m.rx(P.pitch);m.tr(0,-.95,0);
 switch(a){
 case 1:m.prism(0,hy+.12,0,.26,.26,.03,12,V.c('#ffe27a'),1.4);m.prism(0,hy+.14,0,.19,.19,.03,12,[0,0,0],0);break;
 case 2:{const w=S(P.ph*.9)*.25;for(let i=0;i<4;i++){m.push();m.tr(0,1.5-i*.22,by-.04);m.rx(.35+w*(.4+i*.3));m.box(0,-.15,-.02*i,.5-i*.04,.28,.04,C.g,.35);m.pop()}break}
 case 3:for(const s of[-1,1]){m.prism(s*.14,1.0,by-.12,.09,.09,.5,6,V.c('#7a8396'),.1);m.prism(s*.14,.9,by-.12,.07,.04,.12,6,C.g,1.5)}break;
 case 4:m.box(0,hy-.15,0,.46,.05,.06,V.c('#222'));for(const s of[-1,1])m.box(s*.24,hy-.34,0,.1,.2,.2,C.g,.9);break;
 case 5:m.prism(0,hy-.05,0,.2,.22,.12,6,V.c('#ffcf4a'),.9);for(let i=0;i<5;i++){const t=i/5*PI*2;m.box(Math.cos(t)*.2,hy+.12,Math.sin(t)*.2,.05,.12,.05,V.c('#ffd96a'),1)}break;
 case 6:{const f=S(P.ph*.9)*.3;for(const s of[-1,1]){m.push();m.tr(s*.14,1.45,by-.1);m.rz(s*(.55+f));m.box(s*.25,.2,0,.5,.05,.03,C.g,1.4);m.box(s*.2,.0,0,.4,.05,.03,C.g,1.1);m.box(s*.12,-.18,0,.26,.05,.03,C.g,.9);m.pop()}break}
 }m.pop()}

/* ---------- companions ---------- */
V.drawComp=function(m,c,t,x,y,z){m.push();m.tr(x,y+S(t*3)*.12,z);
 switch(c){
 case 1:m.ball(0,0,0,.2,V.c('#cfd6e6'),.1,6);m.ball(0,0,.13,.07,[.1,.9,1],1.5,4);for(const s of[-1,1])for(const q of[-1,1]){m.box(s*.28,.08,q*.28,.3,.02,.06,V.c('#2a3042'));m.push();m.tr(s*.28,.1,q*.28);m.ry(t*30);m.box(0,0,0,.34,.02,.05,V.c('#9aa'));m.pop()}break;
 case 2:{const f=S(t*14)*.7;m.ball(0,0,0,.17,V.c('#14141c'),0,6);m.box(0,0,.18,.05,.04,.12,V.c('#ffb21e'));m.ball(.07,.05,.1,.03,[1,.2,.3],1.5,4);for(const s of[-1,1]){m.push();m.tr(s*.12,.04,0);m.rz(s*f);m.box(s*.22,0,0,.44,.03,.22,V.c('#0e0e16'));m.pop()}m.box(0,-.03,-.2,.1,.03,.2,V.c('#0e0e16'));break}
 case 3:m.box(0,0,0,.34,.3,.3,V.c('#8a94a8'));m.box(0,0,.16,.2,.12,.02,[1,.4,.2],1.5);m.box(0,.2,0,.06,.1,.06,V.c('#cfd6e6'));m.ball(0,.27,0,.05,[1,.3,.2],1.5,4);m.box(0,-.2,0,.2,.06,.2,V.c('#39ffb0'),1);break;
 case 4:m.ball(0,0,0,.18,V.c('#6ee7ff'),1,6);m.push();m.ry(t*2);m.rx(t*1.3);m.prism(0,-.01,0,.3,.3,.02,10,V.c('#ffffff'),1.2);m.pop();m.push();m.rz(t*2);m.ry(t);m.prism(0,-.01,0,.26,.26,.02,10,V.c('#ffe14d'),1.2);m.pop();break;
 case 5:m.box(0,0,0,.26,.2,.4,V.c('#f0c6a0'));m.box(0,.12,.22,.2,.18,.2,V.c('#f0c6a0'));m.box(0,.1,.33,.08,.06,.06,[.05,.05,.05]);for(const s of[-1,1])m.box(s*.1,.24,.2,.06,.14,.06,V.c('#b0724a'));m.box(0,.08,-.22,.05,.05,.18+S(t*20)*.04,V.c('#f0c6a0'));m.box(.0,.18,.25,.2,.03,.02,[.2,1,.8],1.2);break;
 }m.pop()};

/* ---------- bosses ---------- */
V.drawBoss=function(m,b,t,st){const B=V.BOSSES[b],c1=V.c(B.col),c2=V.c(B.col2),fl=st.flash>0?1:0,ex=st.exposed?1:0;
 const glow=ex?1.8:(st.atk?1.3:.7);m.push();m.tr(st.x,st.y,st.z);m.sc(st.scale||1);const bob=S(t*2)*.2;
 switch(b){
 case 0:{m.tr(0,bob+2.4,0);m.box(0,0,0,2.2,1.8,1.4,fl?W:c2);m.box(0,0,.72,1.6,.8,.1,c1,glow);m.ball(0,0,.78,.34,ex?[1,1,1]:[1,.2,.3],glow+.4,6);
  for(const s of[-1,1]){m.push();m.tr(s*1.6,.2,0);m.rz(s*.2);m.box(0,0,0,.5,1.6,.7,c2);m.box(0,-.2,.5,.26,.26,.9,c1,.8);m.pop();m.box(s*.8,-1.2,0,.3,.9,.3,c2);m.prism(s*.8,-2.0,0,.22,.02,.8,6,[1,.6,.2],1.6)}
  m.box(0,1.1,0,.8,.5,.8,c2);m.box(0,1.4,.32,.5,.08,.1,c1,1.4);m.push();m.ry(t*2);m.prism(0,1.7,0,.2,.2,.3,6,c1,1.2);m.pop();break}
 case 1:{m.tr(0,bob*.5,0);m.box(0,.9,0,2.4,1.8,2.2,c1,.2);m.box(0,.3,1.1,2.1,.4,.1,c2);for(const s of[-1,1]){m.box(s*1.2,.1,-.6,.7,.6,2.6,c2);m.box(s*1.2,.1,.2,.5,.5,.6,V.c('#555'))}
  m.box(0,2.15,.2,1.0,.7,.9,V.c('#2a3042'));m.box(0,2.15,.7,.7,.4,.05,[1,.3,.2],glow);m.box(0,3.8,-.6,.3,3.0,.3,c2);m.push();m.tr(0,5.2,-.6);m.rx(-.5);m.box(0,0,1.8,.3,.3,3.8,c2);m.box(0,.2,3.4,.1,.5,.1,c2);m.pop();
  const sw=S(t*2.5)*.8;m.push();m.tr(sw*1.5,2.3,2.6);m.box(0,.9,0,.04,1.8,.04,V.c('#999'));m.ball(0,-.2,0,.8,fl?W:V.c('#444'),.15,7);m.ball(0,-.2,.55,.18,[1,.3,.2],glow,4);m.pop();break}
 case 2:{for(let i=0;i<9;i++){const ph=t*2-i*.5,y=1.6+S(ph)*.9+i*.08,z=-i*1.05;const r=1.15-i*.05;m.push();m.tr(S(ph*.7)*.35,y,z);m.prism(0,-r*.5,0,r,r,r,8,i%2?c2:V.shade(c2,1.4),.1,false);m.box(0,r*.55,0,r*.5,.06,r*.5,c1,glow*.6);m.pop()}
  m.push();m.tr(0,1.8+S(t*2)*.9,.9);m.ry(t*4);for(let i=0;i<6;i++){m.push();m.ry(i/6*PI*2);m.box(.5,0,0,.55,.1,.1,V.c('#c8d0e0'),.2);m.pop()}m.pop();m.ball(0,1.8+S(t*2)*.9,.95,.5,ex?W:c1,glow,6);break}
 case 3:{m.tr(0,bob+3,0);m.push();m.ry(t*.8);for(let i=0;i<6;i++){const a=i/6*PI*2;m.push();m.tr(Math.cos(a)*2.3,S(t*3+i)*.3,Math.sin(a)*2.3);m.ry(-a);m.box(0,0,0,.4,.4,1.2,c2);m.box(0,0,.7,.1,.1,.5,c1,glow);m.pop()}m.pop();
  m.prism(0,-1.4,0,.01,1.1,1.6,6,c2,.1,false);m.prism(0,.2,0,1.1,.01,1.6,6,V.shade(c2,1.3),.15,false);m.ball(0,.3,.4,.34,ex?W:c1,glow+.3,6);for(let i=0;i<5;i++){const a=(i-2)*.35;m.box(S(a)*1.3,1.5+Cs(a)*.2,0,.1,.5,.1,c1,glow)}break}
 case 4:{m.tr(0,bob+2.6,0);for(let i=0;i<14;i++){const a=i*2.4+t*.7,r=.6+(i%4)*.3,y=-1.4+i*.22;m.box(Math.cos(a)*r,y+S(t*2+i)*.12,Math.sin(a)*r*.7,.5,.5,.5,i%3?V.c('#bfe9ff'):c1,.5+(i%2)*.4)}
  m.box(0,.5,0,1.0,1.7,.8,V.c('#6fa7c9'),.2);m.box(0,2.0,0,.7,.7,.7,fl?W:V.c('#9bd8f5'),.3);m.box(0,2.0,.37,.4,.1,.02,ex?W:[1,.4,.5],glow+.3);for(const s of[-1,1]){m.push();m.tr(s*1.1,1.2,0);m.rz(s*.5);m.box(0,-.5,0,.18,1.7,.18,V.c('#d8f3ff'),.4);m.pop()}break}
 case 5:{m.tr(0,bob+2.8,0);m.box(0,0,0,2.6,2.2,1.6,fl?W:c2);m.box(0,.1,.82,1.2,1.2,.1,c1,glow);m.ball(0,.1,.9,.5,ex?W:[1,.1,.2],glow+.5,7);
  for(const s of[-1,1])for(const q of[0,1]){m.push();m.tr(s*(1.7+q*.5),.9-q*1.3,0);m.rz(s*(.4+q*.5));m.box(0,-.5,0,.45,1.9,.5,c2);m.box(0,-1.5,.2,.5,.5,.8,c1,.9);m.pop()}
  m.box(0,1.5,0,1.1,.9,1,V.c('#121218'));m.box(0,1.6,.52,.7,.12,.02,c1,1.6);for(const s of[-1,1])m.box(s*.5,2.4,0,.2,.8,.2,c1,glow);m.push();m.tr(0,.1,-.6);m.rx(t*.8);m.prism(0,0,0,2.2,2.2,.05,12,c1,1.2,false);m.pop();break}
 case 6:{m.tr(0,bob+1.9,0);m.push();m.rz(-.25);m.box(0,.2,0,2,2.4,1.6,c1);m.box(0,.2,.82,1.6,1.8,.04,V.c('#ffef9a'),.2);m.pop();m.box(0,1.9,.55,1.2,.9,1.2,c1);m.box(0,1.5,1.4,.8,.5,.6,c1);for(const s of[-1,1])m.ball(s*.4,2.2,1.1,.2,W,.3,5),m.ball(s*.4,2.2,1.28,.08,[0,0,0],0,4);
  m.box(0,2.5,.5,.9,.08,.9,V.c('#ffd54a'),.9);for(let i=0;i<4;i++)m.box(-.4+i*.27,2.65,.5,.14,.3,.14,V.c('#ffd54a'),.9);for(const s of[-1,1]){m.box(s*.7,2.0,.5,.2,.5,.5,V.c('#222'));m.ball(s*.82,1.9,.5,.24,[1,.2,.7],1.2,5)}
  for(let i=0;i<5;i++)m.box(0,1.4-i*.1,-.9-i*.4,.3+(5-i)*.1,.3,.5,c2);m.push();m.tr(0,0,-3);m.ry(t*2);m.ball(0,3.6,0,.22,[1,.3,.9],1.8,5);m.pop();break}
 }m.pop()};

})();
