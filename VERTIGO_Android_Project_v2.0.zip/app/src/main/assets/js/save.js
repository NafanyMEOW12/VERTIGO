/* VERTIGO save: versioned local save, backup copy, corruption recovery, economy and achievements */
(function(){
'use strict';
const V=window.V;
const KEY='vertigo2_save',BAK='vertigo2_save_bak';
const defaults=()=>({v:2,coins:0,heroes:[0],skins:[0],hero:0,skin:{0:0},accs:[0],acc:0,comps:[0],comp:0,upg:{dash:0,jump:0,armor:0,magnet:0,combo:0,luck:0},
 done:[],medals:{},bossKilled:[],secrets:[],meme:false,memeKilled:false,seenIntro:false,
 best:{endless:0,chase:{},campaign:{}},chall:{},
 daily:{idx:0,last:'',claims:0},
 stat:{dist:0,coins:0,tricks:0,wall:0,near:0,dash:0,breaks:0,runs:0,chases:0,bosses:0,flawless:0,combo:0,supers:0,time:0,score:0},
 ach:[],set:{music:.7,sfx:.8,sens:1,quality:'med',left:false,shake:true,fps:false,haptic:true},created:Date.now()});
V.defaults=defaults;
function merge(base,src){if(src==null||typeof src!=='object')return base;for(const k in base){if(!(k in src))continue;const b=base[k],s=src[k];
 if(Array.isArray(b))base[k]=Array.isArray(s)?s.filter(x=>x!=null):b;
 else if(b&&typeof b==='object')base[k]=merge(b,s);
 else if(typeof b===typeof s&&(typeof s!=='number'||isFinite(s)))base[k]=s}
 for(const k of['skin','medals','chall','chase','campaign'])if(src[k]&&typeof src[k]==='object'&&base[k]&&!Array.isArray(base[k]))Object.assign(base[k],src[k]);return base}
function validate(s){const H=V.HEROES.length;s.heroes=[...new Set(s.heroes.filter(i=>Number.isInteger(i)&&i>=0&&i<H))];if(!s.heroes.includes(0))s.heroes.push(0);
 if(!s.heroes.includes(s.hero))s.hero=0;s.skins=[...new Set(s.skins.filter(i=>Number.isInteger(i)&&i>=0&&i<V.SKINS.length))];
 for(const h of s.heroes){if(!s.skins.includes(h*4))s.skins.push(h*4)}
 s.accs=[...new Set(s.accs.filter(i=>Number.isInteger(i)&&i>=0&&i<V.ACCS.length))];if(!s.accs.includes(0))s.accs.push(0);if(!s.accs.includes(s.acc))s.acc=0;
 s.comps=[...new Set(s.comps.filter(i=>Number.isInteger(i)&&i>=0&&i<V.COMPS.length))];if(!s.comps.includes(0))s.comps.push(0);if(!s.comps.includes(s.comp))s.comp=0;
 s.coins=Math.max(0,Math.floor(s.coins));s.done=[...new Set(s.done.filter(i=>Number.isInteger(i)&&i>=0&&i<6))];
 for(const k in s.upg)s.upg[k]=V.clamp(Math.floor(s.upg[k]),0,5);
 s.skin=s.skin||{};for(const h of s.heroes){const sv=s.skin[h];if(!(Number.isInteger(sv)&&sv>=0&&sv<4&&s.skins.includes(h*4+sv)))s.skin[h]=0}
 s.set.music=V.clamp(+s.set.music,0,1);s.set.sfx=V.clamp(+s.set.sfx,0,1);s.set.sens=V.clamp(+s.set.sens,.5,1.8);if(!['low','med','high'].includes(s.set.quality))s.set.quality='med';
 return s}
V.loadSave=function(){let s=null,src='new';
 for(const k of[KEY,BAK]){try{const raw=localStorage.getItem(k);if(!raw)continue;const j=JSON.parse(raw);if(j&&typeof j==='object'){s=validate(merge(defaults(),j));src=k;break}}catch(e){}}
 if(!s){s=validate(defaults())}
 V.saveSrc=src;V.S=s;return s};
let pend=null,lastW=0;
V.persist=function(now){const w=()=>{pend=null;lastW=Date.now();try{const raw=JSON.stringify(V.S);const old=localStorage.getItem(KEY);if(old)localStorage.setItem(BAK,old);localStorage.setItem(KEY,raw)}catch(e){}};
 if(now){clearTimeout(pend);w()}else if(!pend)pend=setTimeout(w,700)};
V.resetSave=function(){try{localStorage.removeItem(KEY);localStorage.removeItem(BAK)}catch(e){}V.S=validate(defaults());V.persist(true)};

/* ---------- economy (guarded against double charge) ---------- */
V.spend=function(cost){if(!(cost>=0)||V.S.coins<cost)return false;V.S.coins-=cost;V.persist(true);return true};
V.addCoins=function(n){n=Math.floor(n);if(n<=0)return;V.S.coins+=n;V.persist()};
V.owned=(kind,i)=>kind==='hero'?V.S.heroes.includes(i):kind==='skin'?V.S.skins.includes(i):kind==='acc'?V.S.accs.includes(i):V.S.comps.includes(i);
V.buy=function(kind,i){const S=V.S;if(V.owned(kind,i))return'owned';
 let price=0;if(kind==='hero'){const h=V.HEROES[i];if(S.done.length<h.need)return'locked';price=h.price}else if(kind==='skin'){const k=V.SKINS[i];if(!S.heroes.includes(k.hero))return'nohero';price=k.price}else if(kind==='acc')price=V.ACCS[i].price;else price=V.COMPS[i].price;
 if(!V.spend(price))return'poor';
 if(kind==='hero'){S.heroes.push(i);if(!S.skins.includes(i*4))S.skins.push(i*4);S.skin[i]=0}else if(kind==='skin')S.skins.push(i);else if(kind==='acc')S.accs.push(i);else S.comps.push(i);
 V.persist(true);V.checkAch();return'ok'};
V.upgCost=id=>{const l=V.S.upg[id];return l>=5?null:V.UPG_COST[l]};
const upT={};
V.buyUpg=function(id){const now=Date.now();if(upT[id]&&now-upT[id]<350)return'wait';const l=V.S.upg[id];if(l>=5)return'max';const c=V.UPG_COST[l];if(!V.spend(c))return'poor';upT[id]=now;V.S.upg[id]=l+1;V.persist(true);return'ok'};

/* ---------- achievements ---------- */
V.statVal=function(k){const S=V.S;switch(k){case'done':return S.done.length;case'secrets':return S.secrets.length;case'heroes':return S.heroes.length;case'skinsOwned':return S.skins.length;
 case'endless':return S.best.endless;case'dailyN':return S.daily.claims;case'meme':return S.memeKilled?1:0;case'chall':return Object.keys(S.chall).length;case'supers':return S.stat.supers;default:return S.stat[k]||0}};
V.onAch=null;
V.checkAch=function(){const S=V.S;let n=0;for(const a of V.ACH){if(S.ach.includes(a.id))continue;if(V.statVal(a.stat)>=a.goal){S.ach.push(a.id);S.coins+=a.rew;n++;if(V.onAch)V.onAch(a)}}if(n)V.persist(true);return n};

/* ---------- daily rewards (offline, clock-rollback safe) ---------- */
const dkey=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
V.dailyState=function(){const D=V.S.daily,t=dkey();return{idx:D.idx%7,can:D.last<t,today:t}};
V.claimDaily=function(){const S=V.S,st=V.dailyState();if(!st.can)return null;const r=V.DAILY[st.idx];let msg=r.n;
 if(r.t==='coins')S.coins+=r.v;else if(r.t==='acc'){if(!S.accs.includes(r.v)){S.accs.push(r.v)}else S.coins+=150}
 else if(r.t==='skin'||r.t==='bundle'){const want=r.t==='skin'?1:2;const pool=V.SKINS.filter(k=>k.rar===want&&S.heroes.includes(k.hero)&&!S.skins.includes(V.SKINS.indexOf(k)));
  if(pool.length){const k=pool[Math.floor(Math.random()*pool.length)];S.skins.push(V.SKINS.indexOf(k));msg=V.HEROES[k.hero].name+': «'+k.name+'»'}else{S.coins+=300;msg+=' (все скины открыты: +300)'}
  if(r.t==='bundle')S.coins+=r.v}
 S.daily.last=st.today;S.daily.idx=(S.daily.idx+1)%7;S.daily.claims++;V.persist(true);V.checkAch();return msg};
})();
