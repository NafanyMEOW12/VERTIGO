# VERTIGO — Android 3D game starter project

This is a first playable prototype for an original 3D mobile parkour game.

Included:
- Three.js scene with a stylized night city
- Camera following the character
- Touch left/right to wall-jump
- Air dash, double jump, basic wall contact and checkpoints
- Collectibles, combo counter, height/record display, restart and pause
- Local save data
- Android WebView wrapper
- GitHub Actions workflow for building a debug APK

## Build using only an iPhone

The easiest route is to upload this ZIP plus the workflow file.

1. Create a **new private GitHub repository** named `VERTIGO`.
2. Upload `VERTIGO_Android_Project.zip` to the repository root.
3. In GitHub, create the file `.github/workflows/build-apk.yml`.
4. Copy the contents of the included `.github/workflows/build-apk.yml` into that new repository file and commit it. (GitHub does not run a workflow that exists only inside a ZIP archive.)
5. Open **Actions** → **Build VERTIGO Android APK** → **Run workflow**.
6. Wait for the run to finish. Open the run, find **Artifacts**, and download `VERTIGO-debug-apk`.
7. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Send the APK to an Android phone, install it, and allow installation from that source if Android asks.

The workflow automatically extracts the project ZIP, downloads the official Three.js module into the app's assets, and builds the APK. The installed game uses the local library copy and does not need internet to run.

## Current scope

This is a playable prototype, not a finished commercial game. It prioritizes the core movement loop. Full character animation sets, complete story chapters, boss encounters, daily challenges and a polished shop are later development stages.

The generated APK is a debug build for testing, not a Play Store release build.
