package com.vertigo.game;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.view.View;
import android.graphics.Color;
import android.view.WindowManager;
public class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
  getWindow().setStatusBarColor(Color.rgb(6,7,20));
  getWindow().setNavigationBarColor(Color.rgb(6,7,20));
  getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  web=new WebView(this); web.setBackgroundColor(Color.rgb(6,7,20));
  WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setLoadsImagesAutomatically(true); s.setMediaPlaybackRequiresUserGesture(false); s.setSupportZoom(false);
  web.setOverScrollMode(View.OVER_SCROLL_NEVER); web.setWebChromeClient(new WebChromeClient()); setContentView(web); web.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed() {
  if(web!=null) web.evaluateJavascript("(function(){if(window.__vertigoPause){window.__vertigoPause();}else{var m=document.getElementById('menu');if(m)m.style.display='flex';}})()",null);
  else super.onBackPressed();
 }
 @Override protected void onPause(){if(web!=null)web.onPause();super.onPause();}
 @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();}
 @Override protected void onDestroy(){if(web!=null){web.loadUrl("about:blank");web.destroy();web=null;}super.onDestroy();}
}
