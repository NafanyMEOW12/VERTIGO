VERTIGO CINEMATIC SEQUENCE
Three original 1280x720 SVG keyframes, played as an in-game animated cinematic intro with pan/zoom, subtitles, transitions by timed cuts, and skip button. This is an in-engine illustrated cinematic, not a pre-rendered MP4 video.
