VERTIGO LOW-POLY MODEL PACK
10 original hero meshes (OBJ), VANTA Enforcer boss mesh, and 3 companion meshes.
These meshes are offline asset-source models; the current gameplay renderer draws a procedural low-poly character directly in WebGL rather than importing OBJ files. The character in-game was enhanced with layered gear and a running animation. OBJ meshes can be imported in Blender or a compatible 3D editor for rigging/UVs.
